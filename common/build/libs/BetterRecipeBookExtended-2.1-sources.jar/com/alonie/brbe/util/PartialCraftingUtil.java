package com.alonie.brbe.util;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.mixins.accessors.RecipeCollectionAccessor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.class_10295;
import net.minecraft.class_10297;
import net.minecraft.class_10298;
import net.minecraft.class_10300;
import net.minecraft.class_10301;
import net.minecraft.class_10302;
import net.minecraft.class_10352;
import net.minecraft.class_10363;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2371;
import net.minecraft.class_310;
import net.minecraft.class_516;

public final class PartialCraftingUtil {
    private static final WeakHashMap<class_516, Set<class_10298>> PARTIAL_RECIPES = new WeakHashMap<>();
    private static final WeakHashMap<class_516, Integer> CHECKED_COLLECTIONS = new WeakHashMap<>();
    private static int filteringGeneration;
    private static boolean filteringActive;

    private PartialCraftingUtil() {
    }

    /**
     * Single point-of-control for the partial material marking feature.
     * All public methods check this before doing any work, so callers
     * never need to repeat the config gate.
     */
    private static boolean enabled() {
        return BetterRecipeBook.config.partialMarkingEnabled;
    }

    public static void beginFilteringUpdate(boolean active) {
        filteringActive = active;
        if (active) {
            filteringGeneration++;
        }
    }

    public static boolean markPartialMaterials(class_516 collection, class_2371<class_1735> slots) {
        if (!enabled()) return false;
        CHECKED_COLLECTIONS.put(collection, filteringGeneration);
        boolean markedAny = false;
        Set<class_10298> partialRecipes = new HashSet<>();
        for (class_10297 recipe : collection.method_2650()) {
            if (collection.method_2653(recipe.comp_3262())) {
                continue;
            }

            if (recipe.comp_3266().map(requirements -> hasMatchingIngredient(requirements, slots)).orElse(false)
                    || hasMatchingDisplayIngredient(recipe.comp_3263(), slots)) {
                partialRecipes.add(recipe.comp_3262());
                markedAny = true;
            }
        }

        if (markedAny) {
            PARTIAL_RECIPES.put(collection, partialRecipes);
        } else {
            PARTIAL_RECIPES.remove(collection);
        }

        return markedAny;
    }

    public static void markPartialMaterial(class_516 collection, class_10298 recipeDisplayId) {
        if (!enabled()) return;
        PARTIAL_RECIPES.put(collection, new HashSet<>(Collections.singleton(recipeDisplayId)));
        CHECKED_COLLECTIONS.put(collection, filteringGeneration);
    }

    public static boolean wasCheckedForPartialMaterials(class_516 collection) {
        if (!enabled()) return false;
        Integer generation = CHECKED_COLLECTIONS.get(collection);
        return filteringActive && generation != null && generation == filteringGeneration;
    }

    public static boolean isPartiallyCraftable(class_516 collection, class_10298 recipeDisplayId) {
        if (!enabled()) return false;
        Set<class_10298> partialRecipes = PARTIAL_RECIPES.get(collection);
        return partialRecipes != null && partialRecipes.contains(recipeDisplayId);
    }

    public static boolean hasPartialMaterials(class_516 collection) {
        if (!enabled()) return false;
        Set<class_10298> partialRecipes = PARTIAL_RECIPES.get(collection);
        return partialRecipes != null && !partialRecipes.isEmpty();
    }

    /**
     * Classifies a collection by iterating its recipes and checking each
     * against both {@link #isPartiallyCraftable} and the vanilla craftable
     * set.  This is the single source of truth for collection classification;
     * sort methods and button mixins should use this instead of inline loops.
     */
    public static CollectionCategory categorize(class_516 c) {
        if (!enabled()) return CollectionCategory.UNASSIGNED;
        boolean truly = false, partial = false;
        for (class_10297 entry : c.method_2650()) {
            class_10298 id = entry.comp_3262();
            if (isPartiallyCraftable(c, id)) {
                partial = true;
            } else if (c.method_2653(id)) {
                truly = true;
            }
        }
        if (truly) return CollectionCategory.TRULY_CRAFTABLE;
        if (partial) return CollectionCategory.PARTIAL;
        return CollectionCategory.UNASSIGNED;
    }

    public static List<class_10297> getPartiallyCraftableRecipes(class_516 collection) {
        if (!enabled()) return Collections.emptyList();
        Set<class_10298> partialRecipes = PARTIAL_RECIPES.get(collection);
        if (partialRecipes == null || partialRecipes.isEmpty()) {
            return Collections.emptyList();
        }

        List<class_10297> recipes = new ArrayList<>();
        for (class_10297 recipe : collection.method_2650()) {
            if (partialRecipes.contains(recipe.comp_3262())) {
                recipes.add(recipe);
            }
        }

        return recipes;
    }

    public static List<class_10297> getSelectedRecipes(class_516 collection, class_516.class_9937 status) {
        if (!enabled()) return collection.method_64885(status);
        List<class_10297> selectedRecipes = collection.method_64885(status);
        if (status != class_516.class_9937.field_52848) {
            return selectedRecipes;
        }

        Set<class_10298> partialRecipes = PARTIAL_RECIPES.get(collection);
        if (partialRecipes == null || partialRecipes.isEmpty()) {
            return selectedRecipes;
        }

        List<class_10297> combinedRecipes = new ArrayList<>(selectedRecipes);
        Set<class_10298> existingIds = new HashSet<>();
        for (class_10297 recipe : selectedRecipes) {
            existingIds.add(recipe.comp_3262());
        }

        for (class_10297 recipe : collection.method_2650()) {
            if (partialRecipes.contains(recipe.comp_3262()) && !existingIds.contains(recipe.comp_3262())) {
                combinedRecipes.add(recipe);
            }
        }

        return combinedRecipes;
    }

    private static boolean hasMatchingIngredient(List<class_1856> ingredients, class_2371<class_1735> slots) {
        for (class_1856 ingredient : ingredients) {
            if (ingredient.method_65799()) {
                continue;
            }

            for (class_1735 slot : slots) {
                if (slot.method_7681() && ingredient.method_8093(slot.method_7677())) {
                    return true;
                }
            }
        }

        return false;
    }

    private static boolean hasMatchingDisplayIngredient(class_10295 display, class_2371<class_1735> slots) {
        if (display instanceof class_10300 shaped) {
            return hasMatchingSlotDisplay(shaped.comp_3270(), slots);
        }

        if (display instanceof class_10301 shapeless) {
            return hasMatchingSlotDisplay(shapeless.comp_3271(), slots);
        }

        return false;
    }

    private static boolean hasMatchingSlotDisplay(List<class_10302> ingredients, class_2371<class_1735> slots) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1687 == null) {
            return false;
        }

        class_10352 context = class_10363.method_65008(minecraft.field_1687);
        for (class_10302 ingredient : ingredients) {
            for (class_1799 candidate : ingredient.method_64738(context)) {
                if (candidate.method_7960()) {
                    continue;
                }

                for (class_1735 slot : slots) {
                    if (slot.method_7681() && candidate.method_7909().equals(slot.method_7677().method_7909())) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}
