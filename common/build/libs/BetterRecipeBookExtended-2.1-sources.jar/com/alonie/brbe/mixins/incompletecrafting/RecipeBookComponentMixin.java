package com.alonie.brbe.mixins.incompletecrafting;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.mixins.accessors.RecipeCollectionAccessor;
import com.alonie.brbe.util.CollectionCategory;
import com.alonie.brbe.util.IncompatibleCraftingUtil;
import com.alonie.brbe.util.PartialCraftingUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_10297;
import net.minecraft.class_10298;
import net.minecraft.class_1729;
import net.minecraft.class_310;
import net.minecraft.class_490;
import net.minecraft.class_507;
import net.minecraft.class_513;
import net.minecraft.class_516;

@Mixin(class_507.class)
public abstract class RecipeBookComponentMixin {
    @Shadow @Final
    protected class_1729 menu;

    @Shadow @Final
    protected class_310 minecraft;

    @Shadow
    private net.minecraft.class_342 searchBox;

    @Inject(method = "updateCollections", at = @At("HEAD"))
    private void betterRecipeBook$trackPartialFilteringUpdate(boolean resetPageNumber, boolean isFiltering, CallbackInfo ci) {
        boolean retainIncompatible = BetterRecipeBook.config.showAllRecipesInSurvival
                && !isFiltering
                && this.minecraft != null
                && this.minecraft.field_1755 instanceof class_490;
        IncompatibleCraftingUtil.beginFiltering(retainIncompatible);
    }

    @Redirect(method = "updateCollections", at = @At(value = "INVOKE", target = "Ljava/util/List;removeIf(Ljava/util/function/Predicate;)Z"))
    private boolean betterRecipeBook$keepPartiallyCraftable(List<class_516> collections, Predicate<? super class_516> predicate) {
        // ── Gate variables: single point of truth for each concern ──
        boolean onInventoryScreen = this.minecraft != null
                && this.minecraft.field_1755 instanceof class_490;
        boolean retainPartial = BetterRecipeBook.config.partialMarkingEnabled;
        boolean retainIncompatible = onInventoryScreen
                && BetterRecipeBook.config.showAllRecipesInSurvival;

        // Only skip everything when BOTH features are off.
        if (!retainPartial && !retainIncompatible) {
            return collections.removeIf(predicate);
        }

        // ── Partial material marking (gated inside PartialCraftingUtil) ──
        // Step 0: Clear previously-injected partial IDs from craftable set
        for (class_516 collection : collections) {
            if (PartialCraftingUtil.hasPartialMaterials(collection)) {
                RecipeCollectionAccessor accessor = (RecipeCollectionAccessor) collection;
                for (class_10297 entry : collection.method_2650()) {
                    class_10298 id = entry.comp_3262();
                    if (PartialCraftingUtil.isPartiallyCraftable(collection, id)) {
                        accessor.betterRecipeBook$getCraftable().remove(id);
                    }
                }
            }
        }

        for (class_516 collection : collections) {
            PartialCraftingUtil.markPartialMaterials(collection, this.menu.field_7761);

            // Inject partial recipes into craftable set
            if (PartialCraftingUtil.hasPartialMaterials(collection)) {
                RecipeCollectionAccessor accessor = (RecipeCollectionAccessor) collection;
                for (class_10297 entry : collection.method_2650()) {
                    class_10298 id = entry.comp_3262();
                    if (PartialCraftingUtil.isPartiallyCraftable(collection, id)) {
                        accessor.betterRecipeBook$getCraftable().add(id);
                    }
                }
            }
        }

        // ── Incompatible recipe marking ──
        if (retainIncompatible) {
            for (class_516 collection : collections) {
                IncompatibleCraftingUtil.markIncompatibleRecipes(collection);
            }
        }

        // ── Retention flags for the removeIf predicate ──
        boolean hasSearchActive = searchBox != null && !searchBox.method_1882().isEmpty();
        boolean keepPartial = retainPartial && !hasSearchActive;
        boolean keepIncompatible = retainIncompatible
                && IncompatibleCraftingUtil.isActive()
                && !hasSearchActive;

        if (!keepPartial && !keepIncompatible) {
            return collections.removeIf(predicate);
        }

        boolean removed = collections.removeIf(collection -> {
            if (!predicate.test(collection)) return false;
            if (keepPartial && PartialCraftingUtil.hasPartialMaterials(collection)) return false;
            if (keepIncompatible && IncompatibleCraftingUtil.hasIncompatibleRecipes(collection)) return false;
            return true;
        });

        return removed;
    }

    @Redirect(method = "updateCollections", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeBookPage;updateCollections(Ljava/util/List;ZZ)V"))
    private void betterRecipeBook$sortCraftableBeforePartial(
            class_513 page, List<class_516> list, boolean resetPageNumber, boolean isFiltering) {
        // Sort when partialCraftingEnabled is active, or when
        // partialMarkingEnabled is active AND the vanilla filter is on.
        boolean shouldSort = BetterRecipeBook.config.partialCraftingEnabled
                || (BetterRecipeBook.config.partialMarkingEnabled && isFiltering);
        if (!shouldSort) {
            page.method_2627(list, resetPageNumber, isFiltering);
            return;
        }

        // 3-group when partialCraftingEnabled is on (filter button hidden)
        // OR vanilla filter is active. Otherwise 2-group.
        boolean useFullSort = BetterRecipeBook.config.partialCraftingEnabled
                || isFiltering;
        boolean hasPartialData = BetterRecipeBook.config.partialMarkingEnabled;

        List<class_516> front = new ArrayList<>();
        List<class_516> middle = new ArrayList<>();
        List<class_516> back = new ArrayList<>();

        for (class_516 c : list) {
            if (hasPartialData) {
                CollectionCategory cat = PartialCraftingUtil.categorize(c);
                if (useFullSort) {
                    switch (cat) {
                        case TRULY_CRAFTABLE -> front.add(c);
                        case PARTIAL -> middle.add(c);
                        case UNASSIGNED -> back.add(c);
                    }
                } else {
                    if (cat != CollectionCategory.UNASSIGNED) front.add(c);
                    else back.add(c);
                }
            } else {
                if (c.method_2655()) front.add(c); else back.add(c);
            }
        }

        list.clear();
        list.addAll(front);
        list.addAll(middle);
        list.addAll(back);
        page.method_2627(list, resetPageNumber, isFiltering);
    }
}
