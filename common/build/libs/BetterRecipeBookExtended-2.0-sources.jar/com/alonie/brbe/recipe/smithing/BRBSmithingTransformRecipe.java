package com.alonie.brbe.recipe.smithing;

import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.mixins.accessors.smithing.SmithingTransformRecipeAccessor;
import com.alonie.brbe.recipe.BRBSmithingRecipe;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_8054;
import net.minecraft.class_8060;

public class BRBSmithingTransformRecipe extends class_8060 implements BRBSmithingRecipe {
    public BRBSmithingTransformRecipe(class_1856 template, class_1856 base, class_1856 addition, class_1799 result) {
        super(template, base, addition, result);
    }

    public static BRBSmithingTransformRecipe from(class_8060 recipe, class_5455 registryAccess) {
        SmithingTransformRecipeAccessor recipeAccessor = (SmithingTransformRecipeAccessor) recipe;
        return new BRBSmithingTransformRecipe(recipeAccessor.getUnderlyingTemplate(), recipeAccessor.getUnderlyingBase(), recipeAccessor.getUnderlyingAddition(), recipe.method_8110(registryAccess));
    }

    @Override
    public class_1799 getResult(class_5455 registryAccess, BRBBookCategories.Category category) {
        return ((SmithingTransformRecipeAccessor) this).getResult();
    }

    @Override
    public class_1799 getResult(class_5321<class_8054> trimMaterialResourceKey, class_5455 registryAccess, BRBBookCategories.Category category) {
        return getResult(registryAccess, category);
    }

    @Override
    public class_1799 getBase() {
        return ((SmithingTransformRecipeAccessor) this).getUnderlyingBase().method_8105()[0];
    }

    @Override
    public class_1856 getTemplate() {
        return ((SmithingTransformRecipeAccessor) this).getUnderlyingTemplate();
    }

    @Override
    public class_1856 getAddition() {
        return ((SmithingTransformRecipeAccessor) this).getUnderlyingAddition();
    }
}
