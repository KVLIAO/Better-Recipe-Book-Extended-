package com.alonie.brbe.recipe.smithing;

import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.mixins.accessors.smithing.SmithingTrimRecipeAccessor;
import com.alonie.brbe.recipe.BRBSmithingRecipe;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_8053;
import net.minecraft.class_8054;
import net.minecraft.class_8055;
import net.minecraft.class_8056;
import net.minecraft.class_8057;
import net.minecraft.class_8062;
import net.minecraft.class_9334;
import net.minecraft.world.item.armortrim.*;
import java.util.ArrayList;
import java.util.Optional;

public class BRBSmithingTrimRecipe extends class_8062 implements BRBSmithingRecipe {
    private final class_1799 itemStackBase;

    public BRBSmithingTrimRecipe(class_1856 template, class_1856 base, class_1799 itemStackBase, class_1856 addition) {
        super(template, base, addition);
        this.itemStackBase = itemStackBase;
    }

    public static ArrayList<BRBSmithingTrimRecipe> from(class_8062 recipe) {
        SmithingTrimRecipeAccessor recipeAccessor = (SmithingTrimRecipeAccessor) recipe;
        ArrayList<BRBSmithingTrimRecipe> results = new ArrayList<>();

        for (class_1799 base : recipeAccessor.getUnderlyingBase().method_8105()) {
            results.add(new BRBSmithingTrimRecipe(recipeAccessor.getUnderlyingTemplate(), recipeAccessor.getUnderlyingBase(), base, recipeAccessor.getUnderlyingAddition()));
        }

        return results;
    }

    @Override
    public class_1799 getResult(class_5455 registryAccess, BRBBookCategories.Category category) {
        return this.getResult(class_8055.field_42007, registryAccess, category);
    }

    @Override
    public class_1799 getResult(class_5321<class_8054> trimMaterialResourceKey, class_5455 registryAccess, BRBBookCategories.Category category) {
        Optional<class_6880.class_6883<class_8054>> material = registryAccess.method_30530(class_7924.field_42083).method_40264(trimMaterialResourceKey);
        Optional<class_6880.class_6883<class_8056>> trim = class_8057.method_48448(registryAccess, this.getTemplate().method_8105()[0]);

        class_1799 itemStack = this.itemStackBase.method_7972();

        if (material.isPresent() && trim.isPresent()) {
            class_8053 armorTri = new class_8053(material.get(), trim.get());
            itemStack.method_57379(class_9334.field_49607, armorTri);
        }

        return itemStack;
    }

    @Override
    public class_1799 getBase() {
        return this.itemStackBase;
    }

    @Override
    public class_1856 getTemplate() {
        return ((SmithingTrimRecipeAccessor) this).getUnderlyingTemplate();
    }

    @Override
    public class_1856 getAddition() {
        return ((SmithingTrimRecipeAccessor) this).getUnderlyingAddition();
    }
}
