package com.alonie.brbe.recipe;

import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.generic.GenericRecipe;
import java.util.List;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_7923;
import net.minecraft.class_8054;
import net.minecraft.class_8059;
import net.minecraft.class_9334;

public interface BRBSmithingRecipe extends class_8059, GenericRecipe {
    class_1799 getResult(class_5455 registryAccess, BRBBookCategories.Category category);

    class_1799 getResult(class_5321<class_8054> trimMaterialResourceKey, class_5455 registryAccess, BRBBookCategories.Category category);

    class_1856 getTemplate();

    class_1799 getBase();

    class_1856 getAddition();

    default boolean hasMaterials(class_2371<class_1735> slots, class_5455 registryAccess) {
        return hasTemplate(slots) && hasBase(slots, registryAccess) && hasAddition(slots);
    }

    default boolean hasTemplate(List<class_1735> slots) {
        for (class_1735 slot : slots) {
            if (this.getTemplate().method_8093(slot.method_7677())) return true;
        }
        return false;
    }

    default boolean hasBase(List<class_1735> slots, class_5455 registryAccess) {
        for (class_1735 slot : slots) {
            if (!slot.method_7677().method_57826(class_9334.field_49607) && getBase().method_7909().equals(slot.method_7677().method_7909()))
                return true;
        }
        return false;
    }

    default boolean hasAddition(List<class_1735> slots) {
        for (class_1735 slot : slots) {
            if (getAddition().method_8093(slot.method_7677())) return true;
        }
        return false;
    }

    default String getTemplateType() {
        var tipCtx = class_1792.class_9635.method_59528(class_310.method_1551().field_1724.method_37908());
        return getTemplate().method_8105()[0].method_7950(tipCtx, class_310.method_1551().field_1724, class_1836.field_41070).get(1).getString();
    }

    default class_2960 id() {
        return class_7923.field_41178.method_10221(getTemplate().method_8105()[0].method_7909());
    }

    @Override
    default String getSearchString(BRBBookCategories.Category category) {
        return this.getTemplateType();
    }
}
