package com.alonie.brbe.brewingstand;

import com.google.common.collect.Lists;
import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.generic.GenericRecipeBookCollection;
import com.alonie.brbe.generic.pins.Pinnable;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1708;
import net.minecraft.class_1735;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_5455;

public class BrewingRecipeCollection extends GenericRecipeBookCollection<BrewableResult, class_1708> implements Pinnable {
    private final BRBBookCategories.Category category;

    public BrewingRecipeCollection(List<BrewableResult> list, class_1708 menu, class_5455 registryAccess, BRBBookCategories.Category category) {
        super(list, menu, registryAccess);

        this.category = category;
    }

    public List<BrewableResult> getDisplayRecipes(boolean craftable) {
        List<BrewableResult> list = Lists.newArrayList();

        for (BrewableResult recipe : this.recipes) {
            if (recipe.hasMaterials(this.category, this.menu.field_7761) == craftable) {
                list.add(recipe);
            }
        }

        return list;
    }

    @Override
    public boolean has(class_2960 resourceLocation) {
        for (BrewableResult recipe : this.recipes) {
            if (recipe.id().equals(resourceLocation)) {
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean atleastOneCraftable(class_2371<class_1735> slots) {
        for (BrewableResult recipe : this.recipes) {
            if (recipe.hasMaterials(this.category, slots)) {
                return true;
            }
        }

        return false;
    }

    @Override
    protected boolean atleastOnePartiallyCraftable(class_2371<class_1735> slots) {
        for (BrewableResult recipe : this.recipes) {
            if (!recipe.hasMaterials(this.category, slots)) {
                boolean hasIngredient = recipe.hasIngredient(slots);
                boolean hasInput = recipe.hasInput(this.category, slots);
                if ((hasIngredient || hasInput) && !(hasIngredient && hasInput)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public List<BrewableResult> getPartiallyCraftableRecipes(class_2371<class_1735> slots) {
        List<BrewableResult> partial = new ArrayList<>();
        for (BrewableResult recipe : this.recipes) {
            if (!recipe.hasMaterials(this.category, slots)) {
                boolean hasIngredient = recipe.hasIngredient(slots);
                boolean hasInput = recipe.hasInput(this.category, slots);
                if ((hasIngredient || hasInput) && !(hasIngredient && hasInput)) {
                    partial.add(recipe);
                }
            }
        }
        return partial;
    }
}
