package com.alonie.brbe;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.alonie.brbe.generic.GenericRecipe;
import com.alonie.brbe.generic.GenericRecipeBookCollection;
import com.alonie.brbe.generic.pins.Pinnable;
import com.alonie.brbe.mixins.accessors.RecipeBookComponentAccessor;
import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_507;
import net.minecraft.class_513;
import net.minecraft.class_516;
import net.minecraft.class_518;
import net.minecraft.class_8786;

public class PinnedRecipeManager {
    public HashSet<class_2960> pinned;

    public void read() {
        Gson gson = new Gson();
        JsonReader reader = null;

        try {
            File pinsFile = new File(class_310.method_1551().field_1697, BetterRecipeBook.MOD_ID + ".pins");

            if (pinsFile.exists()) {
                reader = new JsonReader(new FileReader(pinsFile.getAbsolutePath()));
                Type type = new TypeToken<HashSet<class_2960>>() {
                }.getType();
                pinned = gson.fromJson(reader, type);
            }
        } catch (Throwable var8) {
            BetterRecipeBook.LOGGER.error(BetterRecipeBook.MOD_ID + ".pins could not be read.");
        } finally {
            if (pinned == null) {
                pinned = new HashSet<>();
            }
            IOUtils.closeQuietly(reader);
        }
    }

    private void store() {
        Gson gson = new Gson();
        OutputStreamWriter writer = null;

        try {
            File pinsFile = new File(class_310.method_1551().field_1697, BetterRecipeBook.MOD_ID + ".pins");
            writer = new OutputStreamWriter(new FileOutputStream(pinsFile), StandardCharsets.UTF_8);
            writer.write(gson.toJson(this.pinned));
        } catch (Throwable var8) {
            BetterRecipeBook.LOGGER.error(BetterRecipeBook.MOD_ID + ".pins could not be saved.");
        } finally {
            IOUtils.closeQuietly(writer);
        }
    }

    public void addOrRemoveFavourite(class_516 target) {
        for (class_2960 identifier : this.pinned) {
            for (class_8786<?> recipe : target.method_2650()) {
                if (recipe.comp_1932().equals(identifier)) {
                    this.pinned.remove(identifier);
                    this.store();
                    return;
                }
            }
        }

        this.pinned.addAll(target.method_2650().stream().map(class_8786::comp_1932).toList());
        this.store();
    }

    public <R extends GenericRecipe, M extends class_1703> void addOrRemoveFavourite(GenericRecipeBookCollection<R, M> target) {
        for (class_2960 identifier : this.pinned) {
            for (R recipe : target.getRecipes()) {
                if (recipe.id().equals(identifier)) {
                    this.pinned.remove(identifier);
                    this.store();
                    return;
                }
            }
        }

        this.pinned.addAll(target.getRecipes().stream().map(R::id).toList());
        this.store();
    }

    public boolean has(Pinnable target) {
        for (class_2960 identifier : this.pinned) {
            if (target.has(identifier)) {
                return true;
            }
        }

        return false;
    }

    public static void handlePinRecipe(class_507 book, class_513 page, class_8786<?> recipe) {
        class_516 collection = new class_516(class_310.method_1551().field_1687.method_30349(), List.of(recipe));
        collection.method_2647(page.method_2633());
        BetterRecipeBook.pinnedRecipeManager.addOrRemoveFavourite(collection);
        ((RecipeBookComponentAccessor) book).updateCollectionsInvoker(false);
        if (class_310.method_1551().field_1755 instanceof class_518 rul) {
            rul.method_16891();
        }
    }

}
