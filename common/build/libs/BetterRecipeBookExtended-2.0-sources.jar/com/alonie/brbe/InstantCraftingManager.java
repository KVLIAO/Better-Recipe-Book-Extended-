package com.alonie.brbe;

import net.minecraft.class_1269;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_361;
import net.minecraft.class_465;
import net.minecraft.class_516;
import net.minecraft.class_5455;
import net.minecraft.class_8786;

public class InstantCraftingManager {

    // used to signify the last clicked crafted recipe before updateCollections was called
    public class_8786<?> lastClickedRecipe = null;
    // updated by RecipeBookPageMixin
    public class_516 lastHoveredCollection = null;

    // used to update toggle state of button when config reloads
    public class_361 lastInstantCraftButton = null;

    public class_1799 lastCraftResult;
    public long lastContainerId = -1;

    public InstantCraftingManager() {
        BetterRecipeBook.configHolder.registerLoadListener((h, c) -> {
            if (lastInstantCraftButton != null) lastInstantCraftButton.method_1964(isEnabled());
            return class_1269.field_5812;
        });
        BetterRecipeBook.configHolder.registerSaveListener((h, c) -> {
            if (lastInstantCraftButton != null) lastInstantCraftButton.method_1964(isEnabled());
            return class_1269.field_5812;
        });
    }

    public void recipeClicked(class_8786<?> recipe, class_5455 registryAccess) {
        if (isEnabled()) {
            class_310 client = class_310.method_1551();
            if (!(client.field_1755 instanceof class_465<?> screen)) return;

            // Keep buttons stationary - remember last recipe clicked, so we know which one to display
            lastClickedRecipe = recipe;
            // Set last craft for onResultSlotUpdated
            lastCraftResult = recipe.comp_1933().method_8110(registryAccess);
            // there is no way to know for sure when (or if) the server will set the result item, so we'll ignore results from different containerIds
            lastContainerId = screen.method_17577().field_7763;
        } else {
            // if instantcraft was disabled and another recipe was clicked, clear the last pending instantcraft
            lastCraftResult = null;
        }
    }

    public void onResultSlotUpdated(class_1799 itemStack) {
        class_310 client = class_310.method_1551();
        if (!isEnabled()
                || client.field_1761 == null
                || !(client.field_1755 instanceof class_465<?> screen)) return;

        if (lastCraftResult == null
                || !class_1799.method_31577(itemStack, lastCraftResult)
                || lastContainerId != screen.method_17577().field_7763) return;

        client.field_1761.method_2906(screen.method_17577().field_7763, 0, 0, class_1713.field_7794, client.field_1724);
        lastCraftResult = null;
    }

    public boolean toggleEnabled() {
        BetterRecipeBook.config.instantCraft.enabled = !BetterRecipeBook.config.instantCraft.enabled;
        BetterRecipeBook.configHolder.save();
        return isEnabled();
    }

    public boolean isEnabled() {
        return BetterRecipeBook.config.instantCraft.enabled;
    }

}
