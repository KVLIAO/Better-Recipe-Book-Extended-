package com.alonie.brbe.util;

import com.alonie.brbe.mixins.accessors.RecipeCollectionAccessor;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.class_1867;
import net.minecraft.class_1869;
import net.minecraft.class_2960;
import net.minecraft.class_516;
import net.minecraft.class_8786;

public final class IncompatibleCraftingUtil {
    private static final WeakHashMap<class_516, Set<class_2960>> INCOMPATIBLE_RECIPES = new WeakHashMap<>();
    private static final WeakHashMap<class_516, Integer> CHECKED_COLLECTIONS = new WeakHashMap<>();
    private static int filteringGeneration;
    private static boolean filteringActive;

    private IncompatibleCraftingUtil() {}

    public static boolean isActive() {
        return filteringActive;
    }

    public static void beginFiltering(boolean active) {
        filteringActive = active;
        if (active) filteringGeneration++;
    }

    public static void markIncompatibleRecipes(class_516 collection) {
        CHECKED_COLLECTIONS.put(collection, filteringGeneration);
        Set<class_2960> incompatible = null;
        RecipeCollectionAccessor accessor = (RecipeCollectionAccessor) collection;

        for (class_8786<?> holder : collection.method_2650()) {
            if (holder.comp_1933() instanceof class_1869 shaped) {
                if (shaped.method_8150() > 2 || shaped.method_8158() > 2) {
                    if (incompatible == null) incompatible = new HashSet<>();
                    incompatible.add(holder.comp_1932());
                    accessor.getFitsDimensions().add(holder);
                }
            } else if (holder.comp_1933() instanceof class_1867 shapeless) {
                if (shapeless.method_8117().size() > 4) {
                    if (incompatible == null) incompatible = new HashSet<>();
                    incompatible.add(holder.comp_1932());
                    accessor.getFitsDimensions().add(holder);
                }
            }
        }

        if (incompatible != null && !incompatible.isEmpty()) {
            INCOMPATIBLE_RECIPES.put(collection, incompatible);
        } else {
            INCOMPATIBLE_RECIPES.remove(collection);
        }
    }

    public static void markIncompatibleOnCollection(class_516 collection, class_2960 id) {
        CHECKED_COLLECTIONS.put(collection, filteringGeneration);
        Set<class_2960> existing = INCOMPATIBLE_RECIPES.get(collection);
        if (existing != null) {
            existing.add(id);
        } else {
            INCOMPATIBLE_RECIPES.put(collection, new HashSet<>(Collections.singleton(id)));
        }
    }

    public static boolean isIncompatible(class_516 collection, class_2960 id) {
        Set<class_2960> set = INCOMPATIBLE_RECIPES.get(collection);
        return set != null && set.contains(id);
    }

    public static boolean checkIncompatible(class_516 collection, class_2960 id) {
        for (class_8786<?> holder : collection.method_2650()) {
            if (!holder.comp_1932().equals(id)) continue;
            if (holder.comp_1933() instanceof class_1869 shaped)
                return shaped.method_8150() > 2 || shaped.method_8158() > 2;
            if (holder.comp_1933() instanceof class_1867 shapeless)
                return shapeless.method_8117().size() > 4;
            return false;
        }
        return false;
    }

    public static boolean hasIncompatibleRecipes(class_516 collection) {
        Set<class_2960> set = INCOMPATIBLE_RECIPES.get(collection);
        return set != null && !set.isEmpty();
    }
}
