package com.alonie.brbe.util;

import com.alonie.brbe.interfaces.TopLayerOverlayProvider;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_8030;

public final class TopLayerOverlayRenderer {
    private TopLayerOverlayRenderer() {
    }

    public static boolean hasOverlay(class_437 screen) {
        if (screen instanceof TopLayerOverlayProvider provider) {
            return provider.betterRecipeBook$hasTopLayerOverlay();
        }

        return false;
    }

    public static void render(class_437 screen, class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (screen instanceof TopLayerOverlayProvider provider) {
            if (provider.betterRecipeBook$hasTopLayerOverlay()) {
                provider.betterRecipeBook$renderTopLayerOverlay(guiGraphics, mouseX, mouseY, partialTick);
            }
        }
    }

    public static class_8030 getOverlayBounds(class_437 screen) {
        if (screen instanceof TopLayerOverlayProvider provider) {
            return provider.betterRecipeBook$getTopLayerOverlayBounds();
        }
        return null;
    }
}
