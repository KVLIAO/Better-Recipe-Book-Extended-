package com.alonie.brbe.util;

import dev.architectury.platform.Platform;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

public final class ModNameUtil {
    private ModNameUtil() {
    }

    public static class_2561 getFormattedModName(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return class_2561.method_43473();
        }

        String namespace = class_7923.field_41178.method_10221(stack.method_7909()).method_12836();
        String modName = resolveModName(namespace);
        return class_2561.method_43470(modName).method_27695(class_124.field_1078, class_124.field_1056);
    }

    public static String resolveModName(String namespace) {
        String jadeKey = "jade.modName." + namespace;
        if (class_1074.method_4663(jadeKey)) {
            return class_1074.method_4662(jadeKey);
        }

        try {
            if (Platform.isModLoaded(namespace)) {
                String modName = Platform.getMod(namespace).getName();
                if (modName != null && !modName.isEmpty()) {
                    return modName;
                }
            }
        } catch (Exception ignored) {
        }

        return namespace;
    }
}
