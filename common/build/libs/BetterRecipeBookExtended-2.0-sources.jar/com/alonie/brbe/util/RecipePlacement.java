package com.alonie.brbe.util;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1856;
import net.minecraft.class_2952;
import net.minecraft.class_8786;

public class RecipePlacement implements class_2952<class_1856> {

    protected List<List<class_1856>> placement = new ArrayList<>();

    public RecipePlacement(int size) {
        for (int i = 0; i < size; i++) placement.add(new ArrayList<>());
    }

    @Override
    public void addItemToSlot(class_1856 ingredient, int menuSlot, int j, int k, int l) {
        if (!ingredient.method_8103() && menuSlot < placement.size()) {
            placement.get(menuSlot).add(ingredient);
        }
    }

    public List<List<class_1856>> getPlacement() {
        return placement;
    }

    public static List<List<class_1856>> create(class_8786<?> recipe, int gridWidth, int gridHeight) {
        RecipePlacement placer = new RecipePlacement(gridWidth * gridHeight);
        placer.method_12816(gridWidth, gridHeight, -1, recipe, recipe.comp_1933().method_8117().iterator(), 0);
        return placer.getPlacement();
    }
}
