package com.alonie.brbe.util;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_1863;
import net.minecraft.class_299;
import net.minecraft.class_310;
import net.minecraft.class_518;
import net.minecraft.class_746;

public class RecipeUnlockUtil {

    public static void unlockRecipesIfRequired() {
        if (BetterRecipeBook.config.newRecipes.unlockAll) {
            unlockRecipes();
        }
    }

    public static void syncToConfig() {
        if (BetterRecipeBook.config.newRecipes.unlockAll) {
            unlockRecipes();
        }
    }

    /**
     * Unlocks all recipes that the RecipeManager knows of, then updates any screen implementing RecipeUpdateListener
     */
    public static void unlockRecipes() {
        class_310 minecraft = class_310.method_1551();
        class_746 player = minecraft.field_1724;
        if (player == null || player.field_3944 == null) {
            return;
        }

        class_1863 recipeManager = player.field_3944.method_2877();
        class_299 recipeBook = player.method_3130();
        recipeManager.method_8126().forEach(recipeBook::method_14876);
        recipeBook.method_1393().forEach(recipeCollection -> recipeCollection.method_2647(recipeBook));
        if (minecraft.field_1755 instanceof class_518 rul) {
            rul.method_16891();
        }
    }

}
