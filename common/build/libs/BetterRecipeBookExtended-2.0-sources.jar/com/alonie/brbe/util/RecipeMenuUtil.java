package com.alonie.brbe.util;

import net.minecraft.class_1720;
import net.minecraft.class_1729;

public class RecipeMenuUtil {

    public static boolean isRecipeSlot(class_1729<?, ?> menu, int slot) {
        if (menu instanceof class_1720) {
            return class_1720.field_30738 == slot;
        } else {
            return isCraftingGridSlot(menu, slot);
        }
    }

    public static boolean isCraftingGridSlot(class_1729<?, ?> menu, int slot) {
        return slot > menu.method_7655() && slot < menu.method_7658();
    }

    public static boolean isResultSlot(class_1729<?, ?> menu, int slot) {
        return menu.method_7655() == slot;
    }

    public static boolean isCraftingMenuSlot(class_1729<?, ?> menu, int slot) {
        return isCraftingGridSlot(menu, slot) || isResultSlot(menu, slot);
    }

}
