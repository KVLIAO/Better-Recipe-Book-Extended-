package com.alonie.brbe.util;

import com.mojang.datafixers.util.Pair;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.api.BRBBookSettings;

public class BRBHelper {
    public static Book createBook(String mod_id, String name) {
        class_2960 location = class_2960.method_60655(mod_id, name);

        String hash = location + "#";
        Pair<String, String> pair = new Pair<>(hash + "isGuiOpen", hash + "isFiltering");

        Book book = new Book(
                location,
                pair
        );

        BRBBookSettings.registerBook(book);

        return book;
    }

    static public class Book {
        public class_2960 resourceLocation;
        public Pair<String, String> pair;

        Book(class_2960 resourceLocation, Pair<String, String> pair) {
            this.resourceLocation = resourceLocation;
            this.pair = pair;
        }

        public BRBBookCategories.Category createCategory(class_1799... entries) {
            return BRBBookCategories.createCategory(this, entries);
        }

        public BRBBookCategories.Category createSearch() {
            return BRBBookCategories.createSearch(this);
        }
    }
}
