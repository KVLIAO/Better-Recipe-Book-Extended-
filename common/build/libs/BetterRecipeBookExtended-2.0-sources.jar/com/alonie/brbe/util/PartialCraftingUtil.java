package com.alonie.brbe.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.class_1735;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_516;
import net.minecraft.class_8786;

public final class PartialCraftingUtil {
    private static final WeakHashMap<class_516, Set<class_2960>> PARTIAL_RECIPES = new WeakHashMap<>();
    private static final WeakHashMap<class_516, Integer> CHECKED_COLLECTIONS = new WeakHashMap<>();
    private static int filteringGeneration;
    private static boolean filteringActive;

    private PartialCraftingUtil() {
    }

    public static void beginFilteringUpdate(boolean active) {
        filteringActive = active;
        if (active) {
            filteringGeneration++;
        }
    }

    /**
     * Checks all recipes in the collection and marks those that have some (but not all) matching ingredients.
     */
    public static boolean markPartialMaterials(class_516 collection, class_2371<class_1735> slots) {
        CHECKED_COLLECTIONS.put(collection, filteringGeneration);
        boolean markedAny = false;
        Set<class_2960> partialRecipes = new HashSet<>();

        for (class_8786<?> recipe : collection.method_2650()) {
            // Skip recipes that are already fully craftable
            if (collection.method_2653(recipe)) {
                continue;
            }

            class_1860<?> vanillaRecipe = recipe.comp_1933();
            if (hasMatchingIngredient(vanillaRecipe.method_8117(), slots)) {
                partialRecipes.add(recipe.comp_1932());
                markedAny = true;
            }
        }

        if (markedAny) {
            PARTIAL_RECIPES.put(collection, partialRecipes);
        } else {
            PARTIAL_RECIPES.remove(collection);
        }

        return markedAny;
    }

    public static void markPartialMaterial(class_516 collection, class_2960 recipeId) {
        PARTIAL_RECIPES.put(collection, new HashSet<>(Collections.singleton(recipeId)));
        CHECKED_COLLECTIONS.put(collection, filteringGeneration);
    }

    public static boolean wasCheckedForPartialMaterials(class_516 collection) {
        Integer generation = CHECKED_COLLECTIONS.get(collection);
        return filteringActive && generation != null && generation == filteringGeneration;
    }

    public static boolean isPartiallyCraftable(class_516 collection, class_8786<?> recipe) {
        return isPartiallyCraftable(collection, recipe.comp_1932());
    }

    public static boolean isPartiallyCraftable(class_516 collection, class_2960 recipeId) {
        Set<class_2960> partialRecipes = PARTIAL_RECIPES.get(collection);
        return partialRecipes != null && partialRecipes.contains(recipeId);
    }

    public static boolean hasPartialMaterials(class_516 collection) {
        Set<class_2960> partialRecipes = PARTIAL_RECIPES.get(collection);
        return partialRecipes != null && !partialRecipes.isEmpty();
    }

    public static void sortCraftableBeforePartial(List<class_516> collections) {
        List<class_516> craftableCollections = new ArrayList<>();
        List<class_516> partialCollections = new ArrayList<>();

        for (class_516 collection : collections) {
            if (collection.method_2655()) {
                craftableCollections.add(collection);
            } else {
                partialCollections.add(collection);
            }
        }

        collections.clear();
        collections.addAll(craftableCollections);
        collections.addAll(partialCollections);
    }

    public static List<class_8786<?>> getPartiallyCraftableRecipes(class_516 collection) {
        Set<class_2960> partialRecipes = PARTIAL_RECIPES.get(collection);
        if (partialRecipes == null || partialRecipes.isEmpty()) {
            return Collections.emptyList();
        }

        List<class_8786<?>> recipes = new ArrayList<>();
        for (class_8786<?> recipe : collection.method_2650()) {
            if (partialRecipes.contains(recipe.comp_1932())) {
                recipes.add(recipe);
            }
        }

        return recipes;
    }

    private static boolean hasMatchingIngredient(List<class_1856> ingredients, class_2371<class_1735> slots) {
        for (class_1856 ingredient : ingredients) {
            if (ingredient.method_8103()) {
                continue;
            }

            for (class_1735 slot : slots) {
                if (slot.method_7681() && ingredient.method_8093(slot.method_7677())) {
                    return true;
                }
            }
        }

        return false;
    }
}
