package com.alonie.brbe.generic.pins;

import net.minecraft.class_2960;

public interface Pinnable {
    boolean has(class_2960 resourceLocation);
}
