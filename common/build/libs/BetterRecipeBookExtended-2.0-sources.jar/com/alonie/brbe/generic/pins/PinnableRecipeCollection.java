package com.alonie.brbe.generic.pins;

import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_516;
import net.minecraft.class_5455;
import net.minecraft.class_8786;

public class PinnableRecipeCollection extends class_516 implements Pinnable {
    public PinnableRecipeCollection(class_5455 registryAccess, List<class_8786<?>> list) {
        super(registryAccess, list);
    }

    static public PinnableRecipeCollection of(class_516 collection) {
        return new PinnableRecipeCollection(collection.method_48479(), collection.method_2650());
    }

    @Override
    public boolean has(class_2960 resourceLocation) {
        for (class_8786<?> recipe : method_2650()) {
            if (recipe.comp_1932().equals(resourceLocation)) {
                return true;
            }
        }
        return false;
    }
}
