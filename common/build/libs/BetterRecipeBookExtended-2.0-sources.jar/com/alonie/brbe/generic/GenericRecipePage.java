package com.alonie.brbe.generic;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.util.BRBTextures;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_1703;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_361;
import net.minecraft.class_5455;

public class GenericRecipePage<M extends class_1703, C extends GenericRecipeBookCollection<R, M>, R extends GenericRecipe> {
    protected final class_5455 registryAccess;
    protected M menu;
    protected class_310 minecraft;
    protected int parentLeft;
    protected int parentTop;
    protected class_361 forwardButton;
    protected class_361 backButton;
    protected List<C> recipeCollections = ImmutableList.of();
    protected C lastClickedRecipeCollection;
    protected R lastClickedRecipe;
    protected BRBBookCategories.Category category;
    protected int totalPages;
    protected int currentPage;
    private final List<GenericRecipeButton<C, R, M>> buttons = Lists.newArrayListWithCapacity(20);

    public List<GenericRecipeButton<C, R, M>> getButtons() {
        return buttons;
    }
    protected GenericRecipeButton<C, R, M> hoveredButton;

    public GenericRecipePage(class_5455 registryAccess, Supplier<GenericRecipeButton<C, R, M>> recipeButtonSupplier) {
        this.registryAccess = registryAccess;

        for (int i = 0; i < 20; ++i) {
            this.buttons.add(recipeButtonSupplier.get());
        }
    }

    protected void initialize(class_310 client, int parentLeft, int parentTop, M menu, int leftOffset) {
        this.minecraft = client;
        this.menu = menu;

        this.parentLeft = parentLeft;
        this.parentTop = parentTop;

        this.forwardButton = new class_361(parentLeft + 93, parentTop + 137, 12, 17, false);
        this.forwardButton.method_1962(BRBTextures.RECIPE_BOOK_PAGE_FORWARD_SPRITES);
        this.backButton = new class_361(parentLeft + 38, parentTop + 137, 12, 17, true);
        this.backButton.method_1962(BRBTextures.RECIPE_BOOK_PAGE_BACKWARD_SPRITES);

        for (int k = 0; k < this.buttons.size(); ++k) {
            this.buttons.get(k).method_48229(parentLeft + 11 + 25 * (k % 5), parentTop + 31 + 25 * (k / 5));
        }
    }

    protected boolean overlayMouseClicked(double mouseX, double mouseY, int button, int j, int k, int l, int m) {
        return false;
    }

    protected void initOverlay(C recipeCollection, int x, int y, class_5455 registryAccess) {
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button, int j, int k, int l, int m) {
        this.lastClickedRecipe = null;
        this.lastClickedRecipeCollection = null;

        if (overlayIsVisible() && overlayMouseClicked(mouseX, mouseY, button, j, k, l, m)) {
            return true;
        }

        if (this.forwardButton.method_25402(mouseX, mouseY, button)) {
            if (++currentPage >= totalPages) {
                currentPage = BetterRecipeBook.config.scrolling.scrollAround ? 0 : totalPages - 1;
            }
            this.updateButtonsForPage();
            return true;
        } else if (this.backButton.method_25402(mouseX, mouseY, button)) {
            if (--currentPage < 0) {
                currentPage = BetterRecipeBook.config.scrolling.scrollAround ? totalPages - 1 : 0;
            }
            this.updateButtonsForPage();
            return true;
        } else {
            for (GenericRecipeButton<C, R, M> recipeButton : this.buttons) {
                if (!recipeButton.method_25402(mouseX, mouseY, button)) continue;
                if (button == 0) {
                    this.lastClickedRecipe = recipeButton.getCurrentDisplayedRecipe();
                    this.lastClickedRecipeCollection = recipeButton.getCollection();
                } else if (button == 1 && !overlayIsVisible() && !recipeButton.isOnlyOption()) {
                    this.initOverlay(recipeButton.getCollection(), this.parentLeft, this.parentTop, registryAccess);
                }
                return true;
            }
        }
        return false;
    }

    public void updateButtonsForPage() {
        int i = 20 * this.currentPage;

        for (int j = 0; j < this.buttons.size(); ++j) {
            var button = this.buttons.get(j);
            if (i + j < this.recipeCollections.size()) {
                C output = this.recipeCollections.get(i + j);
                button.showCollection(output, menu, this.category);
                button.field_22764 = true;
            } else {
                button.field_22764 = false;
            }
        }

        this.updateArrowButtons();
    }

    protected boolean overlayIsVisible() {
        return false;
    }

    protected void render(class_332 gui, int blitX, int blitY, int mouseX, int mouseY, float delta) {
        if (BetterRecipeBook.getQueuedScroll() != 0 && BetterRecipeBook.config.scrolling.enableScrolling) {
            if (isMouseOverRecipeBookPage(mouseX, mouseY, blitX, blitY) && totalPages > 1) {
                currentPage += BetterRecipeBook.getQueuedScroll();
                if (currentPage >= totalPages) {
                    currentPage = BetterRecipeBook.config.scrolling.scrollAround ? currentPage % totalPages : totalPages - 1;
                } else if (currentPage < 0) {
                    currentPage = BetterRecipeBook.config.scrolling.scrollAround ? (currentPage % totalPages) + totalPages : 0;
                }

                updateButtonsForPage();
            }
            BetterRecipeBook.setQueuedScroll(0);
        }

        if (this.totalPages > 1) {
            String string = this.currentPage + 1 + "/" + this.totalPages;
            int width = this.minecraft.field_1772.method_1727(string);
            gui.method_51433(this.minecraft.field_1772, string, blitX - width / 2 + 73, blitY + 141, -1, false);
        }

        this.hoveredButton = null;

        for (var button : this.buttons) {
            button.method_25394(gui, mouseX, mouseY, delta);
            if (button.field_22764 && button.method_25367()) {
                this.hoveredButton = button;
            }
        }

        this.backButton.method_25394(gui, mouseX, mouseY, delta);
        this.forwardButton.method_25394(gui, mouseX, mouseY, delta);
    }

    private static boolean isMouseOverRecipeBookPage(int mouseX, int mouseY, int left, int top) {
        return mouseX >= left && mouseX < left + 147 && mouseY >= top && mouseY < top + 166;
    }

    public void setResults(List<C> recipeCollection, boolean resetCurrentPage, BRBBookCategories.Category category) {
        this.recipeCollections = recipeCollection;
        this.category = category;

        this.totalPages = (int) Math.ceil((double) recipeCollection.size() / 20.0D);
        if (this.totalPages <= this.currentPage || resetCurrentPage) {
            this.currentPage = 0;
        }

        this.updateButtonsForPage();
    }

    @Nullable
    public R getCurrentClickedRecipe() {
        return this.lastClickedRecipe;
    }

    @Nullable
    public C getLastClickedRecipeCollection() {
        return this.lastClickedRecipeCollection;
    }

    protected void updateArrowButtons() {
        if (BetterRecipeBook.config.scrolling.scrollAround && totalPages > 1) {
            forwardButton.field_22764 = true;
            backButton.field_22764 = true;
        } else {
            forwardButton.field_22764 = totalPages > 1 && currentPage < totalPages - 1;
            backButton.field_22764 = totalPages > 1 && currentPage > 0;
        }
    }

    public void drawTooltip(class_332 gui, int x, int y) {
        if (this.minecraft.field_1755 != null && hoveredButton != null) {
            gui.method_51434(class_310.method_1551().field_1772, this.hoveredButton.getTooltipText(), x, y);
        }
    }
}
