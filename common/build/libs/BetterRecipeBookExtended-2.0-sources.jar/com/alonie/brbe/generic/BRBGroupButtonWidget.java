package com.alonie.brbe.generic;

import com.mojang.blaze3d.systems.RenderSystem;
import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.util.BRBTextures;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_361;
import net.minecraft.class_918;

public class BRBGroupButtonWidget extends class_361 {
    protected BRBBookCategories.Category category;

    public BRBGroupButtonWidget(BRBBookCategories.Category category) {
        super(0, 0, 35, 27, false);
        this.category = category;
        this.method_1962(BRBTextures.RECIPE_BOOK_TAB_SPRITES);
    }

    public void method_48579(class_332 gui, int mouseX, int mouseY, float delta) {
        class_310 minecraftClient = class_310.method_1551();

        class_2960 sprite = this.field_45390.method_52729(true, this.field_2194);
        int x = method_46426();
        if (this.field_2194) {
            x -= 2;
        }

        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        gui.method_52706(sprite, x, this.method_46427(), this.field_22758, this.field_22759);
        RenderSystem.enableDepthTest();

        this.renderIcons(gui, minecraftClient.method_1480());
    }

    private void renderIcons(class_332 guiGraphics, class_918 itemRenderer) {
        List<class_1799> list = this.category.getItemIcons();
        int i = this.field_2194 ? -2 : 0;
        if (list.size() == 1) {
            guiGraphics.method_51445(list.get(0), method_46426() + 9 + i, method_46427() + 5);
        } else if (list.size() == 2) {
            guiGraphics.method_51445(list.get(0), method_46426() + 3 + i, method_46427() + 5);
            guiGraphics.method_51445(list.get(1), method_46426() + 14 + i, method_46427() + 5);
        }

    }

    public BRBBookCategories.Category getCategory() {
        return this.category;
    }
}
