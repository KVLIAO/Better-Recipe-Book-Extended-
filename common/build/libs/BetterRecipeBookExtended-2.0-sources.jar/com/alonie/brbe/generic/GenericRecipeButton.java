package com.alonie.brbe.generic;

import com.google.common.collect.Lists;
import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.mixins.accessors.KeyMappingAccessor;
import com.alonie.brbe.util.BRBTextures;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5455;
import net.minecraft.class_6382;

public class GenericRecipeButton<C extends GenericRecipeBookCollection<R, M>, R extends GenericRecipe, M extends class_1703> extends class_339 {
    private final Supplier<Boolean> filteringSupplier;
    protected C collection;
    protected M menu;
    protected float time;
    protected int currentIndex;
    protected class_5455 registryAccess;
    protected BRBBookCategories.Category category;

    public GenericRecipeButton(class_5455 registryAccess, Supplier<Boolean> filteringSupplier) {
        super(0, 0, 25, 25, class_5244.field_39003);
        this.registryAccess = registryAccess;
        this.filteringSupplier = filteringSupplier;
    }

    public void showCollection(C collection, M smithingMenu, BRBBookCategories.Category category) {
        this.collection = collection;
        this.menu = smithingMenu;
        this.category = category;
    }

    public void method_48579(class_332 gui, int mouseX, int mouseY, float delta) {
        if (!class_437.method_25441()) {
            this.time += delta;
        }

        List<R> list = getOrderedRecipes();

        if (list.isEmpty()) {
            return;
        }

        this.currentIndex = class_3532.method_15375(this.time / 30.0F) % list.size();

        // blit outline texture
        class_2960 outlineTexture = collection.atleastOneCraftable(menu.field_7761) ?
                BRBTextures.RECIPE_BOOK_BUTTON_SLOT_CRAFTABLE_SPRITE : BRBTextures.RECIPE_BOOK_BUTTON_SLOT_UNCRAFTABLE_SPRITE;
        gui.method_52706(outlineTexture, method_46426(), method_46427(), this.field_22758, this.field_22759);

        // red overlay for partially craftable recipes (always active, drawn before item so item shows on top)
        {
            R current = getCurrentDisplayedRecipe();
            for (R partial : this.collection.getPartiallyCraftableRecipes(this.menu.field_7761)) {
                if (partial.id().equals(current.id())) {
                    gui.method_25294(method_46426() + 1, method_46427() + 1, method_46426() + this.field_22758 - 1, method_46427() + this.field_22759 - 1, 0x60FF3333);
                    break;
                }
            }
        }

        class_1799 result = getCurrentDisplayedRecipe().getResult(registryAccess, category);

        // render ingredient item (on top of red overlay)
        int offset = 4;
        gui.method_51445(result, method_46426() + offset, method_46427() + offset);

        // if pinned recipe, blit the pin texture over it
        if (BetterRecipeBook.config.enablePinning && BetterRecipeBook.pinnedRecipeManager.has(collection)) {
            gui.method_52706(BRBTextures.RECIPE_BOOK_PIN_SPRITE, method_46426() - 4, method_46427() - 4, 32, 32);
        }
    }

    public R getCurrentDisplayedRecipe() {
        List<R> list = getOrderedRecipes();

        return list.get(currentIndex);
    }

    public boolean isOnlyOption() {
        return this.getOrderedRecipes().size() == 1;
    }

    public List<R> getOrderedRecipes() {
        List<R> list = this.getCollection().getDisplayRecipes(true);

        if (!this.filteringSupplier.get()) {
            list.addAll(this.collection.getDisplayRecipes(false));
        } else {
            list.addAll((List<R>) this.collection.getPartiallyCraftableRecipes(this.menu.field_7761));
        }

        return list;
    }

    public C getCollection() {
        return this.collection;
    }

    @Override
    public void method_47399(class_6382 builder) {
//        ItemStack inputStack = this.getCollection().getFirst().inputAsItemStack(group);
//
//        builder.add(NarratedElementType.TITLE, Component.translatable("narration.recipe", inputStack.getHoverName()));
//        builder.add(NarratedElementType.USAGE, Component.translatable("narration.button.usage.hovered"));
    }

    public int method_25368() {
        return 25;
    }

    protected boolean method_25351(int i) {
        return i == 0 || i == 1;
    }

    public List<class_2561> getTooltipText() {
        List<class_2561> list = Lists.newArrayList();

        var tipCtx = class_1792.class_9635.method_59530(registryAccess);
        list.addAll(getCurrentDisplayedRecipe().getResult(registryAccess, category).method_7950(tipCtx, class_310.method_1551().field_1724, class_1836.field_41070));

        this.addPinTooltip(list);

        return list;
    }

    public void addPinTooltip(List<class_2561> list) {
        list.add(class_2561.method_43473());

        if (BetterRecipeBook.config.enablePinning) {
            if (BetterRecipeBook.pinnedRecipeManager.has(collection)) {
                list.add(class_2561.method_43469("brb.gui.pin.remove", ((KeyMappingAccessor) BetterRecipeBook.PIN_MAPPING).getKey().method_27445()));
            } else {
                list.add(class_2561.method_43469("brb.gui.pin.add", ((KeyMappingAccessor) BetterRecipeBook.PIN_MAPPING).getKey().method_27445()));
            }
        }
    }
}
