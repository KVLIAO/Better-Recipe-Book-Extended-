package com.alonie.brbe.smithingtable;

import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.generic.GenericGhostRecipe;
import com.alonie.brbe.mixins.accessors.HolderReferenceAccessor;
import com.alonie.brbe.recipe.BRBSmithingRecipe;
import com.alonie.brbe.recipe.smithing.BRBSmithingTransformRecipe;
import net.minecraft.class_1799;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_8053;
import net.minecraft.class_8054;
import net.minecraft.class_8055;
import net.minecraft.class_8056;
import net.minecraft.class_8057;
import net.minecraft.class_9334;
import net.minecraft.world.item.armortrim.*;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class SmithingGhostRecipe extends GenericGhostRecipe<BRBSmithingRecipe> {
    public SmithingGhostRecipe(@Nullable Consumer<class_1799> onGhostUpdate, class_5455 registryAccess) {
        super(onGhostUpdate, registryAccess);
    }

    @Override
    public class_1799 getCurrentResult(BRBBookCategories.Category category) {
        if (this.recipe == null) {
            return class_1799.field_8037;
        }

        if (this.recipe instanceof BRBSmithingTransformRecipe) {
            return this.recipe.getResult(registryAccess, category);
        }

        class_1799 itemStack = this.recipe.getBase().method_7972();

        Stream<class_6880.class_6883<class_8054>> holders = registryAccess.method_30530(class_7924.field_42083).method_40270();

        Optional<class_6880.class_6883<class_8054>> currentMaterialReference = class_8055.method_48440(registryAccess, this.ingredients.get(0).getItem());

        if (currentMaterialReference.isEmpty()) {
            return itemStack;
        }

        class_6880.class_6883<class_8054> material = holders.filter(holder -> ((HolderReferenceAccessor<class_8054>) holder).getKey().equals(((HolderReferenceAccessor<class_8054>) currentMaterialReference.get()).getKey())).findFirst().get();

        Optional<class_6880.class_6883<class_8056>> trim = class_8057.method_48448(registryAccess, recipe.getTemplate().method_8105()[0]);

        if (trim.isPresent()) {
            class_8053 armorTri = new class_8053(material, trim.get());
            itemStack.method_57379(class_9334.field_49607, armorTri);
        }

        return itemStack;
    }
}
