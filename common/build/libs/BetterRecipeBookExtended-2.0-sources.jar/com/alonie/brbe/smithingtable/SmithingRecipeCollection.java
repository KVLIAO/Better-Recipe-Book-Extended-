package com.alonie.brbe.smithingtable;

import com.google.common.collect.Lists;
import com.alonie.brbe.generic.GenericRecipeBookCollection;
import com.alonie.brbe.recipe.BRBSmithingRecipe;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1735;
import net.minecraft.class_2371;
import net.minecraft.class_4862;
import net.minecraft.class_5455;

public class SmithingRecipeCollection extends GenericRecipeBookCollection<BRBSmithingRecipe, class_4862> {
    public SmithingRecipeCollection(List<? extends BRBSmithingRecipe> list, class_4862 menu, class_5455 registryAccess) {
        super(list, menu, registryAccess);
    }

    public List<BRBSmithingRecipe> getDisplayRecipes(boolean craftable) {
        List<BRBSmithingRecipe> list = Lists.newArrayList();

        for (BRBSmithingRecipe recipe : this.recipes) {
            if (recipe.hasMaterials(this.menu.field_7761, registryAccess) == craftable) {
                list.add(recipe);
            }
        }

        return list;
    }

    @Override
    public boolean atleastOneCraftable(class_2371<class_1735> slots) {
        for (BRBSmithingRecipe recipe : this.recipes) {
            if (recipe.hasMaterials(slots, registryAccess)) {
                return true;
            }
        }

        return false;
    }

    @Override
    protected boolean atleastOnePartiallyCraftable(class_2371<class_1735> slots) {
        for (BRBSmithingRecipe recipe : this.recipes) {
            if (!recipe.hasMaterials(slots, registryAccess)) {
                boolean hasTemplate = recipe.hasTemplate(slots);
                boolean hasBase = recipe.hasBase(slots, registryAccess);
                boolean hasAddition = recipe.hasAddition(slots);
                if ((hasTemplate || hasBase || hasAddition) && !(hasTemplate && hasBase && hasAddition)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public List<BRBSmithingRecipe> getPartiallyCraftableRecipes(class_2371<class_1735> slots) {
        List<BRBSmithingRecipe> partial = new ArrayList<>();
        for (BRBSmithingRecipe recipe : this.recipes) {
            if (!recipe.hasMaterials(slots, registryAccess)) {
                boolean hasTemplate = recipe.hasTemplate(slots);
                boolean hasBase = recipe.hasBase(slots, registryAccess);
                boolean hasAddition = recipe.hasAddition(slots);
                if ((hasTemplate || hasBase || hasAddition) && !(hasTemplate && hasBase && hasAddition)) {
                    partial.add(recipe);
                }
            }
        }
        return partial;
    }
}
