package com.alonie.brbe.interfaces;

import net.minecraft.class_332;
import net.minecraft.class_8030;

public interface TopLayerOverlayProvider {
    boolean betterRecipeBook$hasTopLayerOverlay();

    void betterRecipeBook$renderTopLayerOverlay(class_332 guiGraphics, int mouseX, int mouseY, float partialTick);

    boolean betterRecipeBook$clickTopLayerOverlay(double mouseX, double mouseY, int button);

    class_8030 betterRecipeBook$getTopLayerOverlayBounds();
}
