package com.alonie.brbe.interfaces.unlockrecipes;

import java.util.Set;
import net.minecraft.class_2960;

/**
 * Access interface for RecipeManagerMixin
 */
public interface IMixinRecipeManager {

    Set<class_2960> betterRecipeBook$getServerUnlockedRecipes();

}
