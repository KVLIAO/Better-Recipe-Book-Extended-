package com.alonie.brbe.api;

import com.google.common.collect.ImmutableList;
import com.alonie.brbe.util.BRBHelper;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class BRBBookCategories {
    private static final Map<BRBHelper.Book, List<Category>> categories = new HashMap<>();

    @Nullable
    public static List<Category> getCategories(BRBHelper.Book book) {
        return categories.get(book);
    }

    private static Category createCategory(BRBHelper.Book book, Category.Type type, class_1799... entries) {
        Category category = new Category(type, entries);
        categories.putIfAbsent(book, new ArrayList<>());

        categories.get(book).add(category);

        return category;
    }

    public static Category createCategory(BRBHelper.Book book, @NotNull class_1799... entries) {
        return createCategory(book, Category.Type.OTHER, entries);
    }

    public static Category createSearch(BRBHelper.Book book) {
        return createCategory(book, Category.Type.SEARCH, new class_1799(class_1802.field_8251));
    }

    public static class Category {
        private final List<class_1799> itemIcons;
        private final Type type;

        Category(Type type, class_1799... entries) {
            this.itemIcons = ImmutableList.copyOf(entries);
            this.type = type;
        }

        public List<class_1799> getItemIcons() {
            return this.itemIcons;
        }

        public Type getType() {
            return this.type;
        }

        public enum Type {
            SEARCH,
            OTHER
        }
    }
}
