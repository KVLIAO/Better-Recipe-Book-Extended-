package com.alonie.brbe.mixins.instantcraft;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_310;
import net.minecraft.class_636;
import net.minecraft.class_8786;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_636.class)
public class MultiPlayerGameModeMixin {
    @Shadow @Final private class_310 minecraft;

    @Inject(method = "handlePlaceRecipe", at = @At("TAIL"))
    private void handlePlaceRecipe(int i, class_8786<?> recipe, boolean bl, CallbackInfo ci) {
        BetterRecipeBook.instantCraftingManager.recipeClicked(recipe, minecraft.field_1687.method_30349());
    }
}