package com.alonie.brbe.mixins.incompletecrafting;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.mixins.accessors.RecipeCollectionAccessor;
import com.alonie.brbe.util.IncompatibleCraftingUtil;
import com.alonie.brbe.util.PartialCraftingUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1729;
import net.minecraft.class_310;
import net.minecraft.class_490;
import net.minecraft.class_507;
import net.minecraft.class_513;
import net.minecraft.class_516;
import net.minecraft.class_8786;

/**
 * After updateCollections() runs its internal forEach consumer (which populates
 * craftable + fitsDimensions sets), we inject additional recipes:
 *
 * 1. Partial recipes → craftable set (when partialCraftableEqualsCraftable)
 *    Prevents the craftable filter from removing collections with partial materials.
 *
 * 2. Incompatible (3x3) recipes → fitsDimensions set (when showAllRecipesInSurvival)
 *    Makes getRecipes(false) naturally return them for display and search.
 *
 * Both work at the data layer, so no removeIf/predicate patches are needed.
 */
@Mixin(class_507.class)
public abstract class RecipeBookComponentMixin {
    @Shadow @Final
    protected class_1729<?, ?> menu;

    @Shadow @Final
    protected class_310 minecraft;

    @Redirect(method = "updateCollections", at = @At(value = "INVOKE", target = "Ljava/util/List;forEach(Ljava/util/function/Consumer;)V"))
    private void betterRecipeBook$injectIntoDataSets(
            List<class_516> collections, Consumer<? super class_516> consumer) {
        // Step 1: Run original forEach (populates craftable + fitsDimensions)
        collections.forEach(consumer);

        boolean onInventory = BetterRecipeBook.config.showAllRecipesInSurvival
                && this.minecraft != null
                && this.minecraft.field_1755 instanceof class_490;

        // Step 0: Clear previously-injected partial IDs from craftable set
        // so markPartialMaterials sees the vanilla state of isCraftable()
        for (class_516 collection : collections) {
            if (PartialCraftingUtil.hasPartialMaterials(collection)) {
                RecipeCollectionAccessor accessor = (RecipeCollectionAccessor) collection;
                for (class_8786<?> holder : collection.method_2650()) {
                    if (PartialCraftingUtil.isPartiallyCraftable(collection, holder.comp_1932())) {
                        accessor.betterRecipeBook$getCraftable().remove(holder);
                    }
                }
            }
        }

        for (class_516 collection : collections) {
            // Step 2: Mark partial materials
            PartialCraftingUtil.markPartialMaterials(collection, this.menu.field_7761);

            // Step 3: Add partial recipes to craftable set so they are treated as craftable
            if (PartialCraftingUtil.hasPartialMaterials(collection)) {
                RecipeCollectionAccessor accessor = (RecipeCollectionAccessor) collection;
                for (class_8786<?> holder : collection.method_2650()) {
                    if (PartialCraftingUtil.isPartiallyCraftable(collection, holder.comp_1932())) {
                        accessor.betterRecipeBook$getCraftable().add(holder);
                    }
                }
            }

            // Step 4: If enabled, add incompatible recipes to fitsDimensions so
            //         getRecipes(false) and search naturally include them
            if (onInventory) {
                IncompatibleCraftingUtil.markIncompatibleRecipes(collection);
            }
        }
    }

    /**
     * Sorts collections so craftable recipes appear first, then partially-
     * craftable, then the rest.  1.21.1 calls page.updateCollections(List, boolean)
     * (2 params instead of 3 on 1.21.11+).
     */
    @Redirect(method = "updateCollections", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeBookPage;updateCollections(Ljava/util/List;Z)V"))
    private void betterRecipeBook$sortBeforePageUpdate(class_513 page, List<class_516> list, boolean resetPageNumber) {
        List<class_516> craftable = new ArrayList<>();
        List<class_516> partial = new ArrayList<>();
        List<class_516> other = new ArrayList<>();

        for (class_516 c : list) {
            boolean hasCraftable = c.method_2655();
            boolean hasPartial = PartialCraftingUtil.hasPartialMaterials(c);

            if (hasCraftable && !hasPartial) {
                craftable.add(c);
            } else if (hasPartial) {
                partial.add(c);
            } else {
                other.add(c);
            }
        }

        list.clear();
        list.addAll(craftable);
        list.addAll(partial);
        list.addAll(other);
        page.method_2627(list, resetPageNumber);
    }
}
