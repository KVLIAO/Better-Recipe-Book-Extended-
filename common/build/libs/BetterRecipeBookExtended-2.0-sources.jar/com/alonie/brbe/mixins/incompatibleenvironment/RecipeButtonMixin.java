package com.alonie.brbe.mixins.incompatibleenvironment;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.util.IncompatibleCraftingUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_490;
import net.minecraft.class_514;
import net.minecraft.class_516;
import net.minecraft.class_8786;

@Mixin(class_514.class)
public abstract class RecipeButtonMixin {

    @Shadow private class_516 collection;
    @Shadow public abstract class_8786<?> getRecipe();
    @Shadow
    private List<class_8786<?>> getOrderedRecipes() {
        throw new AssertionError();
    }

    /**
     * Safety net: ensures the button's recipe list is never empty.
     * If getOrderedRecipes() returns empty (which can happen when
     * fitsDimensions injection fails), populate it with the collection's
     * incompatible recipes so renderWidget doesn't crash with / by zero.
     */
    @Inject(method = "getOrderedRecipes", at = @At("RETURN"), cancellable = true)
    private void betterRecipeBook$ensureNonEmptyRecipes(
            CallbackInfoReturnable<List<class_8786<?>>> cir) {
        List<class_8786<?>> recipes = cir.getReturnValue();
        if (recipes != null && !recipes.isEmpty()) return;
        if (!BetterRecipeBook.config.showAllRecipesInSurvival) return;
        if (!(class_310.method_1551().field_1755 instanceof class_490)) return;

        List<class_8786<?>> fallback = new ArrayList<>();
        for (class_8786<?> holder : this.collection.method_2650()) {
            if (IncompatibleCraftingUtil.checkIncompatible(this.collection, holder.comp_1932())) {
                fallback.add(holder);
            }
        }
        if (!fallback.isEmpty()) {
            cir.setReturnValue(fallback);
        }
    }

    @Inject(method = "getTooltipText", at = @At("RETURN"))
    private void betterRecipeBook$appendIncompatibleWarning(
            CallbackInfoReturnable<List<class_2561>> cir) {
        if (!BetterRecipeBook.config.showAllRecipesInSurvival) return;
        if (!(class_310.method_1551().field_1755 instanceof class_490)) return;

        List<class_2561> list = cir.getReturnValue();
        if (list == null || list.isEmpty()) return;

        class_8786<?> current;
        try {
            current = this.getRecipe();
        } catch (ArithmeticException e) {
            return;
        }
        if (current == null) return;

        if (IncompatibleCraftingUtil.checkIncompatible(this.collection, current.comp_1932())) {
            list.add(class_2561.method_43473());
            list.add(class_2561.method_43471("brbe.gui.environmentIncompatible")
                    .method_27692(class_124.field_1061));
        }
    }
}
