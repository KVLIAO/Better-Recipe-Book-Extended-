package com.alonie.brbe.mixins.incompletecrafting;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.util.PartialCraftingUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1729;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3439;
import net.minecraft.class_514;
import net.minecraft.class_516;
import net.minecraft.class_8786;

@Mixin(class_514.class)
public abstract class RecipeButtonMixin extends class_339 {

    protected RecipeButtonMixin(int x, int y, int width, int height, class_2561 message) {
        super(x, y, width, height, message);
    }
    @Shadow
    private class_516 collection;

    @Shadow
    private int currentIndex;

    /**
     * Disables the crafting filter so all recipes are always visible.
     * 1.21.1 checks filtering via book.isFiltering(menu) on RecipeBook,
     * not via a method on RecipeBookComponent.
     */
    @Redirect(
        method = "getOrderedRecipes",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/stats/RecipeBook;isFiltering(Lnet/minecraft/world/inventory/RecipeBookMenu;)Z")
    )
    private boolean betterRecipeBook$disableFilteringInOrdered(class_3439 book, class_1729<?, ?> menu) {
        return false;
    }

    @Redirect(
        method = "renderWidget",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/stats/RecipeBook;isFiltering(Lnet/minecraft/world/inventory/RecipeBookMenu;)Z")
    )
    private boolean betterRecipeBook$disableFilteringInRender(class_3439 book, class_1729<?, ?> menu) {
        return false;
    }

    @Redirect(method = "renderWidget", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeCollection;hasCraftable()Z"))
    private boolean betterRecipeBook$renderPartiallyCraftableAsCraftable(class_516 collection, class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        return collection.method_2655() || PartialCraftingUtil.hasPartialMaterials(collection);
    }

    @Inject(method = "renderWidget", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;renderFakeItem(Lnet/minecraft/world/item/ItemStack;II)V", shift = At.Shift.BEFORE))
    private void betterRecipeBook$renderPartialOverlay(class_332 gui, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        List<class_8786<?>> recipes = this.collection.method_2650();
        if (recipes.isEmpty()) return;

        class_8786<?> current = recipes.get(this.currentIndex % recipes.size());
        if (PartialCraftingUtil.isPartiallyCraftable(this.collection, current)) {
            gui.method_25294(method_46426() + 1, method_46427() + 1, method_46426() + field_22758 - 1, method_46427() + field_22759 - 1, 0x60FF3333);
        }
    }

    @Inject(method = "getOrderedRecipes", at = @At("RETURN"), cancellable = true)
    private void betterRecipeBook$filterOrderedRecipes(CallbackInfoReturnable<List<class_8786<?>>> cir) {
        List<class_8786<?>> result = new ArrayList<>(cir.getReturnValue());

        // Step 1: add partially-craftable recipes.
        {
            List<class_8786<?>> partials = PartialCraftingUtil.getPartiallyCraftableRecipes(this.collection);
            if (!partials.isEmpty()) {
                Set<class_2960> existing = new HashSet<>();
                for (class_8786<?> r : result) {
                    existing.add(r.comp_1932());
                }
                for (class_8786<?> p : partials) {
                    if (!existing.contains(p.comp_1932())) {
                        result.add(p);
                    }
                }
            }
        }

        // Step 2: if any craftable or partially-craftable recipes exist,
        // drop the completely uncraftable ones from cycling.
        boolean hasCraftable = this.collection.method_2655();
        boolean hasPartial = PartialCraftingUtil.hasPartialMaterials(this.collection);

        if ((hasCraftable || hasPartial) && result.size() > 1) {
            List<class_8786<?>> filtered = new ArrayList<>(result.size());
            for (class_8786<?> r : result) {
                if (this.collection.method_2653(r) && !PartialCraftingUtil.isPartiallyCraftable(this.collection, r)) {
                    filtered.add(r);
                }
            }
            for (class_8786<?> r : result) {
                if (PartialCraftingUtil.isPartiallyCraftable(this.collection, r)) {
                    filtered.add(r);
                }
            }
            cir.setReturnValue(filtered);
        } else if (!result.equals(cir.getReturnValue())) {
            cir.setReturnValue(result);
        }
    }

    @Inject(method = "isOnlyOption", at = @At("RETURN"), cancellable = true)
    private void betterRecipeBook$allowNestedAlternativeOverlay(CallbackInfoReturnable<Boolean> cir) {
        // Already returning false (multi-option) — nothing to fix.
        if (!cir.getReturnValue()) {
            return;
        }

        // Our filter may have reduced getOrderedRecipes to a single entry,
        // but the collection still contains multiple alternatives.
        // Force isOnlyOption=false so the overlay can show them all.
        if (this.collection.method_2650().size() > 1
                && (this.collection.method_2655() || PartialCraftingUtil.hasPartialMaterials(this.collection))) {
            cir.setReturnValue(false);
        }
    }
}
