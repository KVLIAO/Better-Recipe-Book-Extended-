package com.alonie.brbe.mixins.toasts;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_332;
import net.minecraft.class_366;
import net.minecraft.class_368;
import net.minecraft.class_374;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_366.class)
public class RemoveToasts {
    @Inject(at = @At("HEAD"), method = "render", cancellable = true)
    private void draw(class_332 gui, class_374 manager, long startTime, CallbackInfoReturnable<class_368.class_369> cir) {
        if (BetterRecipeBook.config.newRecipes.unlockAll) {
            cir.setReturnValue(class_368.class_369.field_2209);
        }
    }
}
