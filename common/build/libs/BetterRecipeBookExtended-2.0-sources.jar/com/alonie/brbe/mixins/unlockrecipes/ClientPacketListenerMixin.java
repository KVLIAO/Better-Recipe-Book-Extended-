package com.alonie.brbe.mixins.unlockrecipes;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.interfaces.unlockrecipes.IMixinRecipeManager;
import com.alonie.brbe.mixins.accessors.RecipeBookComponentAccessor;
import com.alonie.brbe.util.RecipeMenuUtil;
import com.alonie.brbe.util.RecipeUnlockUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;
import net.minecraft.class_1729;
import net.minecraft.class_1863;
import net.minecraft.class_2653;
import net.minecraft.class_2695;
import net.minecraft.class_2713;
import net.minecraft.class_2788;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_518;
import net.minecraft.class_634;

/**
 * Unlocks all recipes that are sent to the client or updated by either the local server or external server
 */
@Mixin(class_634.class)
public abstract class ClientPacketListenerMixin {

    @Shadow @Final private class_1863 recipeManager;
    @Unique private class_310 _$minecraft = class_310.method_1551();

    @Inject(method = "handleAddOrRemoveRecipes", at = @At(value = "RETURN"))
    public void onAddOrRemoveRecipes(class_2713 packet, CallbackInfo ci) {
        //System.out.println("addOrRemoveRecipes %s: %s".formatted(packet.getState(), Joiner.on(", ").join(packet.getRecipes())));
        Set<class_2960> serverUnlockedRecipes = ((IMixinRecipeManager) recipeManager).betterRecipeBook$getServerUnlockedRecipes();
        switch (packet.method_11751()) {
            case field_12416:
                serverUnlockedRecipes.clear();
            case field_12415:
                serverUnlockedRecipes.addAll(packet.method_11750());
                break;
            case field_12417:
                packet.method_11750().forEach(serverUnlockedRecipes::remove);
        }
        RecipeUnlockUtil.unlockRecipesIfRequired();
    }

    @Inject(method = "handleUpdateRecipes", at = @At(value = "RETURN"))
    public void onUpdateRecipes(class_2788 packet, CallbackInfo ci) {
        RecipeUnlockUtil.unlockRecipesIfRequired();
    }

    @Inject(method = "handleContainerSetSlot", at = @At(value = "HEAD"))
    public void onContainerSetSlot(class_2653 packet, CallbackInfo ci) {
        // clear ghost recipes if crafting grid contents are changed by server
        if (BetterRecipeBook.config.newRecipes.unlockAll && _$minecraft.field_1724 != null
                && _$minecraft.field_1724.field_7512 instanceof class_1729<?, ?> menu
                && _$minecraft.field_1724.field_7512.field_7763 == packet.method_11452()
                && _$minecraft.field_1755 instanceof class_518 rul) {
            if (!packet.method_11449().method_7960() && RecipeMenuUtil.isRecipeSlot(menu, packet.method_11450())) {
                ((RecipeBookComponentAccessor) rul.method_2659()).getGhostRecipe().method_2571();
            }
        }
    }

    @Inject(method = "handlePlaceRecipe", at = @At(value = "HEAD", target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeBookComponent;setupGhostRecipe(Lnet/minecraft/world/item/crafting/Recipe;Ljava/util/List;)V"))
    public void onHandlePlaceRecipe_setupGhostRecipe(class_2695 packet, CallbackInfo ci) {
        if (_$minecraft.field_1755 instanceof class_518 rul) {
            ((RecipeBookComponentAccessor) rul.method_2659()).getGhostRecipe().method_2571();
        }
    }


}
