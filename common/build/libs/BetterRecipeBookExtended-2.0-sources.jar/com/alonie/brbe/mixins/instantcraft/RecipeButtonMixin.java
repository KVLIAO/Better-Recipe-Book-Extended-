package com.alonie.brbe.mixins.instantcraft;

import com.alonie.brbe.BetterRecipeBook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_513;
import net.minecraft.class_514;
import net.minecraft.class_516;
import net.minecraft.class_8786;

@Mixin(class_514.class)
public class RecipeButtonMixin {

    @Shadow private class_516 collection;

    @Unique private List<class_8786<?>> betterRecipeBook$lastClicked;

    @Inject(method = "getOrderedRecipes", at = @At(value = "RETURN"), cancellable = true, locals = LocalCapture.CAPTURE_FAILSOFT)
    public void getOrderedRecipes(CallbackInfoReturnable<List<class_8786<?>>> cir, List<class_8786<?>> holders) {
        if (holders.isEmpty() && betterRecipeBook$lastClicked != null) {
            cir.setReturnValue(new ArrayList<>(betterRecipeBook$lastClicked));
        }
    }

    @Inject(method = "init", at = @At(value = "HEAD"))
    public void init(class_516 collection, class_513 recipeBookPage, CallbackInfo ci) {
        if (BetterRecipeBook.instantCraftingManager.lastHoveredCollection == collection
                && BetterRecipeBook.instantCraftingManager.lastClickedRecipe != null) {
            BetterRecipeBook.instantCraftingManager.lastHoveredCollection = null;
            betterRecipeBook$lastClicked = List.of(BetterRecipeBook.instantCraftingManager.lastClickedRecipe);
        }
    }

}
