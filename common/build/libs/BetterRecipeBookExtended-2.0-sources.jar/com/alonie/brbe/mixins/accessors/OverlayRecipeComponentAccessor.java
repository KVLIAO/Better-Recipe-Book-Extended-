package com.alonie.brbe.mixins.accessors;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_339;
import net.minecraft.class_508;

@Mixin(class_508.class)
public interface OverlayRecipeComponentAccessor {

    @Accessor("recipeButtons")
    List<class_339> getRecipeButtons();

    @Accessor("time")
    float getTime();

    @Accessor("isFurnaceMenu")
    boolean isFurnaceMenu();

}
