package com.alonie.brbe.mixins.unlockrecipes;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_514;

@Mixin(class_514.class)
public abstract class RecipeButtonMixin {

    @Inject(method = "getTooltipText", locals = LocalCapture.CAPTURE_FAILSOFT, at = @At("RETURN"))
    public void getTooltip(CallbackInfoReturnable<List<class_2561>> cir, class_1799 itemStack, List<class_2561> list) {
    }
}
