package com.alonie.brbe.mixins.instantcraft;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.util.BRBTextures;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_361;
import net.minecraft.class_507;
import net.minecraft.class_513;
import net.minecraft.class_517;

@Mixin(class_507.class)
public abstract class RecipeBookComponentMixin {

    @Shadow protected class_310 minecraft;
    @Shadow private int height;
    @Shadow private int width;
    @Shadow private int xOffset;
    @Shadow @Final private class_513 recipeBookPage;

    @Shadow public abstract boolean isVisible();

    @Unique protected class_361 betterRecipeBook$instantCraftButton;
    @Unique private static final class_2561 TOGGLE_INSTANT_CRAFT_ON_TEXT;
    @Unique private static final class_2561 TOGGLE_INSTANT_CRAFT_OFF_TEXT;

    @Unique
    private boolean betterRecipeBook$shouldSkip() {
        if (!BetterRecipeBook.config.instantCraft.showButton) {
            return true;
        }

        // remove instant craft button in furnaces
        return ((Object) this) instanceof class_517;
    }

    @Inject(method = "initVisuals", at = @At("RETURN"))
    public void reset(CallbackInfo ci) {
        if (betterRecipeBook$shouldSkip()) {
            return;
        }

        int i = (this.width - 147) / 2 - this.xOffset;
        int j = (this.height - 166) / 2;

        this.betterRecipeBook$instantCraftButton = new class_361(i + 110, j + 137, 26, 16 + 2, BetterRecipeBook.instantCraftingManager.isEnabled());
        BetterRecipeBook.instantCraftingManager.lastInstantCraftButton = this.betterRecipeBook$instantCraftButton;
        this.betterRecipeBook$instantCraftButton.method_1962(BRBTextures.RECIPE_BOOK_INSTANT_CRAFT_BUTTON_SPRITES);
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeBookPage;render(Lnet/minecraft/client/gui/GuiGraphics;IIIIF)V"))
    public void render(class_332 gui, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (betterRecipeBook$shouldSkip()) {
            return;
        }

        this.betterRecipeBook$instantCraftButton.method_25394(gui, mouseX, mouseY, delta);
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    public void mouseClicked(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
        if (this.isVisible() && !betterRecipeBook$shouldSkip()) {
            if (this.betterRecipeBook$instantCraftButton.method_25402(mouseX, mouseY, button)) {
                boolean bl = BetterRecipeBook.instantCraftingManager.toggleEnabled();
                this.betterRecipeBook$instantCraftButton.method_1964(bl);
                cir.setReturnValue(true);
            }
        }
    }

    @Inject(method = "renderTooltip", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeBookComponent;renderGhostRecipeTooltip(Lnet/minecraft/client/gui/GuiGraphics;IIII)V"))
    public void drawTooltip(class_332 gui, int x, int y, int mouseX, int mouseY, CallbackInfo ci) {
        if (betterRecipeBook$shouldSkip()) {
            return;
        }

        if (this.betterRecipeBook$instantCraftButton.method_25367()) {
            class_2561 text = this.betterRecipeBook$instantCraftButton.method_1965() ? TOGGLE_INSTANT_CRAFT_ON_TEXT : TOGGLE_INSTANT_CRAFT_OFF_TEXT;
            if (this.minecraft.field_1755 != null) {
                gui.method_51434(minecraft.field_1772, List.of(text), mouseX, mouseY);
            }
        }
    }

    static {
        TOGGLE_INSTANT_CRAFT_ON_TEXT = class_2561.method_43471("brb.gui.instantCraft.on");
        TOGGLE_INSTANT_CRAFT_OFF_TEXT = class_2561.method_43471("brb.gui.instantCraft.off");
    }
}
