package com.alonie.brbe.mixins;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.brewingstand.BrewingRecipeBookComponent;
import com.alonie.brbe.util.BRBTextures;
import net.minecraft.class_1661;
import net.minecraft.class_1708;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_465;
import net.minecraft.class_472;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_472.class)
public abstract class BrewingStandScreenMixin extends class_465<class_1708> {

    @Unique
    public final BrewingRecipeBookComponent _$recipeBookComponent = new BrewingRecipeBookComponent();
    @Unique
    private boolean _$widthNarrow;

    public BrewingStandScreenMixin(class_1708 handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
    }

    @Inject(method = "init", at = @At("RETURN"))
    protected void init(CallbackInfo ci) {
        if (BetterRecipeBook.config.enableBook) {
            this._$widthNarrow = this.field_22789 < 379;
            assert this.field_22787 != null;
            this._$recipeBookComponent.init(this.field_22789, this.field_22790, this.field_22787, _$widthNarrow, this.field_2797, class_310.method_1551().method_1562().method_29091());

            if (!BetterRecipeBook.config.keepCentered) {
                this.field_2776 = this._$recipeBookComponent.findLeftEdge(this.field_22789, this.field_2792);
            }

            this.method_37063(new class_344(this.field_2776 + 135, this.field_22790 / 2 - 50, 20, 18, BRBTextures.RECIPE_BOOK_BUTTON_SPRITES, (button) -> {
                this._$recipeBookComponent.toggleVisibility();
                if (!BetterRecipeBook.config.keepCentered) {
                    this.field_2776 = this._$recipeBookComponent.findLeftEdge(this.field_22789, this.field_2792);
                }
                button.method_48229(this.field_2776 + 135, this.field_22790 / 2 - 50);
            }));

            this.method_25429(this._$recipeBookComponent);
        }
    }

    @Override
    public boolean method_25404(int i, int j, int k) {
        if (_$recipeBookComponent.method_25404(i, j, k)) {
            return true;
        }
        return super.method_25404(i, j, k);
    }

    @Override
    public boolean method_16803(int i, int j, int k) {
        if (_$recipeBookComponent.method_16803(i, j, k)) {
            return true;
        }
        return super.method_16803(i, j, k);
    }

    @Override
    public boolean method_25400(char c, int i) {
        if (_$recipeBookComponent.method_25400(c, i)) {
            return true;
        }
        return super.method_25400(c, i);
    }

    @Override
    protected void method_2383(class_1735 slot, int x, int y, class_1713 clickType) {
        // clear ghost recipe if an empty ingredient slot is clicked with no items
        if (slot != null && slot.field_7874 < 4 && field_2797.field_7761.get(slot.field_7874).method_7677().method_7960()) {
            _$recipeBookComponent.ghostRecipe.clear();
        }

        super.method_2383(slot, x, y, clickType);
    }

    @Override
    protected boolean method_2381(double d, double e, int i, int j, int k) {
        boolean bl = d < (double) i || e < (double) j || d >= (double) (i + this.field_2792) || e >= (double) (j + this.field_2779);
        return this._$recipeBookComponent.hasClickedOutside(d, e, this.field_2776, this.field_2800, this.field_2792, this.field_2779, k) && bl;
    }

    @Inject(method = "render", at = @At("RETURN"))
    public void render(class_332 guiGraphics, int i, int j, float f, CallbackInfo ci) {
        if (this._$recipeBookComponent.isVisible()) {
            this._$recipeBookComponent.method_25394(guiGraphics, i, j, f);
            this._$recipeBookComponent.renderGhostRecipe(guiGraphics, this.field_2776, this.field_2800, false, f);
            this._$recipeBookComponent.drawTooltip(guiGraphics, this.field_2776, this.field_2800, i, j);
        }
    }

    // fix brewing progress indicator offset when recipe book is open by modifying the width offset
    @ModifyVariable(
            method = "renderBg",
            index = 5,
            at = @At("STORE")
    )
    public int renderBg_width(int i) {
        if (this._$recipeBookComponent.isVisible() && !BetterRecipeBook.config.keepCentered) {
            return i + 77;
        } else {
            return i;
        }
    }
}
