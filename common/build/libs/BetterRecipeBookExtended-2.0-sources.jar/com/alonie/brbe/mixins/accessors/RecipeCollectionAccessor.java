package com.alonie.brbe.mixins.accessors;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_516;
import net.minecraft.class_8786;

@Mixin(class_516.class)
public interface RecipeCollectionAccessor {
    @Accessor("fitsDimensions")
    Set<class_8786<?>> getFitsDimensions();

    @Accessor("craftable")
    Set<class_8786<?>> betterRecipeBook$getCraftable();
}
