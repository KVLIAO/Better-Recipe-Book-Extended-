package com.alonie.brbe.mixins;

import com.alonie.brbe.interfaces.RecipeBookTabButtonIconOffset;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_507;
import net.minecraft.class_512;

@Mixin(class_507.class)
public abstract class RecipeBookComponentTabIconOffsetMixin {
    @Shadow
    @Final
    private List<class_512> tabButtons;

    @Inject(method = "updateTabs", at = @At("RETURN"))
    private void betterRecipeBook$offsetTopAndBottomTabIcons(CallbackInfo ci) {
        class_512 firstVisibleButton = null;
        class_512 lastVisibleButton = null;

        for (class_512 button : this.tabButtons) {
            RecipeBookTabButtonIconOffset offset = (RecipeBookTabButtonIconOffset) button;
            offset.betterRecipeBook$setIconYOffset(0);
            if (!button.field_22764) {
                continue;
            }

            if (firstVisibleButton == null) {
                firstVisibleButton = button;
            }
            lastVisibleButton = button;
        }

        if (firstVisibleButton != null) {
            ((RecipeBookTabButtonIconOffset) firstVisibleButton).betterRecipeBook$setIconYOffset(-1);
        }
        if (lastVisibleButton != null && lastVisibleButton != firstVisibleButton) {
            ((RecipeBookTabButtonIconOffset) lastVisibleButton).betterRecipeBook$setIconYOffset(1);
        }
    }
}
