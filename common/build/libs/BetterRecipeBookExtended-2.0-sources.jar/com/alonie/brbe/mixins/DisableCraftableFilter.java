package com.alonie.brbe.mixins;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_361;
import net.minecraft.class_507;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Removes the "Only show craftable" filter button — gated by partialCraftingEnabled.
 *
 * 1.21.1 uses StateSwitchingButton (not CycleButton). There is no
 * isFiltering() method on RecipeBookComponent — the filtering check
 * is book.isFiltering(menu) on RecipeBook, which is redirected in
 * RecipeButtonMixin.
 */
@Mixin(class_507.class)
public abstract class DisableCraftableFilter {

    @Shadow
    protected class_361 filterButton;

    @Inject(method = "initVisuals", at = @At("TAIL"))
    private void betterRecipeBook$hideFilterButton(CallbackInfo ci) {
        if (!BetterRecipeBook.config.partialCraftingEnabled) return;
        this.filterButton.field_22764 = false;
        this.filterButton.field_22763 = false;
    }
}
