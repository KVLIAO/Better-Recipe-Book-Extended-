package com.alonie.brbe.mixins.rei;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.compat.ItemViewCompat;
import com.alonie.brbe.mixins.accessors.RecipeBookComponentAccessor;
import com.alonie.brbe.mixins.accessors.RecipeBookPageAccessor;
import net.minecraft.class_1799;
import net.minecraft.class_507;
import net.minecraft.class_513;
import net.minecraft.class_514;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_507.class)
public abstract class RecipeBookComponentMixin {

    @Inject(method = "keyPressed", at = @At("RETURN"), cancellable = true)
    private void betterRecipeBook$handleItemViewKeys(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        if (!ItemViewCompat.isLoaded() || cir.getReturnValueZ()) {
            return;
        }

        class_513 page = ((RecipeBookComponentAccessor) this).getRecipeBookPage();
        if (page == null) {
            return;
        }

        for (class_514 button : ((RecipeBookPageAccessor) page).getButtons()) {
            if (!button.method_25367()) {
                continue;
            }

            class_1799 hoveredStack = button.method_2643().comp_1933().method_8110(button.method_2645().method_48479());
            if (hoveredStack == null || hoveredStack.method_7960()) {
                return;
            }

            if (BetterRecipeBook.RECIPE_VIEW_MAPPING.method_1417(keyCode, scanCode)) {
                cir.setReturnValue(ItemViewCompat.openRecipeView(hoveredStack));
            } else if (BetterRecipeBook.USAGE_VIEW_MAPPING.method_1417(keyCode, scanCode)) {
                cir.setReturnValue(ItemViewCompat.openUsageView(hoveredStack));
            }
            return;
        }
    }
}
