package com.alonie.brbe.mixins.accessors.smithing;

import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_8060;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_8060.class)
public interface SmithingTransformRecipeAccessor {
    @Accessor("template")
    class_1856 getUnderlyingTemplate();

    @Accessor("base")
    class_1856 getUnderlyingBase();

    @Accessor("addition")
    class_1856 getUnderlyingAddition();

    @Accessor("result")
    class_1799 getResult();
}
