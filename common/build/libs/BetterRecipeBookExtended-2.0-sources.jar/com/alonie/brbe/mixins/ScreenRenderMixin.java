package com.alonie.brbe.mixins;

import com.alonie.brbe.util.TopLayerOverlayRenderer;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_437.class)
public abstract class ScreenRenderMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void betterRecipeBook$renderTopLayerOverlay(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        TopLayerOverlayRenderer.render((class_437) (Object) this, guiGraphics, mouseX, mouseY, partialTick);
    }
}
