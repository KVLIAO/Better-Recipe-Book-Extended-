package com.alonie.brbe.mixins.incompatibleenvironment;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.util.IncompatibleCraftingUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_310;
import net.minecraft.class_490;
import net.minecraft.class_507;
import net.minecraft.class_512;
import net.minecraft.class_516;
import net.minecraft.class_8786;

@Mixin(class_507.class)
public abstract class RecipeBookComponentMixin {

    @Shadow @Final private net.minecraft.class_299 book;
    @Shadow private class_512 selectedTab;

    @Inject(method = "setupGhostRecipe", at = @At("HEAD"), cancellable = true)
    private void betterRecipeBook$preventIncompatibleRecipeClick(
            class_8786<?> recipe, List list, CallbackInfo ci) {
        if (!BetterRecipeBook.config.showAllRecipesInSurvival) return;
        if (!(class_310.method_1551().field_1755 instanceof class_490)) return;

        List<class_516> collections = this.book.method_1396(selectedTab.method_2623());
        if (collections == null) return;

        for (class_516 collection : collections) {
            if (IncompatibleCraftingUtil.checkIncompatible(collection, recipe.comp_1932())) {
                ci.cancel();
                return;
            }
        }
    }
}
