package com.alonie.brbe.mixins.pins;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.PinnedRecipeManager;
import com.alonie.brbe.mixins.accessors.OverlayRecipeButtonAccessor;
import com.alonie.brbe.mixins.accessors.OverlayRecipeComponentAccessor;
import com.alonie.brbe.mixins.accessors.RecipeBookComponentAccessor;
import com.alonie.brbe.mixins.accessors.RecipeBookPageAccessor;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_465;
import net.minecraft.class_507;
import net.minecraft.class_508;
import net.minecraft.class_513;
import net.minecraft.class_514;
import net.minecraft.class_518;
import net.minecraft.client.gui.screens.recipebook.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_465.class)
public abstract class AbstractContainerScreenMixin {

    @Inject(method = "keyPressed", at = @At(value = "HEAD"), cancellable = true)
    public void onKeyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        if (!(this instanceof class_518 rul)) return;

        class_310 minecraft = class_310.method_1551();
        class_507 book = rul.method_2659();

        if (!book.method_2605()) return;

        class_513 page = ((RecipeBookComponentAccessor) book).getRecipeBookPage();
        class_508 alternatesWidget = ((RecipeBookPageAccessor) page).getOverlay();

        class_342 searchBox = ((RecipeBookComponentAccessor) book).getSearchBox();

        // when F is pressed, handle pinning/unpinning of recipes except when searchBox is consuming input
        if (BetterRecipeBook.config.enablePinning && BetterRecipeBook.PIN_MAPPING.method_1417(keyCode, scanCode) && !searchBox.method_20315()) {
            // handle alternatives widget first
            if (alternatesWidget.method_2616()) {
                for (class_339 alternativeButton : ((OverlayRecipeComponentAccessor) alternatesWidget).getRecipeButtons()) {
                    if (alternativeButton.method_25367()) {
                        PinnedRecipeManager.handlePinRecipe(book, page, ((OverlayRecipeButtonAccessor) alternativeButton).getRecipe());
                        cir.setReturnValue(true);
                        return;
                    }
                }
                return;
            }

            for (class_514 button : ((RecipeBookPageAccessor) page).getButtons()) {
                if (button.method_25367()) {
                    PinnedRecipeManager.handlePinRecipe(book, page, button.method_2643());
                    cir.setReturnValue(true);
                    return;
                }
            }
        }

        // when <chat key> is pressed, focus recipes component for searchBox
        // this also works for BrewingRecipeBookComponent as the super's searchBox is set to the same object
        if (minecraft.field_1690.field_1890.method_1417(keyCode, scanCode)) {
            minecraft.field_1755.method_25395(book);
        }

    }

}
