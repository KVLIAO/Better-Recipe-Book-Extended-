package com.alonie.brbe.mixins.alternativerecipes;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.mixins.accessors.OverlayRecipeButtonPosAccessor;
import com.alonie.brbe.mixins.accessors.OverlayRecipeComponentAccessor;
import com.alonie.brbe.util.BRBTextures;
import com.alonie.brbe.util.PartialCraftingUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_508;
import net.minecraft.class_8786;


@Mixin(targets = "net.minecraft.client.gui.screens.recipebook.OverlayRecipeComponent$OverlayRecipeButton")
public abstract class OverlayRecipeButtonMixin extends class_339 {

    @Final
    @Shadow
    private boolean isCraftable;
    @Final
    @Shadow
    class_8786<?> recipe;

    @Shadow
    public abstract void method_48579(class_332 gui, int mouseX, int mouseY, float delta);

    @Shadow
    @Final
    protected List<?> ingredientPos;
    @Shadow
    @Final
    class_508 field_3113;

    public OverlayRecipeButtonMixin(int x, int y, int width, int height, class_2561 message) {
        super(x, y, width, height, message);
    }

    @Inject(at = @At("HEAD"), method = "renderWidget", cancellable = true)
    public void renderWidget(class_332 gui, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        boolean effectiveCraftable = this.isCraftable
                || PartialCraftingUtil.isPartiallyCraftable(field_3113.method_2614(), this.recipe);
        class_2960 resourceLocation;

        if (((OverlayRecipeComponentAccessor) field_3113).isFurnaceMenu()) {
            resourceLocation = BRBTextures.RECIPE_BOOK_PLAIN_OVERLAY_SPRITE.method_52729(effectiveCraftable, method_25367());
        } else {
            resourceLocation = BRBTextures.RECIPE_BOOK_CRAFTING_OVERLAY_SPRITE.method_52729(effectiveCraftable, method_25367());
        }

        gui.method_52706(resourceLocation, method_46426(), method_46427(), this.field_22758, this.field_22759);
        gui.method_51448().method_22903();
        if (BetterRecipeBook.config.alternativeRecipes.onHover && !this.method_25367()) { // if show alternatives recipe is enabled and recipe is not hovered, show the result item
            class_1799 recipeOutput = this.recipe.comp_1933().method_8110(field_3113.method_2614().method_48479());
            gui.method_51427(recipeOutput, method_46426() + 4, method_46427() + 4);
        } else { // otherwise display the crafting recipe
            gui.method_51448().method_22904(this.method_46426() + 2, this.method_46427() + 2, 150.0);
            for (Object rawPos : this.ingredientPos) {
                OverlayRecipeButtonPosAccessor pos = (OverlayRecipeButtonPosAccessor) rawPos;
                gui.method_51448().method_22903();
                gui.method_51448().method_22904(pos.betterRecipeBook$getX(), pos.betterRecipeBook$getY(), 0.0);
                // if furnace menu, keep items at default scale, so it isn't tiny
                if (!((OverlayRecipeComponentAccessor) field_3113).isFurnaceMenu()) {
                    gui.method_51448().method_22905(0.375f, 0.375f, 1.0f);
                }
                gui.method_51448().method_22904(-8.0, -8.0, 0.0);
                class_1799[] ingredients = pos.betterRecipeBook$getIngredients();
                if (ingredients.length > 0) {
                    gui.method_51427(ingredients[class_3532.method_15375(((OverlayRecipeComponentAccessor) field_3113).getTime() / 30.0f) % ingredients.length], 0, 0);
                }
                gui.method_51448().method_22909();
            }
        }
        gui.method_51448().method_22909();

        // blit pin for pinned recipes
        if (BetterRecipeBook.config.enablePinning && BetterRecipeBook.pinnedRecipeManager.pinned.contains(recipe.comp_1932())) {
            gui.method_51448().method_22903();
            // make sure pin is drawn over the crafting items
            gui.method_51448().method_34425(gui.method_51448().method_23760().method_23761());
            gui.method_52706(BRBTextures.RECIPE_BOOK_OVERLAY_PIN_SPRITE, method_46426() - 4, method_46427() - 4, this.field_22758 + 8, this.field_22759 + 8);
            gui.method_51448().method_22909();
        }

        ci.cancel();
    }

}
