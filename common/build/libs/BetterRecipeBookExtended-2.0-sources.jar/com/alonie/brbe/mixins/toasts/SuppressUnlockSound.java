package com.alonie.brbe.mixins.toasts;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_1144;
import net.minecraft.class_366;
import net.minecraft.class_368;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(targets = "net.minecraft.client.gui.components.toasts.ToastComponent$ToastInstance")
public class SuppressUnlockSound<T extends class_368> {
    @Shadow
    @Final
    private T toast;

    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/toasts/Toast$Visibility;playSound(Lnet/minecraft/client/sounds/SoundManager;)V"))
    public void playSound(class_368.class_369 instance, class_1144 arg) {
        if (BetterRecipeBook.config.newRecipes.unlockAll && this.toast instanceof class_366) {
            // pass
            return;
        }

        instance.method_1988(arg);
    }
}
