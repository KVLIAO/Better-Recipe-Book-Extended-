package com.alonie.brbe.mixins.ungroup;

import com.google.common.collect.Lists;
import com.alonie.brbe.BetterRecipeBook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import net.minecraft.class_299;
import net.minecraft.class_314;
import net.minecraft.class_3439;
import net.minecraft.class_516;
import net.minecraft.class_8786;

@Mixin(class_299.class)
public class ClientRecipeBookMixin extends class_3439 {
    @Shadow private Map<class_314, List<class_516>> collectionsByTab;

    @Inject(method = "getCollection", locals = LocalCapture.CAPTURE_FAILHARD, at = @At("RETURN"), cancellable = true)
    private void split(class_314 category, CallbackInfoReturnable<List<class_516>> cir) {
        if (BetterRecipeBook.config.alternativeRecipes.noGrouped) {
            List<class_516> list = Lists.newArrayList(this.collectionsByTab.getOrDefault(category, Collections.emptyList()));
            List<class_516> list2 = Lists.newArrayList(list);

            for (class_516 recipeResultCollection : list) {
                if (recipeResultCollection.method_2650().size() > 1) {
                    List<class_8786<?>> recipes = recipeResultCollection.method_2650();
                    list2.remove(recipeResultCollection);

                    for (class_8786<?> recipe : recipes) {
                        class_516 recipeResultCollection1 = new class_516(recipeResultCollection.method_48479(), Collections.singletonList(recipe));
                        recipeResultCollection1.method_2647(this);

                        list2.add(recipeResultCollection1);
                    }
                }
            }
            cir.setReturnValue(list2);
        }
    }
}
