package com.alonie.brbe.mixins.pins;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.generic.pins.PinnableRecipeCollection;
import com.alonie.brbe.mixins.accessors.KeyMappingAccessor;
import com.alonie.brbe.util.BRBTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_514;
import net.minecraft.class_516;

@Mixin(class_514.class)
public abstract class RecipeButtonMixin extends class_339 {

    protected RecipeButtonMixin(int i, int j, int k, int l, class_2561 component) {
        super(i, j, k, l, component);
    }

    @Shadow
    public abstract class_516 getCollection();

    @Inject(method = "getTooltipText", locals = LocalCapture.CAPTURE_FAILHARD, at = @At("RETURN"))
    public void getTooltip(CallbackInfoReturnable<List<class_2561>> cir, class_1799 itemStack, List<class_2561> list) {
        if (!BetterRecipeBook.config.enablePinning) return;

        list.add(class_2561.method_43473());

        if (BetterRecipeBook.pinnedRecipeManager.has(PinnableRecipeCollection.of(this.getCollection()))) {
            list.add(class_2561.method_43469("brb.gui.pin.remove", ((KeyMappingAccessor) BetterRecipeBook.PIN_MAPPING).getKey().method_27445()));
        } else {
            list.add(class_2561.method_43469("brb.gui.pin.add", ((KeyMappingAccessor) BetterRecipeBook.PIN_MAPPING).getKey().method_27445()));
        }
    }

    @Inject(method = "renderWidget", at = @At(value = "RETURN", target = "Lnet/minecraft/client/gui/GuiGraphics;renderFakeItem(Lnet/minecraft/world/item/ItemStack;II)V"))
    public void renderWidget_renderFakeItem(class_332 gui, int x, int y, float delta, CallbackInfo ci) {
        // if pins are enabled, and the recipe is pinned, blit the pin texture after the recipe collection is rendered
        if (BetterRecipeBook.config.enablePinning && BetterRecipeBook.pinnedRecipeManager.has(PinnableRecipeCollection.of(getCollection()))) {
            gui.method_52706(BRBTextures.RECIPE_BOOK_PIN_SPRITE, method_46426() - 4, method_46427() - 4, 32, 32);
        }
    }

}
