package com.alonie.brbe.mixins;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_312.class)
public class MouseScrollHandler {
    @Shadow
    private double accumulatedScrollY;

    @Final @Shadow
    private class_310 minecraft;

    @Inject(at = @At(value = "RETURN"), method = "onScroll")
    public void onMouseScroll(long window, double arg1, double vertical, CallbackInfo ci) {
        if (BetterRecipeBook.getQueuedScroll() == 0 && BetterRecipeBook.config.scrolling.enableScrolling) {
            assert minecraft.field_1724 != null;

            double d = (this.minecraft.field_1690.method_42439().method_41753() ? Math.signum(vertical) : vertical) * this.minecraft.field_1690.method_41806().method_41753();

            BetterRecipeBook.setQueuedScroll((int) -((int) this.accumulatedScrollY + d));
        }
    }
}
