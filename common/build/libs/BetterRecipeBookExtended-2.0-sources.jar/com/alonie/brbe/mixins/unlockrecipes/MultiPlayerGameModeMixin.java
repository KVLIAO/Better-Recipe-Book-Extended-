package com.alonie.brbe.mixins.unlockrecipes;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.interfaces.unlockrecipes.IMixinRecipeManager;
import com.alonie.brbe.mixins.accessors.RecipeBookComponentAccessor;
import com.alonie.brbe.util.ClientInventoryUtil;
import com.alonie.brbe.util.RecipeMenuUtil;
import com.alonie.brbe.util.RecipePlacement;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;
import net.minecraft.class_1662;
import net.minecraft.class_1713;
import net.minecraft.class_1720;
import net.minecraft.class_1729;
import net.minecraft.class_1735;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_507;
import net.minecraft.class_513;
import net.minecraft.class_516;
import net.minecraft.class_518;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_7204;
import net.minecraft.class_8786;

@Mixin(class_636.class)
public abstract class MultiPlayerGameModeMixin {

    @Shadow
    @Final
    private class_310 minecraft;

    @Shadow
    protected abstract void startPrediction(class_638 arg, class_7204 arg2);

    @Shadow
    private int carriedIndex;

    @Inject(method = "handlePlaceRecipe", at = @At(value = "HEAD"), cancellable = true)
    public void onPlaceRecipe(int z, class_8786<?> recipe, boolean shiftKeyDown, CallbackInfo ci) {
        if (BetterRecipeBook.config.newRecipes.unlockAll && minecraft.field_1724 != null && minecraft.field_1761 != null && minecraft.method_1562() != null &&
                minecraft.field_1755 instanceof class_518 rul && minecraft.field_1724.field_7512 instanceof class_1729<?, ?> menu) {
            class_507 comp = rul.method_2659();

            class_513 page = ((RecipeBookComponentAccessor) comp).getRecipeBookPage();
            class_516 lastRecipe = page.method_2635();
            class_1662 contents = new class_1662();
            for (class_1735 slot : menu.field_7761) {
                if (slot.field_7874 != menu.method_7655()) contents.method_7400(slot.method_7677());
            }
            lastRecipe.method_2649(contents, menu.method_7653(), menu.method_7656(), minecraft.field_1724.method_3130());

            Set<class_2960> serverUnlockedRecipes = ((IMixinRecipeManager) minecraft.method_1562().method_2877()).betterRecipeBook$getServerUnlockedRecipes();

            // if we don't have all the items place a client side ghost recipe
            if (!lastRecipe.method_2653(recipe)) {
                // remove items from the crafting grid: not all backends do this for us if we haven't unlocked the recipe
                for (int i = 0; i < menu.method_7658() && i != menu.method_7655(); i++) {
                    ClientInventoryUtil.storeItem(i, idx -> idx != menu.method_7655() || idx >= menu.method_7658());
                }

                // place the ghost recipe as we can't craft the recipe yet
                comp.method_2596(recipe, menu.field_7761);

                // don't send recipe requests to the server that we don't have
                if (!serverUnlockedRecipes.contains(recipe.comp_1932())) ci.cancel();
            } else if (!serverUnlockedRecipes.contains(recipe.comp_1932())) { // if the server didn't unlock this recipe for us, manually place the recipe
                class_636 gameMode = minecraft.field_1761;

                // we are placing the recipe ourselves, don't ask the server to do it.
                ci.cancel();

                // store/drop held item if required
                if (!menu.method_34255().method_7960())
                    ClientInventoryUtil.storeItem(-1, idx -> idx != menu.method_7655() || idx >= menu.method_7658());

                // get the recipe placement to use to filter items and place them in the crafting grid
                var placement = RecipePlacement.create(recipe, menu.method_7653(), menu.method_7656());
                //System.out.println("placement: " + Joiner.on(", ").join(placement.stream().map(s -> s.stream().map(i -> i.toJson(true)).toList()).toList()));

                for (class_1735 craftingSlot : menu.field_7761) {
                    if (RecipeMenuUtil.isRecipeSlot(menu, craftingSlot.field_7874)) {
                        // get the ingredients for this slot in the crafting grid
                        // we need to adjust out the offset of the result slot when getting the ingredient for crafting tables
                        var slotIngredients = placement.get(craftingSlot.field_7874 - (menu.method_7655() > 0 ? 0 : 1));

                        // if the item in the crafting grid doesn't match the recipe, remove it.
                        if (!craftingSlot.method_7677().method_7960() && (slotIngredients.isEmpty() || slotIngredients.stream().anyMatch(i -> !i.method_8093(craftingSlot.method_7677())))) {
                            ClientInventoryUtil.storeItem(craftingSlot.field_7874, idx -> idx != menu.method_7655() || idx >= menu.method_7658());
                        }

                        // find items to put in the crafting grid
                        for (class_1735 inventorySlot : menu.field_7761) {
                            // ignore crafting slots to prevent us from taking recipe items already in the crafting grid
                            if (!RecipeMenuUtil.isRecipeSlot(menu, inventorySlot.field_7874)) {
                                // check if any ingredient is compatible with the item in this inventory slot
                                if (slotIngredients.stream().anyMatch(i -> i.method_8093(inventorySlot.method_7677()))) {
                                    // pickup whole stack, deposit one, then return remaining stack
                                    gameMode.method_2906(menu.field_7763, inventorySlot.field_7874, 0, class_1713.field_7790, minecraft.field_1724);
                                    gameMode.method_2906(menu.field_7763, craftingSlot.field_7874, 1, class_1713.field_7790, minecraft.field_1724);
                                    if (!menu.method_34255().method_7960()) {
                                        gameMode.method_2906(menu.field_7763, inventorySlot.field_7874, 0, class_1713.field_7790, minecraft.field_1724);
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }

                if (menu instanceof class_1720) {
                    // furnace menus are supposed to take out the result item when a recipe is placed
                    if (menu.method_7611(menu.method_7655()).method_7681()) {
                        ClientInventoryUtil.storeItem(menu.method_7655(), idx -> idx != menu.method_7655() || idx >= menu.method_7658());
                    }
                } else {
                    // if instant craft is enabled, set last craft
                    if (BetterRecipeBook.instantCraftingManager.isEnabled() && !menu.method_7611(menu.method_7655()).method_7677().method_7960()) {
                        BetterRecipeBook.instantCraftingManager.recipeClicked(recipe, minecraft.field_1687.method_30349());
                    }
                }
            }
        }
    }

}
