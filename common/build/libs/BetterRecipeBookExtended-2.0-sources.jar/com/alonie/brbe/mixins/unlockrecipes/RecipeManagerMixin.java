package com.alonie.brbe.mixins.unlockrecipes;

import com.alonie.brbe.interfaces.unlockrecipes.IMixinRecipeManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_1863;
import net.minecraft.class_2960;

@Mixin(class_1863.class)
public class RecipeManagerMixin implements IMixinRecipeManager {

    // map for keeping track of unlocked recipes
    // we want this to be an instance variable to avoid any funny business
    @Unique
    private final Set<class_2960> betterRecipeBook$serverUnlockedRecipes = new HashSet<>();

    @Override
    public Set<class_2960> betterRecipeBook$getServerUnlockedRecipes() {
        return betterRecipeBook$serverUnlockedRecipes;
    }

}
