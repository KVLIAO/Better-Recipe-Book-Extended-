package com.alonie.brbe.mixins.ungroup;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.util.PartialCraftingUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import java.util.Locale;
import net.minecraft.class_1729;
import net.minecraft.class_299;
import net.minecraft.class_507;
import net.minecraft.class_513;
import net.minecraft.class_516;
import net.minecraft.class_8786;

@Mixin(class_507.class)
public class RecipeBookComponentMixin {
    @Shadow private String lastSearch;
    @Shadow private class_299 book;
    @Shadow protected class_1729<?, ?> menu;
    @Shadow @Final private class_513 recipeBookPage;

    @Inject(method = "updateCollections", locals = LocalCapture.CAPTURE_FAILSOFT, at = @At(value = "INVOKE", target = "Lit/unimi/dsi/fastutil/objects/ObjectLinkedOpenHashSet;<init>(Ljava/util/Collection;)V"), cancellable = true)
    private void refreshSearchResults(boolean bl, CallbackInfo ci, List<class_516> list, List<class_516> list2, String string) {
        if (BetterRecipeBook.config.alternativeRecipes.noGrouped) {
            list2.removeIf((recipeResultCollection) -> {
                for (class_8786<?> recipe : recipeResultCollection.method_2650()) {
                    return !recipe.comp_1933().method_8110(recipeResultCollection.method_48479()).method_7964().getString().toLowerCase(Locale.ROOT).contains(this.lastSearch.toLowerCase(Locale.ROOT));
                }
                return false;
            });

            if (this.book.method_14880(this.menu)) {
                PartialCraftingUtil.beginFilteringUpdate(true);
                list2.removeIf((recipeCollection) -> {
                    PartialCraftingUtil.markPartialMaterials(recipeCollection, this.menu.field_7761);
                    return !recipeCollection.method_2655() && !PartialCraftingUtil.hasPartialMaterials(recipeCollection);
                });
                PartialCraftingUtil.sortCraftableBeforePartial(list2);
            }

            this.recipeBookPage.method_2627(list2, bl);
            ci.cancel();
        }
    }
}