package com.alonie.brbe.mixins.pins;

import com.alonie.brbe.mixins.accessors.RecipeBookComponentAccessor;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_3439;
import net.minecraft.class_513;
import net.minecraft.class_518;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_513.class)
public class RecipeBookPageMixin {

    @Shadow private class_3439 recipeBook;

    @Shadow private class_310 minecraft;

    @Inject(method = "mouseClicked", at = @At(value = "RETURN", target = "Lnet/minecraft/client/gui/screens/recipebook/OverlayRecipeComponent;isVisible()Z"))
    public void mouseClicked(double d, double e, int i, int j, int k, int l, int m, CallbackInfoReturnable<Boolean> cir) {
        // remove search box focus when overlay is clicked
        if (cir.getReturnValue() && minecraft.field_1755 instanceof class_518 rul) {
            class_342 searchBox = ((RecipeBookComponentAccessor) rul.method_2659()).getSearchBox();
            if (searchBox != null) searchBox.method_25365(false);
        }
    }

}
