package com.alonie.brbe.mixins.modname;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.util.ModNameUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_514;

@Mixin(class_514.class)
public abstract class RecipeButtonMixin {

    @Inject(method = "getTooltipText", locals = LocalCapture.CAPTURE_FAILHARD, at = @At("RETURN"))
    private void betterRecipeBook$appendModName(CallbackInfoReturnable<List<class_2561>> cir, class_1799 itemStack, List<class_2561> list) {
        if (!BetterRecipeBook.config.showModName) {
            return;
        }

        class_2561 modName = ModNameUtil.getFormattedModName(itemStack);
        if (modName == null || modName.getString().isEmpty()) {
            return;
        }

        list.add(class_2561.method_43473());
        list.add(modName);
    }
}
