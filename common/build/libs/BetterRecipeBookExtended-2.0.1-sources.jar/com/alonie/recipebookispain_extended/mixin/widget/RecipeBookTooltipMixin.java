package com.alonie.recipebookispain_extended.mixin.widget;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_10331;
import net.minecraft.class_1761;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_507;
import net.minecraft.class_512;
import net.minecraft.class_7706;

import static com.alonie.recipebookispain_extended.RecipeBookIsPain.toItemGroup;

@Mixin(value = class_507.class, priority = 1001)
public class RecipeBookTooltipMixin {
    @Shadow protected class_310 minecraft;
    @Shadow @Final private List<class_512> tabButtons;

    @Inject(at = @At("TAIL"), method = "render")
    private void rbip$renderTooltip(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (minecraft.field_1755 != null) {
            this.tabButtons.stream().filter(widget -> widget.field_22764 && widget.method_49606()).forEach(widget -> {
                if (widget.method_2623() instanceof class_10331) {
                    context.method_51438(minecraft.field_1772, class_7706.method_47344().method_7737(), mouseX, mouseY);
                } else {
                    Optional.ofNullable(toItemGroup(widget.method_2623()))
                            .map(class_1761::method_7737)
                            .ifPresent(text -> context.method_51438(minecraft.field_1772, text, mouseX, mouseY));
                }
            });
        }
    }
}
