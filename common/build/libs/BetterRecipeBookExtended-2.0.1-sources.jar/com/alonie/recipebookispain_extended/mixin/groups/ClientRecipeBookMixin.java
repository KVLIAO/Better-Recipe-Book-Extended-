package com.alonie.recipebookispain_extended.mixin.groups;

import com.alonie.recipebookispain_extended.RecipeBookIsPain;
import com.alonie.recipebookispain_extended.RecipeBookIsPainExtendedConfig;
import com.alonie.recipebookispain_extended.access.ItemAccess;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalInt;
import net.minecraft.class_10287;
import net.minecraft.class_10294;
import net.minecraft.class_10295;
import net.minecraft.class_10297;
import net.minecraft.class_10298;
import net.minecraft.class_10314;
import net.minecraft.class_10315;
import net.minecraft.class_10352;
import net.minecraft.class_176;
import net.minecraft.class_1799;
import net.minecraft.class_299;
import net.minecraft.class_516;

@Mixin(value = class_299.class, priority = 999)
public class ClientRecipeBookMixin {

    @Shadow @Final private Map<class_10298, class_10297> known;
    @Shadow private Map<class_10287, List<class_516>> collectionsByTab;

    @Unique
    private static final class_10352 RBIP_EMPTY_CONTEXT = new class_10352.class_10353().method_64971(new class_176.class_177().method_782());

    /**
     * Rebuild Polymer namespace cache at the start of every recipe-book refresh.
     */
    @Inject(at = @At("HEAD"), method = "rebuildCollections")
    private void rbip$preRefreshPolymerCache(CallbackInfo ci) {
        if (!RecipeBookIsPainExtendedConfig.enabled()) return;
        RecipeBookIsPain.buildNamespaceCache();
        RecipeBookIsPain.applyNamespaceOverrides();
    }

    @Inject(at = @At("TAIL"), method = "rebuildCollections")
    private void rbip$refreshCreativeGroups(CallbackInfo ci) {
        if (!RecipeBookIsPainExtendedConfig.enabled()) return;
        RecipeBookIsPain.ensureInitialized();
        if (RecipeBookIsPain.RECIPE_BOOK_GROUP_TO_ITEM_GROUP.isEmpty()) return;

        Map<class_10287, EntryBucket> buckets = new LinkedHashMap<>();
        for (class_10297 entry : this.known.values()) {
            // Skip non-crafting recipes (furnace, smithing, stonecutter) to prevent
            // them from mixing into the crafting recipe book's creative tabs.
            class_10295 display = entry.comp_3263();
            if (display instanceof class_10294
                    || display instanceof class_10315
                    || display instanceof class_10314) continue;

            class_10287 group = rbip$getGroupForEntry(entry);
            if (group == null) continue;
            buckets.computeIfAbsent(group, ignored -> new EntryBucket()).add(entry);
        }

        if (buckets.isEmpty()) return;

        Map<class_10287, List<class_516>> updatedResults = new HashMap<>(this.collectionsByTab);
        buckets.forEach((group, bucket) -> updatedResults.put(group, bucket.toCollections()));
        this.collectionsByTab = Map.copyOf(updatedResults);
    }

    @Unique
    private static int rbip$debugCounter = 0;

    @Unique
    private static class_10287 rbip$getGroupForEntry(class_10297 entry) {
        try {
            for (class_1799 stack : entry.method_64730(RBIP_EMPTY_CONTEXT)) {
                class_10287 group = RecipeBookIsPain.toRecipeBookGroup(stack);
                if (rbip$debugCounter < 20) {
                    RecipeBookIsPain.LOGGER.info("[RBIP-DEBUG] recipe #{} id={} stack={} possibleGroup={}",
                            rbip$debugCounter, entry.comp_3262(), stack.method_7909(),
                            ((ItemAccess) stack.method_7909()).rbip$getPossibleGroup().map(Object::toString).orElse("none"));
                    rbip$debugCounter++;
                }
                if (group != null) return group;
            }
        } catch (Exception e) {
            RecipeBookIsPain.LOGGER.debug("[RBIP] Could not resolve output stack for recipe display {}", entry.comp_3262(), e);
        }
        return null;
    }

    private static class EntryBucket {
        private final List<List<class_10297>> entries = new ArrayList<>();
        private final Map<Integer, List<class_10297>> groupedEntries = new LinkedHashMap<>();

        private void add(class_10297 entry) {
            OptionalInt group = entry.comp_3264();
            if (group.isEmpty()) {
                this.entries.add(List.of(entry));
                return;
            }

            List<class_10297> grouped = this.groupedEntries.get(group.getAsInt());
            if (grouped == null) {
                grouped = new ArrayList<>();
                this.groupedEntries.put(group.getAsInt(), grouped);
                this.entries.add(grouped);
            }
            grouped.add(entry);
        }

        private List<class_516> toCollections() {
            return this.entries.stream()
                    .map(entries -> new class_516(List.copyOf(entries)))
                    .toList();
        }
    }
}
