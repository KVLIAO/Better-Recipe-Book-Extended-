package com.alonie.recipebookispain_extended.mixin;

import com.alonie.recipebookispain_extended.access.RecipeBookScrollAccess;
import com.alonie.recipebookispain_extended.mixin.screen.RecipeBookScreenAccessor;
import net.minecraft.class_10260;
import net.minecraft.class_1041;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_507;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_312.class)
public abstract class MouseMixin {
    @Shadow @Final private class_310 minecraft;

    @Shadow
    private double getScaledXPos(class_1041 window) {
        throw new AssertionError();
    }

    @Shadow
    private double getScaledYPos(class_1041 window) {
        throw new AssertionError();
    }

    @Inject(at = @At("HEAD"), method = "onScroll", cancellable = true)
    private void rbip$scrollRecipeBookTabs(long windowHandle, double horizontalAmount, double verticalAmount, CallbackInfo ci) {
        if (windowHandle != this.minecraft.method_22683().method_4490()
                || this.minecraft.method_18506() != null
                || !(this.minecraft.field_1755 instanceof class_10260<?> screen)) {
            return;
        }

        class_1041 window = this.minecraft.method_22683();
        double mouseX = this.getScaledXPos(window);
        double mouseY = this.getScaledYPos(window);
        double scaledVerticalAmount = this.rbip$scaleScrollAmount(verticalAmount);

        class_507<?> recipeBook = ((RecipeBookScreenAccessor) screen).rbip$getRecipeBook();
        if (((RecipeBookScrollAccess) recipeBook).rbip$scrollPages(mouseX, mouseY, scaledVerticalAmount)) {
            screen.method_37069();
            ci.cancel();
        }
    }

    private double rbip$scaleScrollAmount(double amount) {
        double scaledAmount = this.minecraft.field_1690.method_42439().method_41753()
                ? Math.signum(amount)
                : amount;
        return scaledAmount * this.minecraft.field_1690.method_41806().method_41753();
    }
}
