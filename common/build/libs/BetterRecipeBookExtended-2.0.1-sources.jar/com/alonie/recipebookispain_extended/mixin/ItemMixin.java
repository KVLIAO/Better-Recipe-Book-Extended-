package com.alonie.recipebookispain_extended.mixin;

import com.alonie.recipebookispain_extended.access.ItemAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.Optional;
import net.minecraft.class_1761;
import net.minecraft.class_1792;

@Mixin(class_1792.class)
public class ItemMixin implements ItemAccess {
    @Unique
    public class_1761 rbip$possibleGroup;

    @Override
    public Optional<class_1761> rbip$getPossibleGroup() {
        return Optional.ofNullable(rbip$possibleGroup);
    }

    @Override
    public void rbip$setPossibleGroup(class_1761 group) {
        rbip$possibleGroup = group;
    }
}
