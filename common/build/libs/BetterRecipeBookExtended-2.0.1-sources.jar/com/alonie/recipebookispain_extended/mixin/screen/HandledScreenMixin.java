package com.alonie.recipebookispain_extended.mixin.screen;

import com.alonie.recipebookispain_extended.access.RecipeBookScrollAccess;
import net.minecraft.class_10260;
import net.minecraft.class_465;
import net.minecraft.class_507;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_465.class)
public class HandledScreenMixin {
    @Inject(at = @At("HEAD"), method = "mouseScrolled", cancellable = true)
    private void rbip$scrollRecipeBookTabs(double mouseX, double mouseY, double horizontalAmount, double verticalAmount, CallbackInfoReturnable<Boolean> cir) {
        if (!((Object) this instanceof class_10260<?>)) return;

        class_507<?> recipeBook = ((RecipeBookScreenAccessor) this).rbip$getRecipeBook();
        if (((RecipeBookScrollAccess) recipeBook).rbip$scrollPages(mouseX, mouseY, verticalAmount)) {
            cir.setReturnValue(true);
        }
    }
}
