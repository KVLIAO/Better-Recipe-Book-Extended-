package com.alonie.recipebookispain_extended.mixin.widget;

import com.alonie.recipebookispain_extended.RecipeBookIsPain;
import com.alonie.recipebookispain_extended.access.RecipeGroupButtonPlacement;
import com.alonie.recipebookispain_extended.access.RecipeGroupButtonPlacementAccess;
import net.minecraft.class_10287;
import net.minecraft.class_10799;
import net.minecraft.class_1761;
import net.minecraft.class_2960;
import net.minecraft.class_299;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_4185;
import net.minecraft.class_507;
import net.minecraft.class_512;
import net.minecraft.class_8666;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_512.class)
public abstract class RecipeGroupButtonMixin extends class_344 implements RecipeGroupButtonPlacementAccess {
    @Unique private static final int RBIP_TAB_WIDTH = 35;
    @Unique private static final int RBIP_TAB_HEIGHT = 27;
    @Unique private static final int RBIP_ROTATED_TAB_WIDTH = 27;
    @Unique private static final int RBIP_ROTATED_TAB_HEIGHT = 35;
    @Unique private static final class_2960 RBIP_BOTTOM_TAB = class_2960.method_60655("recipe-book-is-pain-extended", "textures/rbip/bottom_tab.png");
    @Unique private static final class_2960 RBIP_BOTTOM_TAB_SELECTED = class_2960.method_60655("recipe-book-is-pain-extended", "textures/rbip/bottom_tab_selected.png");
    @Unique private static final class_2960 RBIP_TOP_TAB = class_2960.method_60655("recipe-book-is-pain-extended", "textures/rbip/top_tab.png");
    @Unique private static final class_2960 RBIP_TOP_TAB_SELECTED = class_2960.method_60655("recipe-book-is-pain-extended", "textures/rbip/top_tab_selected.png");

    @Unique private RecipeGroupButtonPlacement rbip$placement = RecipeGroupButtonPlacement.NORMAL;

    @Shadow @Final private class_507.class_10329 tabInfo;
    @Shadow private float animationTime;
    @Shadow private boolean selected;

    @Shadow public abstract class_10287 getCategory();

    public RecipeGroupButtonMixin(int x, int y, int width, int height, class_8666 sprites, class_4185.class_4241 onPress) {
        super(x, y, width, height, sprites, onPress);
    }

    @Override
    public void rbip$setPlacement(RecipeGroupButtonPlacement placement) {
        this.rbip$placement = placement;
    }

    @Override
    public RecipeGroupButtonPlacement rbip$getPlacement() {
        return this.rbip$placement;
    }

    @Inject(at = @At("HEAD"), method = "startAnimation", cancellable = true)
    private void rbip$skipCreativeTabUnlockBounce(class_299 recipeBook, boolean filteringCraftable, CallbackInfo ci) {
        if (RecipeBookIsPain.toItemGroup(this.getCategory()) != null) {
            ci.cancel();
        }
    }

    @Inject(at = @At("HEAD"), method = "renderContents", cancellable = true)
    private void rbip$drawRotatedButton(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (this.rbip$placement == RecipeGroupButtonPlacement.NORMAL) return;

        boolean pushed = false;
        if (this.animationTime > 0.0F) {
            float scale = 1.0F + 0.1F * (float) Math.sin(this.animationTime / 15.0F * (float) Math.PI);
            context.method_51448().pushMatrix();
            context.method_51448().translate(this.method_46426() + 8, this.method_46427() + 12);
            context.method_51448().scale(1.0F, scale);
            context.method_51448().translate(-(this.method_46426() + 8), -(this.method_46427() + 12));
            pushed = true;
        }

        this.rbip$drawRotatedBackground(context);
        this.rbip$renderIconsAt(context, this.rbip$getRotatedIconX(), this.rbip$getRotatedIconY());

        if (pushed) {
            context.method_51448().popMatrix();
            this.animationTime -= delta;
        }

        ci.cancel();
    }

    @Inject(at = @At("HEAD"), method = "renderIcon", cancellable = true)
    private void rbip$render(class_332 context, CallbackInfo ci) {
        class_1761 group = RecipeBookIsPain.toItemGroup(this.getCategory());
        if (group == null) return;

        int i = this.selected ? -2 : 0;

        if (RecipeBookIsPain.isOwOLoaded) {
            if (RecipeBookIsPain.rbip$renderOwo(context, i, (class_512) (Object) this, group)) {
                ci.cancel();
            }
        }
    }

    @Unique
    private void rbip$drawRotatedBackground(class_332 context) {
        int localX = this.selected ? -2 : 0;
        context.method_51448().pushMatrix();
        if (this.rbip$placement == RecipeGroupButtonPlacement.BOTTOM) {
            context.method_51448().translate(this.method_46426(), this.method_46427() + RBIP_ROTATED_TAB_HEIGHT);
            context.method_51448().rotate(-(float) Math.PI / 2.0F);
        } else {
            context.method_51448().translate(this.method_46426() + RBIP_ROTATED_TAB_WIDTH, this.method_46427());
            context.method_51448().rotate((float) Math.PI / 2.0F);
        }
        class_2960 texture = this.rbip$getRotatedTexture();
        if (texture.method_12832().startsWith("textures/")) {
            context.method_25290(class_10799.field_56883, texture, localX, 0, 0.0F, 0.0F, RBIP_TAB_WIDTH, RBIP_TAB_HEIGHT, RBIP_TAB_WIDTH, RBIP_TAB_HEIGHT);
        } else {
            context.method_52706(class_10799.field_56883, texture, localX, 0, RBIP_TAB_WIDTH, RBIP_TAB_HEIGHT);
        }
        context.method_51448().popMatrix();
    }

    @Unique
    private class_2960 rbip$getRotatedTexture() {
        if (this.rbip$placement == RecipeGroupButtonPlacement.TOP) {
            return this.selected ? RBIP_TOP_TAB_SELECTED : RBIP_TOP_TAB;
        }
        if (this.rbip$placement == RecipeGroupButtonPlacement.BOTTOM) {
            return this.selected ? RBIP_BOTTOM_TAB_SELECTED : RBIP_BOTTOM_TAB;
        }
        return this.field_45356.method_52729(true, this.selected);
    }

    @Unique
    private void rbip$renderIconsAt(class_332 context, int x, int y) {
        class_1761 group = RecipeBookIsPain.toItemGroup(this.getCategory());
        if (group != null && RecipeBookIsPain.isOwOLoaded && RecipeBookIsPain.rbip$renderOwo(context, x, y, group)) {
            return;
        }

        if (this.tabInfo.comp_3288().isPresent()) {
            context.method_51445(this.tabInfo.comp_3287(), this.method_46426(), y);
            context.method_51445(this.tabInfo.comp_3288().get(), this.method_46426() + 11, y);
        } else {
            context.method_51445(this.tabInfo.comp_3287(), x, y);
        }
    }

    @Unique
    private int rbip$getRotatedIconX() {
        int offset = this.rbip$placement == RecipeGroupButtonPlacement.TOP ? 1 : 0;
        return this.method_46426() + (RBIP_ROTATED_TAB_WIDTH - 16) / 2 + offset;
    }

    @Unique
    private int rbip$getRotatedIconY() {
        int y = this.method_46427() + (RBIP_ROTATED_TAB_HEIGHT - 16) / 2;
        if (this.rbip$placement == RecipeGroupButtonPlacement.TOP) {
            return y - 1;
        }
        if (this.rbip$placement == RecipeGroupButtonPlacement.BOTTOM) {
            return y + 1;
        }
        return y;
    }
}
