package com.alonie.recipebookispain_extended;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import com.alonie.recipebookispain_extended.access.ItemAccess;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_10287;
import net.minecraft.class_10331;
import net.minecraft.class_10355;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_507;
import net.minecraft.class_512;
import net.minecraft.class_7701;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class RecipeBookIsPain {

    public static final Logger LOGGER = LogManager.getLogger("RBIP");
    public static PlatformAbstractions PLATFORM;
    public static boolean isOwOLoaded = false;

    public static final List<class_10287> CRAFTING_SEARCH_LIST = new ArrayList<>();
    public static final List<class_10287> CRAFTING_LIST = new ArrayList<>();

    public static final BiMap<class_10287, class_1761> RECIPE_BOOK_GROUP_TO_ITEM_GROUP = HashBiMap.create();
    private static final List<class_1761> MIRRORED_ITEM_GROUPS = new ArrayList<>();
    private static boolean initialized;

    private static final Map<String, class_1761> namespaceCache = new HashMap<>();
    private static boolean namespaceCacheBuilt;

    // ------------------------------------------------
    //  Initialisation
    // ------------------------------------------------

    public static synchronized void ensureInitialized() {
        if (initialized) return;

        class_310 client = class_310.method_1551();
        if (client == null || client.field_1687 == null) {
            LOGGER.debug("[RBIP] Delaying recipe book init until a client world is available");
            return;
        }

        try {
            class_7706.method_47330(class_7701.field_40183, false, client.field_1687.method_30349());
        } catch (Exception e) {
            LOGGER.warn("[RBIP] Could not refresh creative item groups before building recipe book tabs", e);
        }

        // --- Phase 1: standard search-tab scanning ---
        class_7706.method_47341().stream().filter(RecipeBookIsPain::shouldMirror).forEach(tab -> {
            try {
                tab.method_45414().stream()
                        .filter(stack -> !stack.method_7960())
                        .map(class_1799::method_7909)
                        .map(ItemAccess.class::cast)
                        .filter(access -> access.rbip$getPossibleGroup().isEmpty())
                        .forEach(access -> access.rbip$setPossibleGroup(tab));

                class_10287 recipeBookGroup = new class_10355();
                RECIPE_BOOK_GROUP_TO_ITEM_GROUP.put(recipeBookGroup, tab);
                MIRRORED_ITEM_GROUPS.add(tab);
                CRAFTING_LIST.add(recipeBookGroup);
                CRAFTING_SEARCH_LIST.add(recipeBookGroup);
            } catch (Exception e) {
                LOGGER.error("[RBIP] Error while processing {} item group", tab.method_7737(), e);
            }
        });

        initialized = true;

        // --- Phase 2: namespace-based override ---
        buildNamespaceCache();
        applyNamespaceOverrides();

        LOGGER.info("[RBIP] recipe book init complete; mirrored {} creative groups", MIRRORED_ITEM_GROUPS.size());
    }

    // ------------------------------------------------
    //  Namespace cache
    // ------------------------------------------------

    public static synchronized void buildNamespaceCache() {
        namespaceCache.clear();
        for (class_1761 group : class_7706.method_47341()) {
            if (group.method_47312() == class_1761.class_7916.field_41053
                    || group.method_47312() == class_1761.class_7916.field_41054
                    || group.method_47312() == class_1761.class_7916.field_41055) {
                continue;
            }
            class_2960 regId = class_7923.field_44687.method_10221(group);
            if (regId != null) {
                namespaceCache.put(regId.method_12832(), group);
            }
            String displayKey = normalizeGroupName(group.method_7737().getString());
            if (!displayKey.isEmpty()) {
                namespaceCache.put(displayKey, group);
            }
        }
        namespaceCacheBuilt = true;
    }

    public static class_1761 lookupByNamespace(String itemNamespace) {
        if (!namespaceCacheBuilt) buildNamespaceCache();
        return namespaceCache.get(itemNamespace);
    }

    public static synchronized void applyNamespaceOverrides() {
        if (!namespaceCacheBuilt) buildNamespaceCache();
        int overridden = 0;
        for (class_1792 item : class_7923.field_41178) {
            class_2960 id = class_7923.field_41178.method_10221(item);
            if (id == null) continue;
            class_1761 group = namespaceCache.get(id.method_12836());
            if (group == null) continue;
            ((ItemAccess) item).rbip$setPossibleGroup(group);
            overridden++;
        }
        if (overridden > 0) {
            LOGGER.info("[RBIP] Namespace override: {} items rerouted to their own creative tabs", overridden);
        }
    }

    public static int getNamespaceCacheSize() {
        return namespaceCache.size();
    }

    private static String normalizeGroupName(String name) {
        return name.toLowerCase().replaceAll("[^a-z0-9_\\u4e00-\\u9fff]", "");
    }

    // ------------------------------------------------
    //  Group mirroring helpers
    // ------------------------------------------------

    private static boolean shouldMirror(class_1761 tab) {
        return tab.method_47312() != class_1761.class_7916.field_41053
                && tab.method_47312() != class_1761.class_7916.field_41054
                && tab.method_47312() != class_1761.class_7916.field_41055;
    }

    public static void registerNewGroup(class_1761 group) {
        if (!shouldMirror(group)) return;
        if (RECIPE_BOOK_GROUP_TO_ITEM_GROUP.inverse().containsKey(group)) return;
        class_10287 rg = new class_10355();
        RECIPE_BOOK_GROUP_TO_ITEM_GROUP.put(rg, group);
        MIRRORED_ITEM_GROUPS.add(group);
        CRAFTING_LIST.add(rg);
        CRAFTING_SEARCH_LIST.add(rg);
        LOGGER.info("[RBIP] Late-registered group: {}", group.method_7737().getString());
    }

    public static int getMirroredGroupCount() {
        return MIRRORED_ITEM_GROUPS.size();
    }

    // ------------------------------------------------
    //  Lookup
    // ------------------------------------------------

    public static class_1761 toItemGroup(class_10287 recipeBookGroup) {
        return RECIPE_BOOK_GROUP_TO_ITEM_GROUP.get(recipeBookGroup);
    }

    public static class_10287 toRecipeBookGroup(class_1761 tab) {
        return RECIPE_BOOK_GROUP_TO_ITEM_GROUP.inverse().get(tab);
    }

    public static class_10287 toRecipeBookGroup(class_1799 stack) {
        ensureInitialized();
        if (stack.method_7960()) return null;

        class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
        if (id != null) {
            class_1761 nsGroup = namespaceCache.get(id.method_12836());
            if (nsGroup != null) {
                return toRecipeBookGroup(nsGroup);
            }
        }

        return ((ItemAccess) stack.method_7909()).rbip$getPossibleGroup()
                .map(RecipeBookIsPain::toRecipeBookGroup)
                .orElse(null);
    }

    // ------------------------------------------------
    //  Tab building
    // ------------------------------------------------

    public static List<class_507.class_10329> withCreativeTabs(List<class_507.class_10329> tabs) {
        ensureInitialized();
        List<class_507.class_10329> expandedTabs = new ArrayList<>();
        tabs.stream()
                .filter(tab -> tab.comp_3289() instanceof class_10331)
                .findFirst()
                .ifPresent(expandedTabs::add);

        for (class_1761 tab : MIRRORED_ITEM_GROUPS) {
            Optional.ofNullable(toRecipeBookGroup(tab))
                    .map(group -> new class_507.class_10329(tab.method_7747(), Optional.empty(), group))
                    .ifPresent(expandedTabs::add);
        }
        return expandedTabs;
    }

    // ------------------------------------------------
    //  Icon rendering — owo-lib animated icons
    // ------------------------------------------------

    public static boolean rbip$renderOwo(class_332 context, int i, class_512 widget, class_1761 group) {
        return rbip$renderOwo(context, widget.method_46426() + 9 + i, widget.method_46427() + 5, group);
    }

    public static boolean rbip$renderOwo(class_332 context, int x, int y, class_1761 group) {
        // owo-lib not bundled — use standard icon rendering
        return false;
    }

}
