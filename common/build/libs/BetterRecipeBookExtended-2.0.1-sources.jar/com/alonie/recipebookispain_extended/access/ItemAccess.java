package com.alonie.recipebookispain_extended.access;

import java.util.Optional;
import net.minecraft.class_1761;

public interface ItemAccess {
    Optional<class_1761> rbip$getPossibleGroup();
    void rbip$setPossibleGroup(class_1761 group);
}
