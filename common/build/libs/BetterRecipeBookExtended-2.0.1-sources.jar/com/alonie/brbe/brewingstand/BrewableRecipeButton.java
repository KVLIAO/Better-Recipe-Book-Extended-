package com.alonie.brbe.brewingstand;

import com.google.common.collect.Lists;
import com.alonie.brbe.generic.GenericRecipeButton;
import com.alonie.brbe.util.ClientCompat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1708;
import net.minecraft.class_1799;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_6381;
import net.minecraft.class_6382;
import net.minecraft.class_9334;
import java.util.List;
import java.util.function.Supplier;

import static com.alonie.brbe.brewingstand.PlatformPotionUtil.getIngredient;

@Environment(EnvType.CLIENT)
public class BrewableRecipeButton extends GenericRecipeButton<BrewingRecipeCollection, BrewableResult, class_1708> {
    public BrewableRecipeButton(class_5455 registryAccess, Supplier<Boolean> rememberedFilteringSupplier) {
        super(registryAccess, rememberedFilteringSupplier);
    }

    @Override
    public void method_47399(class_6382 builder) {
        class_1799 inputStack = this.collection.getFirst().inputAsItemStack(category);

        builder.method_37034(class_6381.field_33788, class_2561.method_43469("narration.recipe", inputStack.method_7964()));
        builder.method_37034(class_6381.field_33791, class_2561.method_43471("narration.button.usage.hovered"));
    }

    @Override
    public List<class_2561> getTooltipText() {
        List<class_2561> list = Lists.newArrayList();

        class_1799 resultStack = this.collection.getFirst().getResult(this.registryAccess, this.category);
        list.add(resultStack.method_7964());
        class_1844.method_8065(
                resultStack.method_58695(class_9334.field_49651, class_1844.field_49274).method_57397(),
                list::add,
                1F,
                class_310.method_1551().field_1687.method_54719().method_54748()
        );
        list.add(class_2561.method_43473());

        class_124 colour = this.collection.getFirst().hasIngredient(this.menu.field_7761) ? class_124.field_1068 : class_124.field_1063;
        list.add(class_2561.method_43470(ClientCompat.firstIngredientItem(getIngredient(this.collection.getFirst().recipe)).method_7964().getString()).method_27692(colour));
        list.add(class_2561.method_43470("->").method_27692(class_124.field_1063));

        class_1799 inputStack = this.collection.getFirst().inputAsItemStack(this.category);
        if (!this.collection.getFirst().hasInput(this.category, this.menu.field_7761)) {
            colour = class_124.field_1063;
        }
        list.add(class_2561.method_43470(inputStack.method_7964().getString()).method_27692(colour));

        this.addPinTooltip(list);
        return list;
    }
}
