package com.alonie.brbe.brewingstand;

import java.util.List;
import net.minecraft.class_1842;
import net.minecraft.class_1856;
import net.minecraft.class_638;

public class PlatformPotionUtil {
    private static PotionUtilProvider provider;

    public static void setProvider(PotionUtilProvider p) {
        provider = p;
    }

    public static class_1856 getIngredient(Object recipe) {
        if (provider == null) throw new IllegalStateException("PlatformPotionUtil provider not set");
        return provider.getIngredient(recipe);
    }

    public static class_1842 getTo(Object recipe) {
        if (provider == null) throw new IllegalStateException("PlatformPotionUtil provider not set");
        return provider.getTo(recipe);
    }

    public static class_1842 getFrom(Object recipe) {
        if (provider == null) throw new IllegalStateException("PlatformPotionUtil provider not set");
        return provider.getFrom(recipe);
    }

    public static List<?> getPotionMixes(class_638 level) {
        if (provider == null) throw new IllegalStateException("PlatformPotionUtil provider not set");
        return provider.getPotionMixes(level);
    }

    public interface PotionUtilProvider {
        class_1856 getIngredient(Object recipe);
        class_1842 getTo(Object recipe);
        class_1842 getFrom(Object recipe);
        List<?> getPotionMixes(class_638 level);
    }
}
