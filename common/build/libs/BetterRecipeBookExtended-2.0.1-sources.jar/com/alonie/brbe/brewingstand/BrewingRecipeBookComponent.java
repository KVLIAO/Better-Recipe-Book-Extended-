package com.alonie.brbe.brewingstand;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.api.BRBBookSettings;
import com.alonie.brbe.generic.GenericRecipeBookComponent;
import com.alonie.brbe.generic.GenericRecipePage;
import com.alonie.brbe.interfaces.IPinningComponent;
import com.alonie.brbe.loaders.PotionLoader;
import com.alonie.brbe.mixins.accessors.BrewingStandMenuAccessor;
import com.alonie.brbe.util.BRBHelper;
import com.alonie.brbe.util.ClientCompat;
import com.alonie.brbe.util.ClientInventoryUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1708;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5455;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;

import static com.alonie.brbe.brewingstand.PlatformPotionUtil.getFrom;
import static com.alonie.brbe.brewingstand.PlatformPotionUtil.getIngredient;

@Environment(EnvType.CLIENT)
public class BrewingRecipeBookComponent extends GenericRecipeBookComponent<class_1708, BrewingRecipeCollection, BrewableResult> implements IPinningComponent<BrewingRecipeCollection> {
    private static final class_2561 ONLY_CRAFTABLES_TOOLTIP = class_2561.method_43471("brbe.gui.togglePotions.brewable");

    @Override
    public void init(int parentWidth, int parentHeight, class_310 client, boolean narrow, class_1708 menu, Consumer<class_1799> onGhostRecipeUpdate, class_5455 registryAccess) {
        super.init(parentWidth, parentHeight, client, narrow, menu, onGhostRecipeUpdate, registryAccess);

        this.recipesPage = new GenericRecipePage<>(registryAccess, () -> new BrewableRecipeButton(registryAccess, () -> BRBBookSettings.isFiltering(this.getRecipeBookType())));
        // this.cachedInvChangeCount = client.player.getInventory().getChangeCount();

//        if (this.isVisible()) {
        this.initVisuals();
//        }

        ghostRecipe.setRenderingPredicate((type, ingredient) -> {
            class_1799 slot = menu.field_7761.get(ingredient.getContainerSlot()).method_7677();
            switch (type) {
                case ITEM, BACKGROUND -> {
                    // slot 0 is the result so map it to 1
                    class_1799 ghost = ingredient.getContainerSlot() == BrewingStandMenuAccessor.getBOTTLE_SLOT_START() ? ingredient.getOwner().getBySlot(1).getItem() : ingredient.getItem();

                    // slot is result
                    if (ingredient.getContainerSlot() >= BrewingStandMenuAccessor.getBOTTLE_SLOT_START() && ingredient.getContainerSlot() <= BrewingStandMenuAccessor.getBOTTLE_SLOT_END()) {
                        if (!(slot.method_7909() instanceof class_1812)) return true;

                        var slotPotion = slot.method_58694(class_9334.field_49651);
                        var ghostPotion = ghost.method_58694(class_9334.field_49651);

                        return !Objects.equals(slotPotion, ghostPotion);
                    } else { // else it's the consumable item
                        return !slot.method_31574(ghost.method_7909());
                    }
                }
                case TOOLTIP -> {
                    // render tooltip only if slot is empty
                    return slot.method_7960();
                }
            }
            return true;
        });

        // still required?
        //client.keyboardHandler.setSendRepeatsToGui(true);
    }

    public class_1799 getInputStack(BrewableResult result) {
        class_1842 inputPotion = getFrom(result.recipe);
        class_1856 ingredient = getIngredient(result.recipe);
        //Identifier identifier = BuiltInRegistries.POTION.getKey(inputPotion);
        class_1799 inputStack;
        if (this.selectedTab.getCategory() == BetterRecipeBook.BREWING_SPLASH_POTION) {
            inputStack = new class_1799(class_1802.field_8436);
        } else if (this.selectedTab.getCategory() == BetterRecipeBook.BREWING_LINGERING_POTION) {
            inputStack = new class_1799(class_1802.field_8150);
        } else {
            inputStack = new class_1799(class_1802.field_8574);
        }

        inputStack.method_57379(class_9334.field_49651, new class_1844(class_7923.field_41179.method_47983(inputPotion)));
        return inputStack;
    }

    public void setupGhostRecipe(BrewableResult result, List<class_1735> slots) {
        this.ghostRecipe.addIngredient(BrewingStandMenuAccessor.getINGREDIENT_SLOT(), ClientCompat.firstIngredientItem(getIngredient(result.recipe)), slots.get(BrewingStandMenuAccessor.getINGREDIENT_SLOT()).field_7873, slots.get(BrewingStandMenuAccessor.getINGREDIENT_SLOT()).field_7872);

        assert selectedTab != null;
        class_1799 inputStack = result.inputAsItemStack(selectedTab.getCategory());

        for (int i = BrewingStandMenuAccessor.getBOTTLE_SLOT_START(); i <= BrewingStandMenuAccessor.getBOTTLE_SLOT_END(); i++) {
            this.ghostRecipe.addIngredient(i, inputStack.method_7972(), slots.get(i).field_7873, slots.get(i).field_7872);
        }
    }

    @Override
    protected List<BrewingRecipeCollection> getCollectionsForCategory() {
        List<BrewingRecipeCollection> results = new ArrayList<>();
        BRBBookCategories.Category category = selectedTab.getCategory();

        for (BrewableResult potion : PotionLoader.POTIONS) {
            results.add(new BrewingRecipeCollection(List.of(potion), menu, registryAccess, category));
        }

        return results;
    }

    @Override
    public class_2561 getRecipeFilterName() {
        return ONLY_CRAFTABLES_TOOLTIP;
    }

    @Override
    public BRBHelper.Book getRecipeBookType() {
        return BetterRecipeBook.BREWING;
    }

    @Override
    public void handlePlaceRecipe() {
        BrewableResult result = this.recipesPage.getCurrentClickedRecipe();

        if (result == null) return;

        this.ghostRecipe.clear();

        if (!result.hasMaterials(this.selectedTab.getCategory(), menu.field_7761)) {
            setupGhostRecipe(result, menu.field_7761);
            return;
        }

        class_1799 inputStack = getInputStack(result);
        class_1856 ingredient = getIngredient(result.recipe);

        int slotIndex = 0;
        int usedInputSlots = 0;
        for (class_1735 slot : menu.field_7761) {
            class_1799 itemStack = slot.method_7677();

            if (class_1799.method_31577(inputStack, itemStack)) {
                if (usedInputSlots <= 2) {
                    assert class_310.method_1551().field_1761 != null;
                    ClientInventoryUtil.storeItem(-1, i -> i > 4);
                    class_310.method_1551().field_1761.method_2906(menu.field_7763, menu.method_7611(slotIndex).field_7874, 0, class_1713.field_7790, class_310.method_1551().field_1724);
                    class_310.method_1551().field_1761.method_2906(menu.field_7763, menu.method_7611(usedInputSlots).field_7874, 0, class_1713.field_7790, class_310.method_1551().field_1724);
                    ClientInventoryUtil.storeItem(-1, i -> i > 4);
                    ++usedInputSlots;
                }
            } else if (ClientCompat.firstIngredientItem(ingredient).method_7909().equals(slot.method_7677().method_7909())) {
                assert class_310.method_1551().field_1761 != null;
                ClientInventoryUtil.storeItem(-1, i -> i > 4);
                class_310.method_1551().field_1761.method_2906(menu.field_7763, menu.method_7611(slotIndex).field_7874, 0, class_1713.field_7790, class_310.method_1551().field_1724);
                class_310.method_1551().field_1761.method_2906(menu.field_7763, menu.method_7611(3).field_7874, 0, class_1713.field_7790, class_310.method_1551().field_1724);
                ClientInventoryUtil.storeItem(-1, i -> i > 4);
            }

            ++slotIndex;
        }

        this.updateCollections(false);
    }

    public void recipesUpdated() {
        updateCollections(false);
    }

}
