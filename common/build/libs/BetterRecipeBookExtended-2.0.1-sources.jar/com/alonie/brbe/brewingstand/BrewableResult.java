package com.alonie.brbe.brewingstand;

import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.generic.GenericRecipe;
import com.alonie.brbe.util.ClientCompat;
import java.util.List;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import net.minecraft.class_7923;

import static com.alonie.brbe.brewingstand.PlatformPotionUtil.*;

public class BrewableResult implements GenericRecipe {
    public Object recipe;
    public class_2960 input;

    public BrewableResult(Object recipe) {
        this.recipe = recipe;
        this.input = class_7923.field_41179.method_10221(getFrom(recipe));
    }

    public boolean hasIngredient(List<class_1735> slots) {
        for (class_1799 itemStack : ClientCompat.ingredientItems(getIngredient(recipe))) {
            for (class_1735 slot : slots) {
                if (itemStack.method_7909().equals(slot.method_7677().method_7909())) return true;
            }
        }
        return false;
    }

    public class_1799 inputAsItemStack(BRBBookCategories.Category category) {
        class_1842 inputPotion = getFrom(recipe);

        var potionItem = category.getItemIcons().getFirst().method_7909();
        return potionStackFromPotion(potionItem, inputPotion);
    }

    public boolean hasInput(BRBBookCategories.Category category, List<class_1735> slots) {
        class_1799 inputStack = inputAsItemStack(category);

        for (class_1735 slot : slots) {
            class_1799 itemStack = slot.method_7677();

            if (class_1799.method_31577(inputStack, itemStack))
                return true;
        }

        return false;
    }

    public boolean hasMaterials(BRBBookCategories.Category category, List<class_1735> slots) {
        boolean hasIngredient = hasIngredient(slots);
        boolean hasInput = hasInput(category, slots);

        return hasIngredient && hasInput;
    }

    public boolean hasPartialMaterials(BRBBookCategories.Category category, List<class_1735> slots) {
        return hasIngredient(slots) || hasInput(category, slots);
    }

    @Override
    public class_2960 id() {
        return class_7923.field_41179.method_10221(getTo(recipe));
    }

    public class_2561 getHoverName(BRBBookCategories.Category category) {
        var resultPotion = getTo(recipe);
        var potionItem = category.getItemIcons().getFirst().method_7909();
        return potionStackFromPotion(potionItem, resultPotion).method_7964();
    }

    @Override
    public class_1799 getResult(class_5455 registryAccess, BRBBookCategories.Category category) {
        var resultPotion = getTo(recipe);
        var potionItem = category.getItemIcons().getFirst().method_7909();
        return potionStackFromPotion(potionItem, resultPotion);
    }

    @Override
    public String getSearchString(BRBBookCategories.Category category) {
        return getHoverName(category).getString();
    }

    public static class_1799 potionStackFromPotion(class_1792 item, class_1842 pot) {
        return class_1844.method_57400(item, class_7923.field_41179.method_47983(pot));
    }
}
