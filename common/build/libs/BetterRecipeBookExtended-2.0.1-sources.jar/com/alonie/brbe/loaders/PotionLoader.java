package com.alonie.brbe.loaders;

import dev.architectury.event.events.client.ClientLifecycleEvent;
import dev.architectury.event.events.common.LifecycleEvent;
import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.brewingstand.BrewableResult;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_638;

import static com.alonie.brbe.brewingstand.PlatformPotionUtil.getPotionMixes;

public class PotionLoader {
    public static List<BrewableResult> POTIONS = new ArrayList<>();

    public static void init() {
        // Architectury calls CLIENT_LEVEL_LOAD before Minecraft#level is set. (as of version 12.0.27)
        // This means when PlatformPotionUtilImpl tries to access Minecraft#level it is null.
        // for this reason we need to forward the ClientLevel to the method
        ClientLifecycleEvent.CLIENT_LEVEL_LOAD.register(PotionLoader::load);
        LifecycleEvent.SERVER_LEVEL_UNLOAD.register((clientLevel) -> PotionLoader.clear());
    }

    private static void load(class_638 level) {
        PotionLoader.clearNoLog();

        List<?> MIXES = getPotionMixes(level);

        for (Object potionRecipe : MIXES) {
            POTIONS.add(new BrewableResult(potionRecipe));
        }

        BetterRecipeBook.LOGGER.info("Loaded %d potions.".formatted(POTIONS.size()));
    }

    public static void clear() {
        BetterRecipeBook.LOGGER.info("Clearing potions...");
        clearNoLog();
    }

    private static void clearNoLog() {
        POTIONS.clear();
    }
}
