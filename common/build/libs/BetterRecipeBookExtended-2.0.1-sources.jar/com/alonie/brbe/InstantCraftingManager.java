package com.alonie.brbe;

import com.alonie.brbe.util.ClientInventoryUtil;
import com.alonie.brbe.util.RecipeMenuUtil;
import net.minecraft.class_10298;
import net.minecraft.class_1713;
import net.minecraft.class_1720;
import net.minecraft.class_1729;
import net.minecraft.class_1799;
import net.minecraft.class_310;

public class InstantCraftingManager {
    public Object lastInstantCraftButton = null;
    public Object lastHoveredCollection = null;

    private boolean awaitingResultSlotUpdate;
    private boolean craftAll;
    private boolean applyingInstantCraft;
    private int containerId = -1;
    public class_10298 lastClickedRecipe;

    public void recipeClicked(class_10298 recipe, boolean craftAll) {
        if (!this.isEnabled()) {
            return;
        }

        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null || minecraft.field_1761 == null) {
            return;
        }

        if (!(minecraft.field_1724.field_7512 instanceof class_1729 menu) || menu instanceof class_1720) {
            return;
        }

        this.lastClickedRecipe = recipe;
        this.awaitingResultSlotUpdate = true;
        this.craftAll = craftAll;
        this.containerId = menu.field_7763;
    }

    public void onResultSlotUpdated(class_1799 itemStack) {
        if (!this.awaitingResultSlotUpdate || this.applyingInstantCraft || itemStack == null || itemStack.method_7960()) {
            return;
        }

        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null || minecraft.field_1761 == null) {
            this.clearPending();
            return;
        }

        if (!(minecraft.field_1724.field_7512 instanceof class_1729 menu) || menu.field_7763 != this.containerId) {
            this.clearPending();
            return;
        }

        this.applyingInstantCraft = true;
        try {
            if (!menu.method_34255().method_7960()) {
                ClientInventoryUtil.storeItem(-1, idx -> !RecipeMenuUtil.isCraftingMenuSlot(menu, idx));
            }

            if (this.craftAll) {
                minecraft.field_1761.method_2906(menu.field_7763, 0, 0, class_1713.field_7794, minecraft.field_1724);
            } else {
                minecraft.field_1761.method_2906(menu.field_7763, 0, 0, class_1713.field_7790, minecraft.field_1724);
                ClientInventoryUtil.storeItem(-1, idx -> !RecipeMenuUtil.isCraftingMenuSlot(menu, idx));
            }
        } finally {
            this.applyingInstantCraft = false;
            this.clearPending();
        }
    }

    public boolean toggleEnabled() {
        BetterRecipeBook.config.instantCraft.enabled = !BetterRecipeBook.config.instantCraft.enabled;
        BetterRecipeBook.configHolder.save();
        return isEnabled();
    }

    public boolean isEnabled() {
        return BetterRecipeBook.config.instantCraft.enabled;
    }

    private void clearPending() {
        this.awaitingResultSlotUpdate = false;
        this.craftAll = false;
        this.containerId = -1;
    }
}
