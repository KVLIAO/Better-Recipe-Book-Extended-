package com.alonie.brbe.smithingtable;

import com.google.common.collect.Lists;
import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.api.BRBBookSettings;
import com.alonie.brbe.recipe.BRBSmithingRecipe;
import com.alonie.brbe.util.AlternativeOverlayLayout;
import com.alonie.brbe.util.BRBTextures;
import com.alonie.brbe.util.ClientCompat;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_11910;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_5244;
import net.minecraft.class_5455;
import net.minecraft.class_6382;
import net.minecraft.class_8030;

public class SmithingOverlayRecipeComponent implements class_4068, class_364 {
    private static final class_2960 OVERLAY_RECIPE_SPRITE = class_2960.method_60656("recipe_book/overlay_recipe");

    private final List<OverlayRecipeButton> recipeButtons = Lists.newArrayList();
    private BRBSmithingRecipe lastRecipeClicked;
    private SmithingRecipeCollection collection;
    private boolean visible;
    private float time;
    private int x;
    private int y;

    public void init(SmithingRecipeCollection recipeCollection, int x, int y, class_5455 registryAccess) {
        this.collection = recipeCollection;

        List<BRBSmithingRecipe> lockedRecipes = recipeCollection.getDisplayRecipes(true);
        List<BRBSmithingRecipe> unlockedRecipes;
        if (!BRBBookSettings.isFiltering(BetterRecipeBook.SMITHING)) {
            unlockedRecipes = recipeCollection.getDisplayRecipes(false);
        } else {
            unlockedRecipes = recipeCollection.getPartiallyCraftableRecipes();
        }
        int lockedRecipeCount = lockedRecipes.size();
        int totalRecipeCount = lockedRecipeCount + unlockedRecipes.size();
        int columns = AlternativeOverlayLayout.columnsFor(totalRecipeCount);

        this.x = x + 7;
        this.y = y + 26;
        this.visible = true;
        this.recipeButtons.clear();

        for (int index = 0; index < totalRecipeCount; ++index) {
            boolean isCraftable = index < lockedRecipeCount;
            BRBSmithingRecipe recipe = isCraftable ? lockedRecipes.get(index) : unlockedRecipes.get(index - lockedRecipeCount);
            int buttonX = this.x + 4 + 25 * (index % columns);
            int buttonY = this.y + 5 + 25 * (index / columns);
            this.recipeButtons.add(new OverlayRecipeButton(buttonX, buttonY, recipe, isCraftable, registryAccess));
        }

        this.lastRecipeClicked = null;
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0) {
            return false;
        }

        for (OverlayRecipeButton overlayRecipeButton : this.recipeButtons) {
            if (!overlayRecipeButton.mouseClicked(mouseX, mouseY, button)) {
                continue;
            }
            this.lastRecipeClicked = overlayRecipeButton.recipe;
            return true;
        }

        return false;
    }

    @Nullable
    public BRBSmithingRecipe getLastRecipeClicked() {
        return this.lastRecipeClicked;
    }

    public SmithingRecipeCollection getRecipeCollection() {
        return this.collection;
    }

    public boolean isVisible() {
        return this.visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    @Nullable
    public class_8030 getBounds() {
        if (!this.visible || this.recipeButtons.isEmpty()) {
            return null;
        }

        int columns = AlternativeOverlayLayout.columnsFor(this.recipeButtons.size());
        int visibleColumns = Math.min(this.recipeButtons.size(), columns);
        int rows = class_3532.method_15386((float) this.recipeButtons.size() / (float) columns);
        return new class_8030(this.x, this.y, visibleColumns * 25 + 8, rows * 25 + 8);
    }

    @Override
    public void method_25365(boolean bl) {
    }

    @Override
    public boolean method_25370() {
        return false;
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return false;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float delta) {
        if (!this.visible) {
            return;
        }

        this.time += delta;
        guiGraphics.method_51448().pushMatrix();
        int columns = AlternativeOverlayLayout.columnsFor(this.recipeButtons.size());
        int visibleColumns = Math.min(this.recipeButtons.size(), columns);
        int rows = class_3532.method_15386((float) this.recipeButtons.size() / (float) columns);
        ClientCompat.blitSprite(guiGraphics, OVERLAY_RECIPE_SPRITE, this.x, this.y, visibleColumns * 25 + 8, rows * 25 + 8);

        for (OverlayRecipeButton overlayRecipeButton : this.recipeButtons) {
            overlayRecipeButton.method_25394(guiGraphics, mouseX, mouseY, delta);
        }

        guiGraphics.method_51448().popMatrix();
    }

    public static class OverlayRecipeButton extends class_339 {
        final BRBSmithingRecipe recipe;
        private final boolean craftable;
        private final class_5455 registryAccess;

        public OverlayRecipeButton(int x, int y, BRBSmithingRecipe recipe, boolean craftable, class_5455 registryAccess) {
            super(x, y, 24, 24, class_5244.field_39003);
            this.recipe = recipe;
            this.craftable = craftable;
            this.registryAccess = registryAccess;
        }

        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            return ClientCompat.mouseClicked(this, mouseX, mouseY, button);
        }

        @Override
        protected boolean method_25351(class_11910 button) {
            return button.comp_4801() == 0;
        }

        @Override
        public void method_47399(class_6382 narrationElementOutput) {
            this.method_37021(narrationElementOutput);
        }

        @Override
        public void method_48579(class_332 guiGraphics, int mouseX, int mouseY, float delta) {
            class_2960 sprite = BRBTextures.RECIPE_BOOK_PLAIN_OVERLAY_SPRITE.method_52729(this.craftable, this.method_25367());
            ClientCompat.blitSprite(guiGraphics, sprite, this.method_46426(), this.method_46427(), this.field_22758, this.field_22759);
            guiGraphics.method_51445(this.recipe.getResult(this.registryAccess, BetterRecipeBook.SMITHING_SEARCH), this.method_46426() + 4, this.method_46427() + 4);
        }
    }
}
