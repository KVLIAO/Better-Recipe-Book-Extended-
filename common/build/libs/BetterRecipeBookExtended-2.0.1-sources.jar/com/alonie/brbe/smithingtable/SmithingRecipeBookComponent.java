package com.alonie.brbe.smithingtable;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.api.BRBBookSettings;
import com.alonie.brbe.generic.GenericRecipeBookComponent;
import com.alonie.brbe.recipe.BRBSmithingRecipe;
import com.alonie.brbe.recipe.smithing.BRBSmithingTransformRecipe;
import com.alonie.brbe.recipe.smithing.BRBSmithingTrimRecipe;
import com.alonie.brbe.util.BRBHelper;
import com.alonie.brbe.util.ClientInventoryUtil;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_10297;
import net.minecraft.class_10302;
import net.minecraft.class_10314;
import net.minecraft.class_10352;
import net.minecraft.class_10363;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_314;
import net.minecraft.class_4862;
import net.minecraft.class_516;
import net.minecraft.class_5250;
import net.minecraft.class_5455;
import net.minecraft.class_9334;

public class SmithingRecipeBookComponent extends GenericRecipeBookComponent<class_4862, SmithingRecipeCollection, BRBSmithingRecipe> {
    private static final class_5250 ONLY_CRAFTABLES_TOOLTIP = class_2561.method_43471("brbe.gui.smithable");

    public void init(int width, int height, class_310 minecraft, boolean widthNarrow, class_4862 menu, Consumer<class_1799> onGhostRecipeUpdate, class_5455 registryAccess) {
        super.init(width, height, minecraft, widthNarrow, menu, onGhostRecipeUpdate, registryAccess);

        this.ghostRecipe = new SmithingGhostRecipe(onGhostRecipeUpdate, registryAccess);
        this.ghostRecipe.setDefaultRenderingPredicate(this.menu);
        this.recipesPage = new SmithingRecipeBookPage(registryAccess, () -> BRBBookSettings.isFiltering(getRecipeBookType()));

//        if (this.isVisible()) {
        this.initVisuals();
//        }
    }

    @Override
    public class_2561 getRecipeFilterName() {
        return ONLY_CRAFTABLES_TOOLTIP;
    }

    @Override
    public BRBHelper.Book getRecipeBookType() {
        return BetterRecipeBook.SMITHING;
    }

    @Override
    public void handlePlaceRecipe() {
        BRBSmithingRecipe result = this.recipesPage.getCurrentClickedRecipe();
        SmithingRecipeCollection recipeCollection = this.recipesPage.getLastClickedRecipeCollection();

        if (result == null || recipeCollection == null) return;

        this.ghostRecipe.clear();

        if (!result.hasMaterials(this.menu.field_7761, this.registryAccess)) {
            this.setupGhostRecipe(result, this.menu.field_7761);
            return;
        }

        int slotIndex = 0;
        boolean placedBase = false;
        for (class_1735 slot : menu.field_7761) {
            class_1799 itemStack = slot.method_7677();

            if (result.requiresTemplate() && result.getTemplate().method_8093(itemStack)) {
                assert class_310.method_1551().field_1761 != null;
                ClientInventoryUtil.storeItem(-1, i -> i > 4);
                class_310.method_1551().field_1761.method_2906(menu.field_7763, menu.method_7611(slotIndex).field_7874, 0, class_1713.field_7790, class_310.method_1551().field_1724);
                class_310.method_1551().field_1761.method_2906(menu.field_7763, class_4862.field_41924, 0, class_1713.field_7790, class_310.method_1551().field_1724);
                ClientInventoryUtil.storeItem(-1, i -> i > 4);
            } else if (!placedBase && !itemStack.method_57826(class_9334.field_49607) && result.getBase().method_7909().equals(itemStack.method_7909())) {
                assert class_310.method_1551().field_1761 != null;
                ClientInventoryUtil.storeItem(-1, i -> i > 4);
                class_310.method_1551().field_1761.method_2906(menu.field_7763, menu.method_7611(slotIndex).field_7874, 0, class_1713.field_7790, class_310.method_1551().field_1724);
                class_310.method_1551().field_1761.method_2906(menu.field_7763, class_4862.field_41925, 0, class_1713.field_7790, class_310.method_1551().field_1724);
                ClientInventoryUtil.storeItem(-1, i -> i > 4);
                placedBase = true;
            } else if (result.requiresAddition() && result.getAddition().method_8093(itemStack)) {
                assert class_310.method_1551().field_1761 != null;
                ClientInventoryUtil.storeItem(-1, i -> i > 4);
                class_310.method_1551().field_1761.method_2906(menu.field_7763, menu.method_7611(slotIndex).field_7874, 0, class_1713.field_7790, class_310.method_1551().field_1724);
                class_310.method_1551().field_1761.method_2906(menu.field_7763, class_4862.field_41926, 0, class_1713.field_7790, class_310.method_1551().field_1724);
                ClientInventoryUtil.storeItem(-1, i -> i > 4);
            }

            ++slotIndex;
        }

        this.updateCollections(false);
    }

    public void setupGhostRecipe(BRBSmithingRecipe result, List<class_1735> list) {
        this.ghostRecipe.setRecipe(result);

        if (result.requiresAddition()) {
            this.ghostRecipe.addIngredient(class_4862.field_41926, result.getAddition(), class_4862.field_41930, class_4862.field_41931);
        }
        if (result.requiresTemplate()) {
            this.ghostRecipe.addIngredient(class_4862.field_41924, result.getTemplate(), class_4862.field_41928, class_4862.field_41931);
        }
        this.ghostRecipe.addIngredient(class_4862.field_41925, result.getBase().method_7972(), class_4862.field_41929, class_4862.field_41931);
    }

    public boolean isShowingGhostRecipe() {
        return this.ghostRecipe != null && this.ghostRecipe.size() > 0;
    }

    @Override
    protected List<SmithingRecipeCollection> getCollectionsForCategory() {
        if (this.minecraft.field_1724 == null || this.minecraft.field_1687 == null) {
            return Collections.emptyList();
        }

        List<SmithingRecipeCollection> results = new ArrayList<>();
        BRBBookCategories.Category category = selectedTab.getCategory();
        class_10352 displayContext = class_10363.method_65008(this.minecraft.field_1687);
        List<class_516> collections = this.minecraft.field_1724.method_3130().method_1396(class_314.field_25624);

        for (class_516 collection : collections) {
            List<BRBSmithingRecipe> smithingRecipes = new ArrayList<>();

            for (class_10297 entry : collection.method_2650()) {
                if (!(entry.comp_3263() instanceof class_10314 smithingDisplay)) {
                    continue;
                }

                boolean isTrimRecipe = smithingDisplay.comp_3258() instanceof class_10302.class_10310;
                if (!shouldInclude(category, isTrimRecipe)) {
                    continue;
                }

                if (isTrimRecipe) {
                    smithingRecipes.addAll(BRBSmithingTrimRecipe.from(smithingDisplay, displayContext));
                } else {
                    smithingRecipes.add(BRBSmithingTransformRecipe.from(entry, smithingDisplay, displayContext));
                }
            }

            if (!smithingRecipes.isEmpty()) {
                results.add(new SmithingRecipeCollection(smithingRecipes, this.menu, registryAccess));
            }
        }

        return results;
    }

    private static boolean shouldInclude(BRBBookCategories.Category category, boolean isTrimRecipe) {
        if (category == BetterRecipeBook.SMITHING_SEARCH) {
            return true;
        }

        if (category == BetterRecipeBook.SMITHING_TRANSFORM) {
            return !isTrimRecipe;
        }

        return isTrimRecipe;
    }
}
