package com.alonie.brbe.smithingtable;

import com.alonie.brbe.generic.GenericRecipeButton;
import com.alonie.brbe.generic.GenericRecipePage;
import com.alonie.brbe.recipe.BRBSmithingRecipe;
import java.util.function.Supplier;
import net.minecraft.class_332;
import net.minecraft.class_4862;
import net.minecraft.class_5455;

public class SmithingRecipeBookPage extends GenericRecipePage<class_4862, SmithingRecipeCollection, BRBSmithingRecipe> {
    public final SmithingOverlayRecipeComponent overlay = new SmithingOverlayRecipeComponent();

    public SmithingRecipeBookPage(class_5455 registryAccess, Supplier<Boolean> filteringSupplier) {
        super(registryAccess, () -> new GenericRecipeButton<>(registryAccess, filteringSupplier));
    }

    @Override
    protected boolean overlayMouseClicked(double mouseX, double mouseY, int button, int j, int k, int l, int m) {
        if (this.overlay.mouseClicked(mouseX, mouseY, button)) {
            this.lastClickedRecipe = this.overlay.getLastRecipeClicked();
            this.lastClickedRecipeCollection = this.overlay.getRecipeCollection();
        } else {
            this.overlay.setVisible(false);
        }
        return true;
    }

    @Override
    protected void initOverlay(SmithingRecipeCollection recipeCollection, int x, int y, class_5455 registryAccess) {
        this.overlay.init(recipeCollection, this.parentLeft, this.parentTop, registryAccess);
    }

    @Override
    public void render(class_332 gui, int x, int y, int mouseX, int mouseY, float delta) {
        super.render(gui, x, y, mouseX, mouseY, delta);

        gui.method_71048();
        this.overlay.method_25394(gui, mouseX, mouseY, delta);
    }

    @Override
    public boolean overlayIsVisible() {
        return this.overlay.isVisible();
    }
}
