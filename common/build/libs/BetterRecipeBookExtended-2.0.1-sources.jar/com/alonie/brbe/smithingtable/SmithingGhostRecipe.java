package com.alonie.brbe.smithingtable;

import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.generic.GenericGhostRecipe;
import com.alonie.brbe.recipe.BRBSmithingRecipe;
import com.alonie.brbe.recipe.smithing.BRBSmithingTransformRecipe;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_5455;
import net.minecraft.class_8055;

public class SmithingGhostRecipe extends GenericGhostRecipe<BRBSmithingRecipe> {
    public SmithingGhostRecipe(@Nullable Consumer<class_1799> onGhostUpdate, class_5455 registryAccess) {
        super(onGhostUpdate, registryAccess);
    }

    @Override
    public class_1799 getCurrentResult(BRBBookCategories.Category category) {
        if (this.recipe == null) {
            return class_1799.field_8037;
        }

        if (this.recipe instanceof BRBSmithingTransformRecipe) {
            return this.recipe.getResult(this.registryAccess, category);
        }

        class_1799 materialStack = this.ingredients.isEmpty() ? class_1799.field_8037 : this.ingredients.get(0).getItem();
        if (materialStack.method_31574(class_1802.field_8155)) return this.recipe.getResult(class_8055.field_42004, this.registryAccess, category);
        if (materialStack.method_31574(class_1802.field_8620)) return this.recipe.getResult(class_8055.field_42005, this.registryAccess, category);
        if (materialStack.method_31574(class_1802.field_22020)) return this.recipe.getResult(class_8055.field_42006, this.registryAccess, category);
        if (materialStack.method_31574(class_1802.field_27022)) return this.recipe.getResult(class_8055.field_42008, this.registryAccess, category);
        if (materialStack.method_31574(class_1802.field_8695)) return this.recipe.getResult(class_8055.field_42009, this.registryAccess, category);
        if (materialStack.method_31574(class_1802.field_8687)) return this.recipe.getResult(class_8055.field_42010, this.registryAccess, category);
        if (materialStack.method_31574(class_1802.field_8477)) return this.recipe.getResult(class_8055.field_42011, this.registryAccess, category);
        if (materialStack.method_31574(class_1802.field_8759)) return this.recipe.getResult(class_8055.field_42012, this.registryAccess, category);
        if (materialStack.method_31574(class_1802.field_27063)) return this.recipe.getResult(class_8055.field_42013, this.registryAccess, category);
        if (materialStack.method_31574(class_1802.field_55044)) return this.recipe.getResult(class_8055.field_55049, this.registryAccess, category);
        return this.recipe.getResult(class_8055.field_42007, this.registryAccess, category);
    }
}
