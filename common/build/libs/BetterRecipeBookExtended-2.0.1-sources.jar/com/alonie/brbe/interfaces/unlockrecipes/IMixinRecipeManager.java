package com.alonie.brbe.interfaces.unlockrecipes;

import java.util.Set;
import net.minecraft.class_10298;

/**
 * Access interface for RecipeManagerMixin
 */
public interface IMixinRecipeManager {

    Set<class_10298> betterRecipeBook$getServerUnlockedRecipes();

}
