package com.alonie.brbe.interfaces;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.config.Config;
import com.alonie.brbe.util.BRBTextures;
import com.alonie.brbe.util.ClientCompat;
import me.shedaniel.autoconfig.AutoConfig;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_5250;
import org.jetbrains.annotations.Nullable;

public interface ISettingsButton {
    class_5250 OPEN_SETTINGS_TOOLTIP = class_2561.method_43471("brbe.gui.settings.open");


    default class_344 createSettingsButton(int i, int j) {
        if (BetterRecipeBook.config.settingsButton) {
            return new class_344(i + 11, j + 137, 18, 18, BRBTextures.SETTINGS_BUTTON_SPRITES, button -> {
                class_310.method_1551().method_1507(AutoConfig.getConfigScreen(Config.class, class_310.method_1551().field_1755).get());
            });
        }
        return null;
    }

    default void renderSettingsButton(@Nullable class_344 settingsButton, class_332 gui, int mouseX, int mouseY, float delta) {
        if (settingsButton != null && BetterRecipeBook.config.settingsButton) {
            settingsButton.method_25394(gui, mouseX, mouseY, delta);
        }
    }

    default boolean settingsButtonMouseClicked(@Nullable class_344 settingsButton, double mouseX, double mouseY, int button) {
        if (settingsButton == null || !BetterRecipeBook.config.settingsButton) return false;

        return ClientCompat.mouseClicked(settingsButton, mouseX, mouseY, button);
    }

    // TODO: Remove this and use .setTooltip and render it automatically
    default void renderSettingsButtonTooltip(@Nullable class_344 settingsButton, class_332 gui, int mouseX, int mouseY) {
        if (settingsButton != null && settingsButton.method_25367() && BetterRecipeBook.config.settingsButton
                && class_310.method_1551().field_1755 != null) {
            ClientCompat.setComponentTooltipForNextFrame(gui, java.util.List.of(OPEN_SETTINGS_TOOLTIP), mouseX, mouseY);
        }
    }
}
