package com.alonie.brbe.search;

import java.util.Locale;
import net.minecraft.class_1799;

/**
 * Plain substring match on the item's hover name.
 * This is equivalent to the original simple search behavior.
 */
public class TextArgument implements SearchArgument {
    private final String searchText;

    public TextArgument(String searchText) {
        this.searchText = searchText.toLowerCase(Locale.ROOT);
    }

    @Override
    public boolean matches(class_1799 stack, SearchCache cache) {
        return stack.method_7964().getString().toLowerCase(Locale.ROOT).contains(searchText);
    }

    @Override
    public boolean isAdvanced() {
        return false;
    }

    public String getSearchText() {
        return searchText;
    }
}
