package com.alonie.brbe.search;

import java.util.Locale;
import net.minecraft.class_1799;

/**
 * Searches by item tags. Prefix: $
 * <p>
 * Matches if any tag of the item (e.g., "minecraft:logs", "c:stone")
 * contains the query text.
 */
public class TagArgument implements SearchArgument {
    private final String tagQuery;

    public TagArgument(String tagQuery) {
        this.tagQuery = tagQuery.toLowerCase(Locale.ROOT);
    }

    @Override
    public boolean matches(class_1799 stack, SearchCache cache) {
        for (String tag : cache.getTags(stack)) {
            if (tag.toLowerCase(Locale.ROOT).contains(tagQuery)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isAdvanced() {
        return true;
    }
}
