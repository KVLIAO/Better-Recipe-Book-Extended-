package com.alonie.brbe.search;

import java.util.List;
import net.minecraft.class_1799;

/**
 * OR composition: any child argument matching suffices.
 * Pipe (|) separates AlternativeArgument groups.
 */
public class AlternativeArgument implements SearchArgument {
    private final List<SearchArgument> children;

    public AlternativeArgument(List<SearchArgument> children) {
        this.children = children;
    }

    @Override
    public boolean matches(class_1799 stack, SearchCache cache) {
        if (children.isEmpty()) {
            return true;
        }
        for (SearchArgument child : children) {
            if (child.matches(stack, cache)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean isAdvanced() {
        for (SearchArgument child : children) {
            if (child.isAdvanced()) {
                return true;
            }
        }
        return false;
    }
}
