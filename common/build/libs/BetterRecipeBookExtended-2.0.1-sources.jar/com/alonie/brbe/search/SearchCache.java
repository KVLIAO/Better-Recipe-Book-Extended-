package com.alonie.brbe.search;

import com.alonie.brbe.util.ModNameUtil;
import java.util.*;
import java.util.stream.Collectors;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_7923;

/**
 * Extracts and caches search-relevant data from ItemStacks.
 * <p>
 * Created fresh each search pass to avoid stale data or memory leaks.
 * Uses ItemStack.copy() as cache keys for stable hash/equality.
 */
public class SearchCache {

    // namespace → mod display name
    private final Map<String, String> modNameCache = new HashMap<>();

    // item stack (by copy) → set of tag strings
    private final Map<class_1799, Set<String>> tagsCache = new HashMap<>();

    // item stack (by copy) → concatenated tooltip text
    private final Map<class_1799, String> tooltipCache = new HashMap<>();

    // item → cached namespace (immutable, so safe to cache permanently)
    private final Map<class_1792, String> namespaceCache = new HashMap<>();

    private class_1792.class_9635 tooltipContext;

    private void ensureTooltipContext() {
        if (tooltipContext == null) {
            var level = class_310.method_1551().field_1687;
            if (level != null) {
                tooltipContext = class_1792.class_9635.method_59528(level);
            }
        }
    }

    /**
     * Returns the mod namespace for the given stack's item.
     * e.g., "minecraft", "brbe"
     */
    public String getModNamespace(class_1799 stack) {
        return namespaceCache.computeIfAbsent(stack.method_7909(), item ->
                class_7923.field_41178.method_10221(item).method_12836());
    }

    /**
     * Returns the human-readable mod name for the given stack's item.
     * e.g., "Minecraft", "Better Recipe Book"
     */
    public String getModName(class_1799 stack) {
        String namespace = getModNamespace(stack);
        return modNameCache.computeIfAbsent(namespace, ModNameUtil::resolveModName);
    }

    /**
     * Returns all tag identifiers for the given stack's item.
     * e.g., ["minecraft:logs", "minecraft:oak_logs"]
     */
    public Set<String> getTags(class_1799 stack) {
        return tagsCache.computeIfAbsent(stack.method_7972(), key -> {
            Set<String> tags = new HashSet<>();
            key.method_7909().method_40131().method_40228()
                    .map(tagKey -> tagKey.comp_327().toString())
                    .forEach(tags::add);
            return tags;
        });
    }

    /**
     * Returns the concatenated tooltip text for the given stack.
     * Lines are joined with newline. Returns empty string if tooltip cannot be generated.
     */
    public String getTooltipText(class_1799 stack) {
        return tooltipCache.computeIfAbsent(stack.method_7972(), key -> {
            ensureTooltipContext();
            if (tooltipContext == null) return "";

            var player = class_310.method_1551().field_1724;
            if (player == null) return "";

            try {
                List<class_2561> lines = key.method_7950(tooltipContext, player, class_1836.field_41070);
                return lines.stream()
                        .map(class_2561::getString)
                        .collect(Collectors.joining("\n"));
            } catch (Exception e) {
                return "";
            }
        });
    }

    /**
     * Clears all cached data. Called between search passes.
     */
    public void clear() {
        modNameCache.clear();
        tagsCache.clear();
        tooltipCache.clear();
        // namespaceCache is item-based and safe to keep; tooltipContext is session-based
    }
}
