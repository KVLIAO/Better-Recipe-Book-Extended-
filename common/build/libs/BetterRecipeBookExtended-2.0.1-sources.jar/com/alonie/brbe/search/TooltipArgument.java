package com.alonie.brbe.search;

import java.util.Locale;
import net.minecraft.class_1799;

/**
 * Searches by tooltip text. Prefix: #
 * <p>
 * Matches if the concatenated tooltip lines of the item contain the query text.
 */
public class TooltipArgument implements SearchArgument {
    private final String tooltipQuery;

    public TooltipArgument(String tooltipQuery) {
        this.tooltipQuery = tooltipQuery.toLowerCase(Locale.ROOT);
    }

    @Override
    public boolean matches(class_1799 stack, SearchCache cache) {
        String tooltip = cache.getTooltipText(stack);
        return tooltip != null && tooltip.toLowerCase(Locale.ROOT).contains(tooltipQuery);
    }

    @Override
    public boolean isAdvanced() {
        return true;
    }
}
