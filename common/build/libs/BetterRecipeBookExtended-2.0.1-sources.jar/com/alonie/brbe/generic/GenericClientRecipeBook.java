package com.alonie.brbe.generic;

import net.minecraft.class_3439;
import net.minecraft.class_5421;

public class GenericClientRecipeBook extends class_3439 {
    private boolean filteringCraftable;

    public boolean isFilteringCraftable() {
        return filteringCraftable;
    }

    public boolean method_30176(class_5421 category) {
        return filteringCraftable;
    }

    public void setFilteringCraftable(boolean filteringCraftable) {
        this.filteringCraftable = filteringCraftable;
    }
}
