package com.alonie.brbe.generic;

import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.util.ClientCompat;
import com.alonie.brbe.util.BRBTextures;
import com.alonie.brbe.widget.StateSwitchingButton;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_918;

public class BRBGroupButtonWidget extends StateSwitchingButton {
    protected BRBBookCategories.Category category;
    private int iconYOffset;

    public BRBGroupButtonWidget(BRBBookCategories.Category category) {
        super(0, 0, 35, 27, false);
        this.category = category;
        this.initTextureValues(BRBTextures.RECIPE_BOOK_TAB_SPRITES);
    }

    public void method_48579(class_332 gui, int mouseX, int mouseY, float delta) {
        class_310 minecraftClient = class_310.method_1551();

        class_2960 sprite = this.sprites.method_52729(true, this.isStateTriggered);
        int x = method_46426();
        if (this.isStateTriggered) {
            x -= 2;
        }

        ClientCompat.blitSprite(gui, sprite, x, this.method_46427(), this.field_22758, this.field_22759);

        this.renderIcons(gui, minecraftClient.method_1480());
    }

    private void renderIcons(class_332 guiGraphics, class_918 itemRenderer) {
        List<class_1799> list = this.category.getItemIcons();
        int i = this.isStateTriggered ? -2 : 0;
        int iconY = method_46427() + 5 + this.iconYOffset;
        if (list.size() == 1) {
            guiGraphics.method_51445(list.get(0), method_46426() + 9 + i, iconY);
        } else if (list.size() == 2) {
            guiGraphics.method_51445(list.get(0), method_46426() + 3 + i, iconY);
            guiGraphics.method_51445(list.get(1), method_46426() + 14 + i, iconY);
        }

    }

    public void setIconYOffset(int iconYOffset) {
        this.iconYOffset = iconYOffset;
    }

    public BRBBookCategories.Category getCategory() {
        return this.category;
    }
}
