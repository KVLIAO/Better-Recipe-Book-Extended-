package com.alonie.brbe.generic;

import com.google.common.collect.Lists;
import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.util.ClientCompat;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_5455;

public class GenericGhostRecipe<R extends GenericRecipe> {
    @Nullable
    protected Consumer<class_1799> onGhostUpdate;
    @Nullable
    protected R recipe;
    protected final List<GenericGhostIngredient> ingredients = Lists.newArrayList();
    protected float time;
    protected class_5455 registryAccess;
    @Nullable
    private BiPredicate<GhostRenderType, GenericGhostIngredient> renderingPredicate;

    public GenericGhostRecipe(@Nullable Consumer<class_1799> onGhostUpdate, class_5455 registryAccess) {
        this.onGhostUpdate = onGhostUpdate;
        this.registryAccess = registryAccess;
    }

    /**
     * @param renderingPredicate Returns true if {@link GhostRenderType} should be rendered
     */
    public void setRenderingPredicate(@Nullable BiPredicate<GhostRenderType, GenericGhostIngredient> renderingPredicate) {
        this.renderingPredicate = renderingPredicate;
    }

    public <T extends class_1703> void setDefaultRenderingPredicate(T menu) {
        this.setRenderingPredicate((type, ingredient) -> {
            class_1799 slot = menu.field_7761.get(ingredient.getContainerSlot()).method_7677();
            switch (type) {
                case ITEM, BACKGROUND, TOOLTIP -> {
                    return slot.method_7960();
                }
            }
            return true;
        });
    }

    public class_1799 getCurrentResult(BRBBookCategories.Category category) {
        if (this.recipe == null) {
            return class_1799.field_8037;
        }

        class_1799 itemStack = this.recipe.getResult(registryAccess, category);

        return itemStack.method_7972();
    }

    public void clear() {
        this.recipe = null;
        this.ingredients.clear();
        this.time = 0.0F;
    }

    public void addIngredient(int containerSlot, class_1856 ingredient, int i, int j) {
        this.ingredients.add(new GenericGhostIngredient(containerSlot, ingredient, i, j));
    }

    public void addIngredient(int containerSlot, class_1799 itemStack, int i, int j) {
        this.ingredients.add(new GenericGhostIngredient(containerSlot, itemStack, i, j));
    }

    public GenericGhostIngredient get(int i) {
        return this.ingredients.get(i);
    }

    public int size() {
        return this.ingredients.size();
    }

    @Nullable
    public R getRecipe() {
        return this.recipe;
    }

    public void setRecipe(@Nullable R recipe) {
        this.recipe = recipe;
    }

    public void render(class_332 guiGraphics, class_310 minecraft, int i, int j, boolean bl, float f, BRBBookCategories.Category category) {
        if (!ClientCompat.isControlDown()) {
            this.time += f;
            if (this.onGhostUpdate != null && this.recipe != null) this.onGhostUpdate.accept(this.getCurrentResult(category));
        }

        for (int k = 0; k < this.ingredients.size(); ++k) {
            GenericGhostIngredient ghostIngredient = this.ingredients.get(k);
            boolean shouldRenderBackground = renderingPredicate != null && renderingPredicate.test(GhostRenderType.BACKGROUND, ghostIngredient);
            boolean shouldRenderItem = renderingPredicate != null && renderingPredicate.test(GhostRenderType.ITEM, ghostIngredient);

            int l = ghostIngredient.getX() + i;
            int m = ghostIngredient.getY() + j;
            if (shouldRenderBackground) {
                if (k == 0 && bl) {
                    guiGraphics.method_25294(l - 4, m - 4, l + 20, m + 20, 822018048);
                } else {
                    guiGraphics.method_25294(l, m, l + 16, m + 16, 822018048);
                }
            }

            class_1799 itemStack = ghostIngredient.getItem();
            if (shouldRenderItem) {
                guiGraphics.method_51445(itemStack, l, m);
            }

            if (shouldRenderBackground) {
                guiGraphics.method_25294(l, m, l + 16, m + 16, 822083583);
            }

            if (k == 0) {
                guiGraphics.method_51431(minecraft.field_1772, itemStack, l, m);
            }
        }
    }

    public GenericGhostIngredient getBySlot(int i) {
        for (GenericGhostIngredient ingredient : ingredients) {
            if (ingredient.getContainerSlot() == i) return ingredient;
        }
        return null;
    }

    public void drawTooltip(class_332 gui, int x, int y, int mouseX, int mouseY) {
        class_1799 itemStack = null;

        for (GenericGhostIngredient ingredient : ingredients) {
            int j = ingredient.getX() + x;
            int k = ingredient.getY() + y;

            // don't render tooltip if cursor is not over item or predicate returns false
            if (mouseX >= j && mouseY >= k && mouseX < j + 16 && mouseY < k + 16 && (renderingPredicate == null || renderingPredicate.test(GhostRenderType.TOOLTIP, ingredient))) {
                itemStack = ingredient.getItem();
            }
        }

        if (itemStack != null && class_310.method_1551().field_1755 != null) {
            ClientCompat.setComponentTooltipForNextFrame(gui, class_437.method_25408(class_310.method_1551(), itemStack), mouseX, mouseY);
        }
    }

    public class GenericGhostIngredient {
        @Nullable
        private final class_1856 ingredient;
        @Nullable
        private final class_1799[] itemStacks;
        private final int x;
        private final int y;
        private final int containerSlot;

        public GenericGhostIngredient(int containerSlot, class_1856 ingredient, int i, int j) {
            this.containerSlot = containerSlot;
            this.ingredient = ingredient;
            this.itemStacks = null;
            this.x = i;
            this.y = j;
        }

        public GenericGhostIngredient(int containerSlot, class_1799 itemStack, int i, int j) {
            this.containerSlot = containerSlot;
            this.ingredient = null;
            this.itemStacks = new class_1799[]{itemStack};
            this.x = i;
            this.y = j;
        }

        public int getX() {
            return this.x;
        }

        public int getY() {
            return this.y;
        }

        public class_1799 getItem() {
            class_1799[] displayStacks = this.itemStacks != null ? this.itemStacks : ClientCompat.ingredientItems(this.ingredient);
            return displayStacks.length == 0 ? class_1799.field_8037 : displayStacks[class_3532.method_15375(GenericGhostRecipe.this.time / 30.0F) % displayStacks.length];
        }

        public int getContainerSlot() {
            return this.containerSlot;
        }

        public GenericGhostRecipe<R> getOwner() {
            return GenericGhostRecipe.this;
        }
    }

    public enum GhostRenderType {
        /**
         * When rendering the fake item model
         */
        ITEM,
        /**
         * When rendering the background color
         */
        BACKGROUND,
        /**
         * When rendering the fake item tooltip
         */
        TOOLTIP
    }
}
