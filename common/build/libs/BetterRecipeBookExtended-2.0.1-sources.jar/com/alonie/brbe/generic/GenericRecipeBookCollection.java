package com.alonie.brbe.generic;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.alonie.brbe.generic.pins.Pinnable;
import java.util.List;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_5455;

public abstract class GenericRecipeBookCollection<R extends GenericRecipe, M extends class_1703> implements Pinnable {
    protected final class_5455 registryAccess;
    protected List<R> recipes;
    protected M menu;

    protected GenericRecipeBookCollection(List<? extends R> list, M menu, class_5455 registryAccess) {
        this.menu = menu;
        this.recipes = ImmutableList.copyOf(list);
        this.registryAccess = registryAccess;
    }

    public List<R> getRecipes() {
        return recipes;
    }

    protected abstract List<R> getDisplayRecipes(boolean craftable);

    public boolean has(class_2960 Identifier) {
        for (R recipe : getRecipes()) {
            if (recipe.id().equals(Identifier)) {
                return true;
            }
        }

        return false;
    }

    public R getFirst() {
        return this.getRecipes().get(0);
    }

    protected abstract boolean atleastOneCraftable(class_2371<class_1735> slots);

    public abstract boolean isCraftable(R recipe, class_2371<class_1735> slots);

    protected boolean atleastOnePartiallyCraftable(class_2371<class_1735> slots) {
        return false;
    }

    public List<R> getPartiallyCraftableRecipes(class_2371<class_1735> slots) {
        return Lists.newArrayList();
    }

    public List<R> getPartiallyCraftableRecipes() {
        return this.getPartiallyCraftableRecipes(this.menu.field_7761);
    }
}
