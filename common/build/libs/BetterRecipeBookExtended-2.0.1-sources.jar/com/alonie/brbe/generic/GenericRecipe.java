package com.alonie.brbe.generic;

import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.generic.pins.Pinnable;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_5455;

public interface GenericRecipe extends Pinnable {
    class_2960 id();

    @Override
    default boolean has(class_2960 identifier) {
        return (id().equals(identifier));
    }

    class_1799 getResult(class_5455 registryAccess, BRBBookCategories.Category category);

    String getSearchString(BRBBookCategories.Category category);
}
