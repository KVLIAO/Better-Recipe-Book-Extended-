package com.alonie.brbe.generic.pins;

import com.alonie.brbe.BetterRecipeBook;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_10297;
import net.minecraft.class_2960;
import net.minecraft.class_516;

public final class PinnableRecipeCollection implements Pinnable {
    private final List<class_2960> identifiers;

    private PinnableRecipeCollection(List<class_2960> identifiers) {
        this.identifiers = identifiers;
    }

    public static PinnableRecipeCollection of(class_516 collection) {
        return new PinnableRecipeCollection(collection.method_2650().stream()
                .map(PinnableRecipeCollection::idFor)
                .toList());
    }

    public Collection<class_2960> identifiers() {
        return this.identifiers;
    }

    @Override
    public boolean has(class_2960 identifier) {
        return this.identifiers.contains(identifier);
    }

    private static class_2960 idFor(class_10297 entry) {
        String stableKey = entry.comp_3265() + "|" + entry.comp_3264().orElse(-1) + "|" + entry.comp_3263();
        return class_2960.method_60655(BetterRecipeBook.MOD_ID, "pin/" + sha1Hex(stableKey));
    }

    private static String sha1Hex(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            byte[] hash = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder(hash.length * 2);
            for (byte element : hash) {
                builder.append(Character.forDigit((element >> 4) & 15, 16));
                builder.append(Character.forDigit(element & 15, 16));
            }
            return builder.toString();
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("Missing SHA-1 support", exception);
        }
    }
}
