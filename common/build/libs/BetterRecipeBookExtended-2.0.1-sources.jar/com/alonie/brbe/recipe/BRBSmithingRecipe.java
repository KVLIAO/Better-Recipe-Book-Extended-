package com.alonie.brbe.recipe;

import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.generic.GenericRecipe;
import com.alonie.brbe.util.ClientCompat;
import java.util.List;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1856;
import net.minecraft.class_2371;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_8054;
import net.minecraft.class_9334;

public interface BRBSmithingRecipe extends GenericRecipe {
    class_1799 getResult(class_5455 registryAccess, BRBBookCategories.Category category);

    class_1799 getResult(class_5321<class_8054> trimMaterialResourceKey, class_5455 registryAccess, BRBBookCategories.Category category);

    class_1856 getTemplate();

    class_1799 getBase();

    class_1856 getAddition();

    default boolean requiresTemplate() {
        return true;
    }

    default boolean requiresAddition() {
        return true;
    }

    default boolean hasMaterials(class_2371<class_1735> slots, class_5455 registryAccess) {
        return hasTemplate(slots) && hasBase(slots, registryAccess) && hasAddition(slots);
    }

    default boolean hasPartialMaterials(class_2371<class_1735> slots, class_5455 registryAccess) {
        return (this.requiresTemplate() && hasTemplate(slots))
                || hasBase(slots, registryAccess)
                || (this.requiresAddition() && hasAddition(slots));
    }

    default boolean hasTemplate(List<class_1735> slots) {
        if (!this.requiresTemplate()) {
            return true;
        }

        for (class_1735 slot : slots) {
            if (this.getTemplate().method_8093(slot.method_7677())) return true;
        }
        return false;
    }

    default boolean hasBase(List<class_1735> slots, class_5455 registryAccess) {
        for (class_1735 slot : slots) {
            if (!slot.method_7677().method_57826(class_9334.field_49607) && getBase().method_7909().equals(slot.method_7677().method_7909()))
                return true;
        }
        return false;
    }

    default boolean hasAddition(List<class_1735> slots) {
        if (!this.requiresAddition()) {
            return true;
        }

        for (class_1735 slot : slots) {
            if (getAddition().method_8093(slot.method_7677())) return true;
        }
        return false;
    }

    default String getTemplateType() {
        class_310 minecraft = class_310.method_1551();
        class_1799 templateStack = ClientCompat.firstIngredientItem(getTemplate());
        if (templateStack.method_7960()) {
            return this.getBase().method_7964().getString();
        }

        if (minecraft.field_1724 == null || minecraft.field_1687 == null || templateStack.method_7960()) {
            return templateStack.method_7964().getString();
        }

        var tipCtx = class_1792.class_9635.method_59528(minecraft.field_1687);
        List<net.minecraft.class_2561> lines = templateStack.method_7950(tipCtx, minecraft.field_1724, class_1836.field_41070);
        if (lines.size() > 1) {
            return lines.get(1).getString();
        }

        return templateStack.method_7964().getString();
    }

    @Override
    default String getSearchString(BRBBookCategories.Category category) {
        return this.getTemplateType();
    }
}
