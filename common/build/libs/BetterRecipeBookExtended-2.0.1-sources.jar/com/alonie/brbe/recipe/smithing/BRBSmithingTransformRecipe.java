package com.alonie.brbe.recipe.smithing;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.recipe.BRBSmithingRecipe;
import java.util.List;
import net.minecraft.class_10297;
import net.minecraft.class_10314;
import net.minecraft.class_10352;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_7923;
import net.minecraft.class_8054;

public class BRBSmithingTransformRecipe implements BRBSmithingRecipe {
    private final class_2960 id;
    private final class_1856 template;
    private final class_1799 base;
    private final class_1856 addition;
    private final class_1799 result;
    private final boolean requiresTemplate;
    private final boolean requiresAddition;

    private BRBSmithingTransformRecipe(class_2960 id, class_1856 template, class_1799 base, class_1856 addition, class_1799 result, boolean requiresTemplate, boolean requiresAddition) {
        this.id = id;
        this.template = template;
        this.base = base;
        this.addition = addition;
        this.result = result;
        this.requiresTemplate = requiresTemplate;
        this.requiresAddition = requiresAddition;
    }

    public static BRBSmithingTransformRecipe from(class_10297 entry, class_10314 display, class_10352 displayContext) {
        List<class_1799> templateStacks = display.comp_3302().method_64738(displayContext);
        List<class_1799> additionStacks = display.comp_3304().method_64738(displayContext);
        class_1856 template = ingredientFrom(templateStacks);
        class_1799 base = firstResolved(display.comp_3303().method_64738(displayContext));
        class_1856 addition = ingredientFrom(additionStacks);
        class_1799 result = firstResolved(entry.method_64730(displayContext));
        class_2960 id = buildId("transform", template, base, addition, result);
        return new BRBSmithingTransformRecipe(id, template, base, addition, result, !templateStacks.isEmpty(), !additionStacks.isEmpty());
    }

    @Override
    public class_2960 id() {
        return this.id;
    }

    @Override
    public class_1799 getResult(class_5455 registryAccess, BRBBookCategories.Category category) {
        return this.result.method_7972();
    }

    @Override
    public class_1799 getResult(class_5321<class_8054> trimMaterialResourceKey, class_5455 registryAccess, BRBBookCategories.Category category) {
        return this.getResult(registryAccess, category);
    }

    @Override
    public class_1856 getTemplate() {
        return this.template;
    }

    @Override
    public class_1799 getBase() {
        return this.base.method_7972();
    }

    @Override
    public class_1856 getAddition() {
        return this.addition;
    }

    @Override
    public boolean requiresTemplate() {
        return this.requiresTemplate;
    }

    @Override
    public boolean requiresAddition() {
        return this.requiresAddition;
    }

    private static class_1856 ingredientFrom(List<class_1799> stacks) {
        if (stacks.isEmpty()) {
            return class_1856.method_8101(class_1802.field_8077);
        }

        return class_1856.method_26964(stacks.stream().map(class_1799::method_7909));
    }

    private static class_1799 firstResolved(List<class_1799> stacks) {
        return stacks.isEmpty() ? class_1799.field_8037 : stacks.get(0);
    }

    private static class_2960 buildId(String kind, class_1856 template, class_1799 base, class_1856 addition, class_1799 result) {
        return class_2960.method_60655(BetterRecipeBook.MOD_ID,
                "smithing/" + kind + "/"
                        + keyPart(firstItem(template)) + "/"
                        + keyPart(base) + "/"
                        + keyPart(firstItem(addition)) + "/"
                        + keyPart(result));
    }

    private static class_1799 firstItem(class_1856 ingredient) {
        return ingredient.method_8105()
                .findFirst()
                .map(holder -> holder.comp_349().method_7854())
                .orElse(class_1799.field_8037);
    }

    private static String keyPart(class_1799 stack) {
        class_1935 item = stack.method_7960() ? net.minecraft.class_1802.field_8162 : stack.method_7909();
        class_2960 key = class_7923.field_41178.method_10221(item.method_8389());
        return key.method_12836() + "_" + key.method_12832();
    }
}
