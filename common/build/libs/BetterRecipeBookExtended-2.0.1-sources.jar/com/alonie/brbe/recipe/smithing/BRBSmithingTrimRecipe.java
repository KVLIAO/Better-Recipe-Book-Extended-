package com.alonie.brbe.recipe.smithing;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.recipe.BRBSmithingRecipe;
import com.alonie.brbe.util.ClientCompat;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10302;
import net.minecraft.class_10314;
import net.minecraft.class_10352;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_8054;
import net.minecraft.class_8055;
import net.minecraft.class_8056;
import net.minecraft.class_8062;

public class BRBSmithingTrimRecipe implements BRBSmithingRecipe {
    private final class_2960 id;
    private final class_1856 template;
    private final class_1856 addition;
    private final class_1799 itemStackBase;
    private final class_6880<class_8056> pattern;

    private BRBSmithingTrimRecipe(class_2960 id, class_1856 template, class_1856 addition, class_1799 itemStackBase, class_6880<class_8056> pattern) {
        this.id = id;
        this.template = template;
        this.addition = addition;
        this.itemStackBase = itemStackBase;
        this.pattern = pattern;
    }

    public static ArrayList<BRBSmithingTrimRecipe> from(class_10314 display, class_10352 displayContext) {
        ArrayList<BRBSmithingTrimRecipe> results = new ArrayList<>();
        if (!(display.comp_3258() instanceof class_10302.class_10310 trimDisplay)) {
            return results;
        }

        class_1856 template = ingredientFrom(display.comp_3302().method_64738(displayContext));
        class_1856 addition = ingredientFrom(display.comp_3304().method_64738(displayContext));

        for (class_1799 base : display.comp_3303().method_64738(displayContext)) {
            if (base.method_7960()) {
                continue;
            }

            class_2960 id = buildId(template, base, addition);
            results.add(new BRBSmithingTrimRecipe(id, template, addition, base, trimDisplay.comp_3299()));
        }

        return results;
    }

    @Override
    public class_2960 id() {
        return this.id;
    }

    @Override
    public class_1799 getResult(class_5455 registryAccess, BRBBookCategories.Category category) {
        return this.getResult(class_8055.field_42007, registryAccess, category);
    }

    @Override
    public class_1799 getResult(class_5321<class_8054> trimMaterialResourceKey, class_5455 registryAccess, BRBBookCategories.Category category) {
        return class_8062.method_64996(registryAccess, this.itemStackBase.method_7972(), this.materialStack(trimMaterialResourceKey), this.pattern);
    }

    private class_1799 materialStack(class_5321<class_8054> material) {
        if (material == class_8055.field_42004) return new class_1799(class_1802.field_8155);
        if (material == class_8055.field_42005) return new class_1799(class_1802.field_8620);
        if (material == class_8055.field_42006) return new class_1799(class_1802.field_22020);
        if (material == class_8055.field_42007) return new class_1799(class_1802.field_8725);
        if (material == class_8055.field_42008) return new class_1799(class_1802.field_27022);
        if (material == class_8055.field_42009) return new class_1799(class_1802.field_8695);
        if (material == class_8055.field_42010) return new class_1799(class_1802.field_8687);
        if (material == class_8055.field_42011) return new class_1799(class_1802.field_8477);
        if (material == class_8055.field_42012) return new class_1799(class_1802.field_8759);
        if (material == class_8055.field_42013) return new class_1799(class_1802.field_27063);
        if (material == class_8055.field_55049) return new class_1799(class_1802.field_55044);
        return ClientCompat.firstIngredientItem(this.getAddition());
    }

    @Override
    public class_1799 getBase() {
        return this.itemStackBase.method_7972();
    }

    @Override
    public class_1856 getTemplate() {
        return this.template;
    }

    @Override
    public class_1856 getAddition() {
        return this.addition;
    }

    private static class_1856 ingredientFrom(List<class_1799> stacks) {
        return class_1856.method_26964(stacks.stream().map(class_1799::method_7909));
    }

    private static class_2960 buildId(class_1856 template, class_1799 base, class_1856 addition) {
        return class_2960.method_60655(BetterRecipeBook.MOD_ID,
                "smithing/trim/"
                        + keyPart(firstItem(template)) + "/"
                        + keyPart(base) + "/"
                        + keyPart(firstItem(addition)));
    }

    private static class_1799 firstItem(class_1856 ingredient) {
        return ingredient.method_8105()
                .findFirst()
                .map(holder -> holder.comp_349().method_7854())
                .orElse(class_1799.field_8037);
    }

    private static String keyPart(class_1799 stack) {
        class_1935 item = stack.method_7960() ? class_1802.field_8162 : stack.method_7909();
        class_2960 key = class_7923.field_41178.method_10221(item.method_8389());
        return key.method_12836() + "_" + key.method_12832();
    }
}
