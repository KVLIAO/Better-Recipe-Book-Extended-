package com.alonie.brbe.mixins.unlockrecipes;

import com.alonie.brbe.util.RecipeUnlockUtil;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftMixin {
    @Inject(method = "clearClientLevel", at = @At("HEAD"))
    private void onClearClientLevel(class_437 screen, CallbackInfo ci) {
        RecipeUnlockUtil.restoreRecipes();
    }
}
