package com.alonie.brbe.mixins.accessors.smithing;

import net.minecraft.class_1856;
import net.minecraft.class_6880;
import net.minecraft.class_8056;
import net.minecraft.class_8062;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_8062.class)
public interface SmithingTrimRecipeAccessor {
    @Accessor("template")
    class_1856 getUnderlyingTemplate();

    @Accessor("base")
    class_1856 getUnderlyingBase();

    @Accessor("addition")
    class_1856 getUnderlyingAddition();

    @Accessor("pattern")
    class_6880<class_8056> getPattern();
}
