package com.alonie.brbe.mixins;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.interfaces.TopLayerOverlayProvider;
import com.alonie.brbe.smithingtable.SmithingRecipeBookComponent;
import com.alonie.brbe.smithingtable.SmithingRecipeBookPage;
import com.alonie.brbe.util.ClientCompat;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_4862;
import net.minecraft.class_4894;
import net.minecraft.class_4895;
import net.minecraft.class_8030;
import net.minecraft.class_8064;
import com.alonie.brbe.util.BRBTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4895.class)
public abstract class SmithingScreenMixin extends class_4894<class_4862> implements TopLayerOverlayProvider {
    @Shadow
    protected abstract void updateArmorStandPreview(class_1799 itemStack);

    @Unique
    public final SmithingRecipeBookComponent _$recipeBookComponent = new SmithingRecipeBookComponent();
    @Unique
    private boolean _$widthNarrow;

    public SmithingScreenMixin(class_4862 itemCombinerMenu, class_1661 inventory, class_2561 component, class_2960 Identifier) {
        super(itemCombinerMenu, inventory, component, Identifier);
    }

    @Inject(method = "subInit", at = @At("RETURN"))
    void init(CallbackInfo ci) {
        if (BetterRecipeBook.config.enableBook) {
            this._$widthNarrow = this.field_22789 < 379;
            this._$recipeBookComponent.init(this.field_22789, this.field_22790, this.field_22787, _$widthNarrow, this.field_2797, this::updateArmorStandPreview, class_310.method_1551().method_1562().method_29091());

            if (!BetterRecipeBook.config.keepCentered) {
                this.field_2776 = this._$recipeBookComponent.findLeftEdge(this.field_22789, this.field_2792);
            }

            // NOTE : width and height are both 0
            this.method_37063(new class_344(this.field_2776 + 147, this.field_22790 / 2 - 75, 20, 18, BRBTextures.RECIPE_BOOK_BUTTON_SPRITES, (button) -> {
                this._$recipeBookComponent.toggleVisibility();
                if (!BetterRecipeBook.config.keepCentered) {
                    this.field_2776 = this._$recipeBookComponent.findLeftEdge(this.field_22789, this.field_2792);
                }
                button.method_48229(this.field_2776 + 147, this.field_22790 / 2 - 75);
            }));

            this.method_25429(this._$recipeBookComponent);
        }
    }

    @Override
    public boolean method_25404(class_11908 event) {
        if (_$recipeBookComponent.method_25404(event)) {
            return true;
        }
        return super.method_25404(event);
    }

    @Override
    public boolean method_16803(class_11908 event) {
        if (_$recipeBookComponent.method_16803(event)) {
            return true;
        }
        return super.method_16803(event);
    }

    @Override
    public boolean method_25400(class_11905 event) {
        if (_$recipeBookComponent.method_25400(event)) {
            return true;
        }
        return super.method_25400(event);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if (this.betterRecipeBook$clickTopLayerOverlay(event, doubleClick)) {
            return true;
        }

        return super.method_25402(event, doubleClick);
    }

    @Override
    public boolean betterRecipeBook$hasTopLayerOverlay() {
        return this._$recipeBookComponent.isVisible()
                && this._$recipeBookComponent.recipesPage instanceof SmithingRecipeBookPage page
                && page.overlayIsVisible();
    }

    @Override
    public void betterRecipeBook$renderTopLayerOverlay(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (this.betterRecipeBook$hasTopLayerOverlay()) {
            ((SmithingRecipeBookPage) this._$recipeBookComponent.recipesPage).overlay.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        }
    }

    @Override
    public boolean betterRecipeBook$clickTopLayerOverlay(class_11909 event, boolean doubleClick) {
        if (this.betterRecipeBook$hasTopLayerOverlay()
                && this._$recipeBookComponent.method_25402(event, doubleClick)) {
            return true;
        }

        return false;
    }

    @Override
    public class_8030 betterRecipeBook$getTopLayerOverlayBounds() {
        if (this.betterRecipeBook$hasTopLayerOverlay()) {
            return ((SmithingRecipeBookPage) this._$recipeBookComponent.recipesPage).overlay.getBounds();
        }

        return null;
    }

    @Override
    protected void method_2383(class_1735 slot, int x, int y, class_1713 clickType) {
        // clear ghost recipe if an empty ingredient slot is clicked with no items
        if (BetterRecipeBook.config.enableBook && slot != null && slot.field_7874 < 4 && field_2797.method_34255().method_7960() && field_2797.field_7761.get(slot.field_7874).method_7677().method_7960()) {
            _$recipeBookComponent.ghostRecipe.clear();
        }

        super.method_2383(slot, x, y, clickType);
    }

    @Override
    protected boolean method_2381(double d, double e, int i, int j) {
        boolean bl = d < (double) i || e < (double) j || d >= (double) (i + this.field_2792) || e >= (double) (j + this.field_2779);
        return this._$recipeBookComponent.hasClickedOutside(d, e, this.field_2776, this.field_2800, this.field_2792, this.field_2779, 0) && bl;
    }

    @Inject(method = "render", at = @At("RETURN"))
    public void render(class_332 guiGraphics, int i, int j, float f, CallbackInfo ci) {
        if (this._$recipeBookComponent.isVisible()) {
            this._$recipeBookComponent.method_25394(guiGraphics, i, j, f);
            this._$recipeBookComponent.renderGhostRecipe(guiGraphics, this.field_2776, this.field_2800, false, f);
            this._$recipeBookComponent.drawTooltip(guiGraphics, this.field_2776, this.field_2800, i, j);
        }
    }

    @Redirect(method = "renderBg", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/inventory/CyclingSlotBackground;render(Lnet/minecraft/world/inventory/AbstractContainerMenu;Lnet/minecraft/client/gui/GuiGraphics;FII)V"))
    public void renderBg(class_8064 instance, class_1703 slot, class_332 bl, float g, int k, int arg) {
        if (!BetterRecipeBook.config.enableBook || !_$recipeBookComponent.isShowingGhostRecipe()) {
            instance.method_48469(this.field_2797, bl, g, this.field_2776, this.field_2800);
        }

        // pass, cancel render of onboarding tip slots if there is a ghost recipe
    }

    @Inject(method = "renderOnboardingTooltips", at = @At(value = "HEAD"), cancellable = true)
    public void renderOnboardingTooltips(class_332 guiGraphics, int i, int j, CallbackInfo ci) {
        if (BetterRecipeBook.config.enableBook && _$recipeBookComponent.isShowingGhostRecipe()) {
            ci.cancel();
        }
    }

    @Inject(method = "slotChanged", at = @At(value = "HEAD"))
    public void slotChanged(class_1703 abstractContainerMenu, int i, class_1799 itemStack, CallbackInfo ci) {
        if (i == class_4862.field_41925 || i == class_4862.field_41926 || i == class_4862.field_41924 || i == class_4862.field_41927) {
            _$recipeBookComponent.ghostRecipe.clear();
        }
    }
}
