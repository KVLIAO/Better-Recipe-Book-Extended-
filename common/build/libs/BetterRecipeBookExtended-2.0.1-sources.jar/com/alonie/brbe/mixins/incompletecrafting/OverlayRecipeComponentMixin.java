package com.alonie.brbe.mixins.incompletecrafting;

import com.alonie.brbe.util.AlternativeOverlayLayout;
import com.alonie.brbe.util.PartialCraftingUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;
import net.minecraft.class_10297;
import net.minecraft.class_10352;
import net.minecraft.class_508;
import net.minecraft.class_516;

@Mixin(class_508.class)
public class OverlayRecipeComponentMixin {
    @Shadow
    @Final
    private List<?> recipeButtons;

    @Redirect(method = "init", at = @At(value = "INVOKE", target = "Ljava/util/Collections;emptyList()Ljava/util/List;"))
    private List<class_10297> betterRecipeBook$showPartiallyCraftableAlternatives(class_516 collection, class_10352 contextMap, boolean isFiltering, int x, int y, int overlayX, int overlayY, float width) {
        return PartialCraftingUtil.getPartiallyCraftableRecipes(collection);
    }

    @ModifyVariable(method = "init", index = 13, at = @At("STORE"))
    private int betterRecipeBook$expandColumnsAfterFiveRows(int columns, class_516 collection, class_10352 contextMap, boolean isFiltering, int x, int y, int overlayX, int overlayY, float width) {
        int recipeCount = collection.method_64885(class_516.class_9937.field_52848).size();
        if (!isFiltering) {
            recipeCount += collection.method_64885(class_516.class_9937.field_52849).size();
        } else {
            recipeCount += PartialCraftingUtil.getPartiallyCraftableRecipes(collection).size();
        }

        return AlternativeOverlayLayout.columnsFor(recipeCount);
    }

    @ModifyVariable(method = "render", index = 5, at = @At("STORE"))
    private int betterRecipeBook$renderExpandedColumnsAfterFiveRows(int columns) {
        return AlternativeOverlayLayout.columnsFor(this.recipeButtons.size());
    }
}
