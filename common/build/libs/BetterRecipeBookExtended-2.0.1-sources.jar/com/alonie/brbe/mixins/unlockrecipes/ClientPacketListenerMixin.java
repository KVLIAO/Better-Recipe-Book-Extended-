package com.alonie.brbe.mixins.unlockrecipes;

import com.alonie.brbe.util.RecipeUnlockUtil;
import net.minecraft.class_10266;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Keeps the singleplayer client and integrated server recipe book in sync with the unlock-all setting.
 */
@Mixin(class_634.class)
public abstract class ClientPacketListenerMixin {

    @Inject(method = "handleRecipeBookAdd", at = @At("RETURN"))
    private void onRecipeBookAdd(class_10266 packet, CallbackInfo ci) {
        RecipeUnlockUtil.syncToConfig();
    }
}
