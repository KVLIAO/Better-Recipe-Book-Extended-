package com.alonie.brbe.mixins.pins;

import com.google.common.collect.Lists;
import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.generic.pins.PinnableRecipeCollection;
import com.alonie.brbe.interfaces.IPinningComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import java.util.List;
import net.minecraft.class_507;
import net.minecraft.class_516;

@Mixin(class_507.class)
public abstract class RecipeBookComponentMixin implements IPinningComponent<PinnableRecipeCollection> {

    @Unique
    public void betterRecipeBook$sortByPinsInPlaceCollection(List<class_516> results) {
        List<class_516> tempResults = Lists.newArrayList(results);

        if (BetterRecipeBook.config.enablePinning) {
            for (class_516 result : tempResults) {
                if (BetterRecipeBook.pinnedRecipeManager.has(PinnableRecipeCollection.of(result))) {
                    results.remove(result);
                    results.add(0, result);
                }
            }
        }
    }

    @ModifyArg(method = "updateCollections", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeBookPage;updateCollections(Ljava/util/List;ZZ)V"))
    private List<class_516> updateCollections(List<class_516> list) {
        this.betterRecipeBook$sortByPinsInPlaceCollection(list);
        return list;
    }
}
