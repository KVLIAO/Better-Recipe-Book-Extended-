package com.alonie.brbe.mixins.pins;

import net.minecraft.class_11909;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_513;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_513.class)
public class RecipeBookPageMixin {

    @Shadow private class_310 minecraft;

    @Inject(method = "mouseClicked", at = @At("RETURN"))
    public void mouseClicked(class_11909 event, int x, int y, int width, int height, boolean isDoubleClick, CallbackInfoReturnable<Boolean> cir) {
        // If the recipe page consumed the click, clear any focused recipe-book search box.
        if (cir.getReturnValue() && minecraft.field_1755 != null && minecraft.field_1755.method_25399() instanceof class_342 searchBox) {
            searchBox.method_25365(false);
        }
    }

}
