package com.alonie.brbe.mixins.accessors;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_1860;
import net.minecraft.class_3441;
import net.minecraft.class_5321;

@Mixin(class_3441.class)
public interface ServerRecipeBookAccessor {
    @Accessor("known")
    Set<class_5321<class_1860<?>>> betterRecipeBook$getKnown();
}
