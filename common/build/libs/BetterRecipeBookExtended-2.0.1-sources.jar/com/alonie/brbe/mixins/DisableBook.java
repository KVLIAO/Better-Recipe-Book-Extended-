package com.alonie.brbe.mixins;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_507;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_507.class)
public class DisableBook {
    @Inject(at = @At("HEAD"), method = "isVisible", cancellable = true)
    public void isOpen(CallbackInfoReturnable<Boolean> cir) {
        if (!BetterRecipeBook.config.enableBook) {
            cir.setReturnValue(false);
        }
    }
}
