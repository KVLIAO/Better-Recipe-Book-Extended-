package com.alonie.brbe.mixins.incompatibleenvironment;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_10295;
import net.minecraft.class_10300;
import net.minecraft.class_10301;
import net.minecraft.class_310;
import net.minecraft.class_490;
import net.minecraft.class_9933;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_9933.class)
public abstract class CraftingRecipeBookComponentMixin {

    @Inject(method = "canDisplay", at = @At("RETURN"), cancellable = true)
    private void betterRecipeBook$showAllRecipes(class_10295 recipeDisplay, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue()
                && BetterRecipeBook.config.showAllRecipesInSurvival
                && class_310.method_1551().field_1755 instanceof class_490
                && (recipeDisplay instanceof class_10300
                    || recipeDisplay instanceof class_10301)) {
            cir.setReturnValue(true);
        }
    }
}
