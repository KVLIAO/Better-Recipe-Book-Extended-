package com.alonie.brbe.mixins.instantcraft;

import com.alonie.brbe.BetterRecipeBook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_10298;
import net.minecraft.class_513;
import net.minecraft.class_514;
import net.minecraft.class_516;

@Mixin(class_514.class)
public class RecipeButtonMixin {

    @Shadow private class_516 collection;

    @Unique private List<class_10298> betterRecipeBook$lastClicked;

    @Inject(method = "init", at = @At(value = "HEAD"))
    public void init(class_516 collection, class_513 recipeBookPage, CallbackInfo ci) {
        if (BetterRecipeBook.instantCraftingManager.lastHoveredCollection == collection) {
            BetterRecipeBook.instantCraftingManager.lastHoveredCollection = null;
            betterRecipeBook$lastClicked = List.of(BetterRecipeBook.instantCraftingManager.lastClickedRecipe);
        }
    }
}
