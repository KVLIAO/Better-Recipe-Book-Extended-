package com.alonie.brbe.mixins.ungroup;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.mixins.accessors.RecipeCollectionAccessor;
import com.alonie.brbe.util.PartialCraftingUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_10297;
import net.minecraft.class_507;
import net.minecraft.class_516;

@Mixin(class_507.class)
public class RecipeBookComponentMixin {
    @ModifyArg(method = "updateCollections", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeBookPage;updateCollections(Ljava/util/List;ZZ)V"), index = 0)
    private List<class_516> splitCollectionsAfterFiltering(List<class_516> collections) {
        if (!BetterRecipeBook.config.alternativeRecipes.noGrouped) {
            return collections;
        }

        List<class_516> splitCollections = new ArrayList<>(collections.size());
        for (class_516 collection : collections) {
            List<class_10297> recipes = collection.method_2650();
            if (recipes.size() <= 1) {
                splitCollections.add(collection);
                continue;
            }

            RecipeCollectionAccessor source = (RecipeCollectionAccessor) collection;
            boolean restrictToCraftableOrPartial = PartialCraftingUtil.hasPartialMaterials(collection)
                    || collection.method_2655();
            boolean addedAny = false;
            for (class_10297 recipe : recipes) {
                if (!source.betterRecipeBook$getSelected().contains(recipe.comp_3262())) {
                    continue;
                }

                boolean isCraftable = source.betterRecipeBook$getCraftable().contains(recipe.comp_3262());
                boolean isPartial = PartialCraftingUtil.isPartiallyCraftable(collection, recipe.comp_3262());
                if (restrictToCraftableOrPartial && !isCraftable && !isPartial) {
                    continue;
                }

                class_516 splitCollection = new class_516(Collections.singletonList(recipe));
                RecipeCollectionAccessor split = (RecipeCollectionAccessor) splitCollection;
                split.betterRecipeBook$getSelected().add(recipe.comp_3262());
                if (isCraftable) {
                    split.betterRecipeBook$getCraftable().add(recipe.comp_3262());
                }
                if (isPartial) {
                    PartialCraftingUtil.markPartialMaterial(splitCollection, recipe.comp_3262());
                }

                splitCollections.add(splitCollection);
                addedAny = true;
            }

            if (!addedAny && !restrictToCraftableOrPartial) {
                splitCollections.add(collection);
            }
        }

        return splitCollections;
    }
}
