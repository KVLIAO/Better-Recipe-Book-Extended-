package com.alonie.brbe.mixins.ungroup;

import com.google.common.collect.Lists;
import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.mixins.accessors.RecipeCollectionAccessor;
import com.alonie.brbe.util.IncompatibleCraftingUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import net.minecraft.class_10287;
import net.minecraft.class_10297;
import net.minecraft.class_10300;
import net.minecraft.class_10301;
import net.minecraft.class_299;
import net.minecraft.class_3439;
import net.minecraft.class_516;

@Mixin(class_299.class)
public class ClientRecipeBookMixin extends class_3439 {
    @Shadow private Map<class_10287, List<class_516>> collectionsByTab;

    @Inject(method = "getCollection", locals = LocalCapture.CAPTURE_FAILHARD, at = @At("RETURN"), cancellable = true)
    private void split(class_10287 category, CallbackInfoReturnable<List<class_516>> cir) {
        if (BetterRecipeBook.config.alternativeRecipes.noGrouped) {
            List<class_516> list = Lists.newArrayList(this.collectionsByTab.getOrDefault(category, Collections.emptyList()));
            List<class_516> list2 = Lists.newArrayList(list);

            for (class_516 recipeResultCollection : list) {
                if (recipeResultCollection.method_2650().size() > 1) {
                    List<class_10297> recipes = recipeResultCollection.method_2650();
                    list2.remove(recipeResultCollection);

                    for (class_10297 recipe : recipes) {
                        class_516 splitCollection = new class_516(Collections.singletonList(recipe));
                        RecipeCollectionAccessor sourceAccessor = (RecipeCollectionAccessor) recipeResultCollection;
                        RecipeCollectionAccessor splitAccessor = (RecipeCollectionAccessor) splitCollection;

                        if (sourceAccessor.betterRecipeBook$getSelected().contains(recipe.comp_3262())) {
                            splitAccessor.betterRecipeBook$getSelected().add(recipe.comp_3262());
                        }
                        if (sourceAccessor.betterRecipeBook$getCraftable().contains(recipe.comp_3262())) {
                            splitAccessor.betterRecipeBook$getCraftable().add(recipe.comp_3262());
                        }

                        // Mark incompatible directly (original collection hasn't been
                        // processed by IncompatibleCraftingUtil yet at this point).
                        if (recipe.comp_3263() instanceof class_10300 shaped
                                && (shaped.comp_3268() > 2 || shaped.comp_3269() > 2)) {
                            IncompatibleCraftingUtil.markIncompatibleOnCollection(splitCollection, recipe.comp_3262());
                        } else if (recipe.comp_3263() instanceof class_10301 shapeless
                                && shapeless.comp_3271().size() > 4) {
                            IncompatibleCraftingUtil.markIncompatibleOnCollection(splitCollection, recipe.comp_3262());
                        }

                        list2.add(splitCollection);
                    }
                }
            }
            cir.setReturnValue(list2);
        }
    }
}
