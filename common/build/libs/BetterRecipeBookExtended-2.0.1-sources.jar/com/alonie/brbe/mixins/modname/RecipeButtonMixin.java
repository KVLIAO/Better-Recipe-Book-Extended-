package com.alonie.brbe.mixins.modname;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.util.ModNameUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_514;

/**
 * Adds the source mod name to vanilla crafting recipe button tooltips.
 * Compatible with Jade's i18n format: {@code jade.modName.<MOD_ID>}
 */
@Mixin(class_514.class)
public abstract class RecipeButtonMixin {

    @Inject(method = "getTooltipText", at = @At("RETURN"))
    private void betterRecipeBook$appendModName(class_1799 itemStack, CallbackInfoReturnable<List<class_2561>> cir) {
        if (!BetterRecipeBook.config.showModName) {
            return;
        }

        List<class_2561> tooltip = cir.getReturnValue();
        if (tooltip == null || tooltip.isEmpty()) {
            return;
        }

        class_2561 modName = ModNameUtil.getFormattedModName(itemStack);
        if (modName == null || modName.getString().isEmpty()) {
            return;
        }

        tooltip.add(class_2561.method_43473());
        tooltip.add(modName);
    }
}
