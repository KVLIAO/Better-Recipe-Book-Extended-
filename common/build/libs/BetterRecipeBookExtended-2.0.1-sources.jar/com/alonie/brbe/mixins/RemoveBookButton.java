package com.alonie.brbe.mixins;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_507;
import net.minecraft.class_8666;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_344.class)
public abstract class RemoveBookButton {
    @Final
    @Shadow
    protected class_8666 sprites;

    @Inject(at = @At("HEAD"), method = "renderContents", cancellable = true)
    public void renderContents(class_332 gui, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (sprites == class_507.field_45550) {
            ((class_344) (Object) this).field_22764 = BetterRecipeBook.config.enableBook;
            if (!BetterRecipeBook.config.enableBook) {
                ci.cancel();
            }
        }
    }
}
