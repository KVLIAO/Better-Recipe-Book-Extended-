package com.alonie.brbe.mixins.search;

import com.alonie.brbe.search.SearchCache;
import com.alonie.brbe.search.SearchQuery;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10297;
import net.minecraft.class_10363;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_507;
import net.minecraft.class_516;

@Mixin(class_507.class)
public class RecipeBookComponentMixin {

    @Shadow
    @Final
    protected class_310 minecraft;

    @Shadow
    protected class_342 searchBox;

    @Unique
    private String betterRecipeBook$savedSearchText;

    @Unique
    private SearchQuery betterRecipeBook$parsedQuery;

    /**
     * Stage 1: At HEAD, detect advanced search syntax.
     * If found, save and clear the search box so vanilla's substring filter is a no-op.
     */
    @Inject(method = "updateCollections", at = @At("HEAD"))
    private void betterRecipeBook$onUpdateCollections(boolean resetPageNumber, boolean isFiltering, CallbackInfo ci) {
        betterRecipeBook$savedSearchText = null;
        betterRecipeBook$parsedQuery = null;

        if (searchBox == null) {
            return;
        }

        String text = searchBox.method_1882();
        if (text == null || text.isEmpty()) {
            return;
        }

        SearchQuery query = SearchQuery.parse(text);
        if (query.isAdvanced()) {
            // Save the search text and clear the box
            // Vanilla's removeIf will then see an empty search and pass everything
            betterRecipeBook$savedSearchText = text;
            betterRecipeBook$parsedQuery = query;
            searchBox.method_1852("");
        }
    }

    /**
     * Stage 2: At the point where the list is passed to RecipeBookPage,
     * apply the advanced search filter if we have a parsed query.
     */
    @ModifyArg(method = "updateCollections",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeBookPage;updateCollections(Ljava/util/List;ZZ)V"),
            index = 0)
    private List<class_516> betterRecipeBook$applyAdvancedSearch(List<class_516> collections) {
        if (betterRecipeBook$parsedQuery == null || minecraft.field_1687 == null) {
            return collections;
        }

        SearchCache cache = new SearchCache();
        var displayContext = class_10363.method_65008(minecraft.field_1687);

        List<class_516> filtered = new ArrayList<>();
        for (class_516 collection : collections) {
            boolean added = false;
            for (class_10297 entry : collection.method_2650()) {
                List<class_1799> results = entry.method_64730(displayContext);
                for (class_1799 result : results) {
                    if (result != null && !result.method_7960()
                            && betterRecipeBook$parsedQuery.matches(result, cache)) {
                        filtered.add(collection);
                        added = true;
                        break;
                    }
                }
                if (added) break;
            }
        }

        return filtered;
    }

    /**
     * Stage 3: At TAIL, restore the search box text if we cleared it.
     */
    @Inject(method = "updateCollections", at = @At("TAIL"))
    private void betterRecipeBook$restoreSearchText(boolean resetPageNumber, boolean isFiltering, CallbackInfo ci) {
        if (betterRecipeBook$savedSearchText != null && searchBox != null) {
            searchBox.method_1852(betterRecipeBook$savedSearchText);
            betterRecipeBook$savedSearchText = null;
            betterRecipeBook$parsedQuery = null;
        }
    }
}
