package com.alonie.brbe.mixins.instantcraft;

import com.alonie.brbe.BetterRecipeBook;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.List;
import net.minecraft.class_513;
import net.minecraft.class_514;
import net.minecraft.class_516;

@Mixin(class_513.class)
public class RecipeBookPageMixin {

    @Shadow @Final private List<class_514> buttons;

    @Shadow private List<class_516> recipeCollections;

    @Inject(method = "updateCollections", at = @At(value = "HEAD"), locals = LocalCapture.CAPTURE_FAILHARD)
    public void updateCollections(List<class_516> list, boolean bl, CallbackInfo ci) {
        // used to help keep the same recipe in a button you were instant-crafting with.
        // works in conjunction with RecipeButtonMixin#getOrderedRecipes.
        if (BetterRecipeBook.instantCraftingManager.isEnabled()) {
            buttons.stream()
                    .filter(class_514::method_49606)
                    .findAny()
                    .ifPresent(btn -> {
                        class_516 hoveredCollection = btn.method_2645();
                        int idx = recipeCollections.indexOf(hoveredCollection);
                        if (idx != -1 && idx < list.size() && BetterRecipeBook.instantCraftingManager.lastClickedRecipe != null) {
                            list.remove(hoveredCollection);
                            list.add(idx, hoveredCollection);
                            BetterRecipeBook.instantCraftingManager.lastHoveredCollection = btn.method_2645();
                        }
                    });
        }
    }

}
