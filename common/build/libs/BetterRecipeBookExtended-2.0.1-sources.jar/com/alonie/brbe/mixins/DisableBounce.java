package com.alonie.brbe.mixins;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_10298;
import net.minecraft.class_299;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_299.class)
public class DisableBounce {
    @Inject(method = "willHighlight", at = @At(value = "HEAD"), cancellable = true)
    public void willHighlight(class_10298 recipeDisplayId, CallbackInfoReturnable<Boolean> cir) {
        if (!BetterRecipeBook.config.newRecipes.enableBounce) {
            cir.setReturnValue(false);
            cir.cancel();
        }
    }
}
