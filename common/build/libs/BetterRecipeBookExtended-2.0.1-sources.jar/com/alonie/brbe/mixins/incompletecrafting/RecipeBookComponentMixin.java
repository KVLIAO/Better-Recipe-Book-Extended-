package com.alonie.brbe.mixins.incompletecrafting;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.mixins.accessors.RecipeCollectionAccessor;
import com.alonie.brbe.util.IncompatibleCraftingUtil;
import com.alonie.brbe.util.PartialCraftingUtil;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_10297;
import net.minecraft.class_10298;
import net.minecraft.class_1729;
import net.minecraft.class_310;
import net.minecraft.class_490;
import net.minecraft.class_507;
import net.minecraft.class_513;
import net.minecraft.class_516;

@Mixin(class_507.class)
public abstract class RecipeBookComponentMixin {
    @Shadow @Final
    protected class_1729 menu;

    @Shadow @Final
    protected class_310 minecraft;

    @Shadow
    private net.minecraft.class_342 searchBox;

    @Inject(method = "updateCollections", at = @At("HEAD"))
    private void betterRecipeBook$trackPartialFilteringUpdate(boolean resetPageNumber, boolean isFiltering, CallbackInfo ci) {
        boolean retainIncompatible = BetterRecipeBook.config.showAllRecipesInSurvival
                && !isFiltering
                && this.minecraft != null
                && this.minecraft.field_1755 instanceof class_490;
        IncompatibleCraftingUtil.beginFiltering(retainIncompatible);
    }

    @Redirect(method = "updateCollections", at = @At(value = "INVOKE", target = "Ljava/util/List;removeIf(Ljava/util/function/Predicate;)Z"))
    private boolean betterRecipeBook$keepPartiallyCraftable(List<class_516> collections, Predicate<? super class_516> predicate) {
        // Skip incompatible logic when showAllRecipesInSurvival is off.
        // (Partial material injection always runs — it is gated separately.)
        if (!BetterRecipeBook.config.showAllRecipesInSurvival) {
            return collections.removeIf(predicate);
        }

        boolean onInventoryScreen = this.minecraft != null
                && this.minecraft.field_1755 instanceof class_490;

        // Partial material marking — gated by partialMarkingEnabled
        if (BetterRecipeBook.config.partialMarkingEnabled) {
            // Step 0: Clear previously-injected partial IDs from craftable set
            for (class_516 collection : collections) {
                if (PartialCraftingUtil.hasPartialMaterials(collection)) {
                    RecipeCollectionAccessor accessor = (RecipeCollectionAccessor) collection;
                    for (class_10297 entry : collection.method_2650()) {
                        class_10298 id = entry.comp_3262();
                        if (PartialCraftingUtil.isPartiallyCraftable(collection, id)) {
                            accessor.betterRecipeBook$getCraftable().remove(id);
                        }
                    }
                }
            }

            for (class_516 collection : collections) {
                PartialCraftingUtil.markPartialMaterials(collection, this.menu.field_7761);

                // Inject partial recipes into craftable set
                if (PartialCraftingUtil.hasPartialMaterials(collection)) {
                    RecipeCollectionAccessor accessor = (RecipeCollectionAccessor) collection;
                    for (class_10297 entry : collection.method_2650()) {
                        class_10298 id = entry.comp_3262();
                        if (PartialCraftingUtil.isPartiallyCraftable(collection, id)) {
                            accessor.betterRecipeBook$getCraftable().add(id);
                        }
                    }
                }
            }
        }

        // Mark incompatible recipes — gated by showAllRecipesInSurvival (outer guard),
        // NOT by partialMarkingEnabled, so "当前无法合成" recipes don't become air
        // placeholders when partialMarkingEnabled is off.
        if (onInventoryScreen) {
            for (class_516 collection : collections) {
                IncompatibleCraftingUtil.markIncompatibleRecipes(collection);
            }
        }

        boolean hasSearchActive = searchBox != null && !searchBox.method_1882().isEmpty();
        boolean hasPartial = !hasSearchActive
                && BetterRecipeBook.config.partialMarkingEnabled;
        boolean retainIncompatible = onInventoryScreen
                && IncompatibleCraftingUtil.isActive()
                && !hasSearchActive;

        if (!hasPartial && !retainIncompatible) {
            return collections.removeIf(predicate);
        }

        boolean removed = collections.removeIf(collection -> {
            if (!predicate.test(collection)) return false;
            if (hasPartial && PartialCraftingUtil.hasPartialMaterials(collection)) return false;
            if (retainIncompatible && IncompatibleCraftingUtil.hasIncompatibleRecipes(collection)) return false;
            return true;
        });

        return removed;
    }

    @Redirect(method = "updateCollections", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeBookPage;updateCollections(Ljava/util/List;ZZ)V"))
    private void betterRecipeBook$sortCraftableBeforePartial(
            class_513 page, List<class_516> list, boolean resetPageNumber, boolean isFiltering) {
        if (!BetterRecipeBook.config.partialCraftingEnabled) {
            page.method_2627(list, resetPageNumber, isFiltering);
            return;
        }
        List<class_516> craftable = new ArrayList<>();
        List<class_516> partial = new ArrayList<>();
        List<class_516> other = new ArrayList<>();
        for (class_516 c : list) {
            boolean hasCraftable = c.method_2655();
            boolean hasPartial = PartialCraftingUtil.hasPartialMaterials(c);
            if (hasCraftable && !hasPartial) {
                craftable.add(c);
            } else if (hasPartial) {
                partial.add(c);
            } else {
                other.add(c);
            }
        }
        list.clear();
        list.addAll(craftable);
        list.addAll(partial);
        list.addAll(other);
        page.method_2627(list, resetPageNumber, isFiltering);
    }
}
