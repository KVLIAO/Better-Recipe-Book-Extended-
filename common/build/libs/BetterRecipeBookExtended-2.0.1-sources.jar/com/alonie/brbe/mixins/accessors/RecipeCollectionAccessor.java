package com.alonie.brbe.mixins.accessors;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_10298;
import net.minecraft.class_516;

@Mixin(class_516.class)
public interface RecipeCollectionAccessor {
    @Accessor("craftable")
    Set<class_10298> betterRecipeBook$getCraftable();

    @Accessor("selected")
    Set<class_10298> betterRecipeBook$getSelected();
}
