package com.alonie.brbe.mixins.hideoverlay;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.compat.ItemViewCompat;
import net.minecraft.class_11908;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_342;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Intercepts A/R/U keys on container screens when the "Hide REI/JEI Overlay" config is enabled.
 * <p>
 * When REI/JEI overlays are hidden:
 * - A key: consumed to prevent REI/JEI favorites (skipped if a text field is focused)
 * - R/U keys: routed to {@link ItemViewCompat} for recipe/usage lookup
 */
@Mixin(class_465.class)
public abstract class AbstractContainerScreenMixin {

    // GLFW key constants
    private static final int KEY_A = 65;
    private static final int KEY_R = 82;
    private static final int KEY_U = 85;

    @Shadow
    protected class_1735 hoveredSlot;

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void betterRecipeBook$handleKeysOnHiddenOverlay(class_11908 event, CallbackInfoReturnable<Boolean> cir) {
        if (!BetterRecipeBook.config.hideReiJeiOverlay) {
            return;
        }

        int keyCode = event.comp_4795();

        // A key: prevent REI/JEI favorites from processing.
        // If a text field (search box) is focused, let the key through for typing.
        if (keyCode == KEY_A) {
            class_437 screen = (class_437) (Object) this;
            if (!(screen.method_25399() instanceof class_342)) {
                cir.setReturnValue(true);
            }
            return;
        }

        if (keyCode != KEY_R && keyCode != KEY_U) {
            return;
        }

        if (!ItemViewCompat.isLoaded()) {
            return;
        }

        class_1735 slot = this.hoveredSlot;
        if (slot == null || !slot.method_7681()) {
            return;
        }

        class_1799 stack = slot.method_7677();
        boolean handled = keyCode == KEY_R
                ? ItemViewCompat.openRecipeView(stack)
                : ItemViewCompat.openUsageView(stack);

        if (handled) {
            cir.setReturnValue(true);
        }
    }
}
