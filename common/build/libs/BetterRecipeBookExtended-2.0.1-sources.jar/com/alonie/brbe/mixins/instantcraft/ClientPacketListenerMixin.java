package com.alonie.brbe.mixins.instantcraft;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_2653;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPacketListenerMixin {
    @Inject(at = @At("TAIL"), method = "handleContainerSetSlot")
    private void onScreenHandlerSlotUpdate(class_2653 packet, CallbackInfo ci) {
        if (packet.method_11450() != 0) return;
        BetterRecipeBook.instantCraftingManager.onResultSlotUpdated(packet.method_11449());
    }
}
