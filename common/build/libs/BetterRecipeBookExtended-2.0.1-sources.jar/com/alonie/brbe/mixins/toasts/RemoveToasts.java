package com.alonie.brbe.mixins.toasts;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_366;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_366.class)
public class RemoveToasts {
    @Inject(at = @At("HEAD"), method = "render", cancellable = true)
    private void draw(class_332 gui, class_327 font, long startTime, CallbackInfo ci) {
        if (BetterRecipeBook.config.newRecipes.unlockAll) {
            ci.cancel();
        }
    }
}
