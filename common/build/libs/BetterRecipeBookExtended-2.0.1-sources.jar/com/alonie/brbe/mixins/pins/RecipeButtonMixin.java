package com.alonie.brbe.mixins.pins;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.generic.pins.PinnableRecipeCollection;
import com.alonie.brbe.mixins.accessors.KeyMappingAccessor;
import com.alonie.brbe.util.BRBTextures;
import com.alonie.brbe.util.ClientCompat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_514;
import net.minecraft.class_516;

@Mixin(class_514.class)
public abstract class RecipeButtonMixin extends class_339 {

    protected RecipeButtonMixin(int i, int j, int k, int l, class_2561 component) {
        super(i, j, k, l, component);
    }

    @Shadow
    public abstract class_516 getCollection();

    @Inject(method = "getTooltipText", at = @At("RETURN"))
    public void getTooltip(CallbackInfoReturnable<List<class_2561>> cir) {
        if (!BetterRecipeBook.config.enablePinning) return;

        List<class_2561> list = cir.getReturnValue();
        if (list == null) {
            return;
        }

        list.add(class_2561.method_43473());

        String keyName = ((KeyMappingAccessor) BetterRecipeBook.PIN_MAPPING).getKey().method_27445().getString();
        if (BetterRecipeBook.pinnedRecipeManager.has(PinnableRecipeCollection.of(this.getCollection()))) {
            list.add(class_2561.method_43469("brbe.gui.pin.remove", keyName));
        } else {
            list.add(class_2561.method_43469("brbe.gui.pin.add", keyName));
        }
    }

    @Inject(method = "renderWidget", at = @At("RETURN"))
    public void renderWidget_renderFakeItem(class_332 gui, int x, int y, float delta, CallbackInfo ci) {
        // if pins are enabled, and the recipe is pinned, blit the pin texture after the recipe collection is rendered
        if (BetterRecipeBook.config.enablePinning && BetterRecipeBook.pinnedRecipeManager.has(PinnableRecipeCollection.of(getCollection()))) {
            ClientCompat.blitSprite(gui, BRBTextures.RECIPE_BOOK_PIN_SPRITE, method_46426() - 4, method_46427() - 4, 32, 32);
        }
    }

}
