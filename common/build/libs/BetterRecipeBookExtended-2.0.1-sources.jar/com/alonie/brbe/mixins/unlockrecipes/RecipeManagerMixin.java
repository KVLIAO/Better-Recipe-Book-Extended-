package com.alonie.brbe.mixins.unlockrecipes;

import com.alonie.brbe.interfaces.unlockrecipes.IMixinRecipeManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_10298;
import net.minecraft.class_1863;

@Mixin(class_1863.class)
public class RecipeManagerMixin implements IMixinRecipeManager {

    // map for keeping track of unlocked recipes
    // we want this to be an instance variable to avoid any funny business
    @Unique
    private final Set<class_10298> betterRecipeBook$serverUnlockedRecipes = new HashSet<>();

    @Override
    public Set<class_10298> betterRecipeBook$getServerUnlockedRecipes() {
        return betterRecipeBook$serverUnlockedRecipes;
    }

}
