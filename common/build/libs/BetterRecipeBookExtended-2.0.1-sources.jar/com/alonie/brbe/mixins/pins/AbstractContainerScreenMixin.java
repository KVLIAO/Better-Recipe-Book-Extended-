package com.alonie.brbe.mixins.pins;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.generic.pins.PinnableRecipeCollection;
import com.alonie.brbe.mixins.accessors.OverlayRecipeComponentAccessor;
import com.alonie.brbe.mixins.accessors.RecipeBookComponentAccessor;
import com.alonie.brbe.mixins.accessors.RecipeBookPageAccessor;
import com.alonie.brbe.util.ClientCompat;
import net.minecraft.class_10260;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_507;
import net.minecraft.class_508;
import net.minecraft.class_513;
import net.minecraft.class_514;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_10260.class)
public abstract class AbstractContainerScreenMixin {
    @Shadow @Final private class_507<?> recipeBookComponent;

    @Inject(method = "mouseClicked", at = @At(value = "HEAD"), cancellable = true)
    public void betterRecipeBook$clickVisibleOverlayFirst(class_11909 event, boolean doubleClick, CallbackInfoReturnable<Boolean> cir) {
        class_507<?> book = this.recipeBookComponent;
        if (!book.method_2605()) {
            return;
        }

        class_508 alternatesWidget = ((RecipeBookPageAccessor) ((RecipeBookComponentAccessor) book).getRecipeBookPage()).getOverlay();
        if (alternatesWidget.method_2616() && book.method_25402(event, doubleClick)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "render", at = @At(value = "RETURN"))
    public void betterRecipeBook$renderVisibleOverlayOnTop(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, org.spongepowered.asm.mixin.injection.callback.CallbackInfo ci) {
        class_507<?> book = this.recipeBookComponent;
        if (!book.method_2605()) {
            return;
        }

        class_508 alternatesWidget = ((RecipeBookPageAccessor) ((RecipeBookComponentAccessor) book).getRecipeBookPage()).getOverlay();
        if (alternatesWidget.method_2616()) {
            guiGraphics.method_71048();
            alternatesWidget.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        }
    }

    @Inject(method = "keyPressed", at = @At(value = "HEAD"), cancellable = true)
    public void onKeyPressed(class_11908 event, CallbackInfoReturnable<Boolean> cir) {
        class_310 minecraft = class_310.method_1551();
        class_507<?> book = this.recipeBookComponent;

        if (!book.method_2605()) return;

        class_513 page = ((RecipeBookComponentAccessor) book).getRecipeBookPage();
        class_508 alternatesWidget = ((RecipeBookPageAccessor) page).getOverlay();
        class_342 searchBox = ((RecipeBookComponentAccessor) book).getSearchBox();

        // when F is pressed, handle pinning/unpinning of recipes except when searchBox is consuming input
        if (BetterRecipeBook.config.enablePinning && ClientCompat.matches(BetterRecipeBook.PIN_MAPPING, event.comp_4795(), event.comp_4796(), event.comp_4797()) && (searchBox == null || !searchBox.method_20315())) {
            if (alternatesWidget.method_2616()) {
                for (class_339 button : ((OverlayRecipeComponentAccessor) alternatesWidget).getRecipeButtons()) {
                    if (button.method_25367()) {
                        BetterRecipeBook.pinnedRecipeManager.addOrRemoveFavourite(PinnableRecipeCollection.of(alternatesWidget.method_2614()));
                        RecipeBookComponentAccessor accessor = (RecipeBookComponentAccessor) book;
                        boolean filtering = accessor.isFilteringInvoker();
                        accessor.updateCollectionsInvoker(false, filtering);
                        cir.setReturnValue(true);
                        return;
                    }
                }
            }

            for (class_514 button : ((RecipeBookPageAccessor) page).getButtons()) {
                if (button.method_25367()) {
                    BetterRecipeBook.pinnedRecipeManager.addOrRemoveFavourite(PinnableRecipeCollection.of(button.method_2645()));
                    RecipeBookComponentAccessor accessor = (RecipeBookComponentAccessor) book;
                    boolean filtering = accessor.isFilteringInvoker();
                    accessor.updateCollectionsInvoker(false, filtering);
                    cir.setReturnValue(true);
                    return;
                }
            }
        }

        // when <chat key> is pressed, focus recipes component for searchBox
        // this also works for BrewingRecipeBookComponent as the super's searchBox is set to the same object
        if (ClientCompat.matches(minecraft.field_1690.field_1890, event.comp_4795(), event.comp_4796(), event.comp_4797())) {
            minecraft.field_1755.method_25395(book);
        }

    }

}
