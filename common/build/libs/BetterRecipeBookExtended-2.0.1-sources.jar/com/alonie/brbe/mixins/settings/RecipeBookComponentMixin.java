package com.alonie.brbe.mixins.settings;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.interfaces.ISettingsButton;
import net.minecraft.class_11909;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_344;
import net.minecraft.class_507;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_507.class)
public abstract class RecipeBookComponentMixin implements ISettingsButton {

    @Shadow
    protected class_310 minecraft;

    @Shadow
    private int height;
    @Shadow
    private int width;
    @Shadow
    private int xOffset;

    @Shadow
    public abstract boolean isVisible();

    @Unique
    protected class_344 _$settingsButton;

    @Inject(method = "initVisuals", at = @At("RETURN"))
    public void reset(CallbackInfo ci) {
        if (BetterRecipeBook.config.settingsButton) {
            int i = (this.width - 147) / 2 - this.xOffset;
            int j = (this.height - 166) / 2;

            this._$settingsButton = createSettingsButton(i, j);
        }
    }

    @Inject(method = "mouseClicked", at = @At("RETURN"), cancellable = true)
    public void mouseClicked(class_11909 event, boolean doubleClick, CallbackInfoReturnable<Boolean> cir) {
        if (!this.isVisible()) {
            return;
        }

        if (this.settingsButtonMouseClicked(this._$settingsButton, event.comp_4798(), event.comp_4799(), event.method_74245())) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "render", at = @At("RETURN"))
    public void render(class_332 gui, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (this._$settingsButton != null) {
            this._$settingsButton.field_22764 = this.isVisible() && BetterRecipeBook.config.settingsButton;
        }

        if (!this.isVisible()) {
            return;
        }

        this.renderSettingsButton(this._$settingsButton, gui, mouseX, mouseY, delta);
    }

    @Inject(method = "renderTooltip", at = @At("RETURN"))
    public void drawTooltip(class_332 gui, int mouseX, int mouseY, class_1735 hoveredSlot, CallbackInfo ci) {
        if (!this.isVisible()) {
            return;
        }

        this.renderSettingsButtonTooltip(this._$settingsButton, gui, mouseX, mouseY);
    }
}
