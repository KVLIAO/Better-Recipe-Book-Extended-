package com.alonie.brbe.mixins.accessors;

import net.minecraft.class_2561;
import net.minecraft.class_342;
import net.minecraft.class_507;
import net.minecraft.class_513;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_507.class)
public interface RecipeBookComponentAccessor {

    @Accessor("recipeBookPage")
    class_513 getRecipeBookPage();

    @Accessor("searchBox")
    class_342 getSearchBox();

    @Accessor("searchBox")
    void setSearchBox(class_342 searchBox);

    @Invoker("isFiltering")
    boolean isFilteringInvoker();

    @Invoker("updateCollections")
    void updateCollectionsInvoker(boolean resetPage, boolean filteringChanged);

    @Accessor("xOffset")
    int getXOffset();

    @Accessor("SEARCH_HINT")
    static class_2561 getSEARCH_HINT() {
        throw new AssertionError();
    }

    @Accessor("ALL_RECIPES_TOOLTIP")
    static class_2561 getALL_RECIPES_TOOLTIP() {
        throw new AssertionError();
    }

}
