package com.alonie.brbe.mixins.incompatibleenvironment;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.util.IncompatibleCraftingUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_10298;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_490;
import net.minecraft.class_514;
import net.minecraft.class_516;

@Mixin(class_514.class)
public abstract class RecipeButtonMixin {

    @Shadow private class_516 collection;
    @Shadow public abstract class_10298 getCurrentRecipe();

    @Inject(method = "getTooltipText", at = @At("RETURN"))
    private void betterRecipeBook$appendIncompatibleWarning(
            class_1799 itemStack,
            CallbackInfoReturnable<List<class_2561>> cir) {
        if (!BetterRecipeBook.config.showAllRecipesInSurvival) return;
        if (!(class_310.method_1551().field_1755 instanceof class_490)) return;

        List<class_2561> tooltip = cir.getReturnValue();
        if (tooltip == null || tooltip.isEmpty()) return;

        class_10298 currentRecipe;
        try { currentRecipe = this.getCurrentRecipe(); }
        catch (ArithmeticException e) { return; }
        if (currentRecipe == null) return;

        if (IncompatibleCraftingUtil.checkIncompatible(this.collection, currentRecipe)) {
            tooltip.add(class_2561.method_43473());
            tooltip.add(class_2561.method_43471("brbe.gui.environmentIncompatible")
                    .method_27692(class_124.field_1061));
        }
    }
}
