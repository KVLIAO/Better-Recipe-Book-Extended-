package com.alonie.brbe.mixins.accessors;

import net.minecraft.class_5321;
import net.minecraft.class_6880;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_6880.class_6883.class)
public interface HolderReferenceAccessor<T> {
    @Accessor("key")
    class_5321<T> getKey();
}
