package com.alonie.brbe.mixins.alternativerecipes;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.mixins.accessors.ClientRecipeBookAccessor;
import com.alonie.brbe.mixins.accessors.OverlayRecipeButtonPosAccessor;
import com.alonie.brbe.util.BRBTextures;
import com.alonie.brbe.util.ClientCompat;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Map;
import net.minecraft.class_10297;
import net.minecraft.class_10298;
import net.minecraft.class_10363;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;


@Mixin(targets = "net.minecraft.client.gui.screens.recipebook.OverlayRecipeComponent$OverlayRecipeButton")
public abstract class OverlayRecipeButtonMixin extends class_339 {

    @Final
    @Shadow
    private boolean isCraftable;
    @Final
    @Shadow
    private class_10298 recipe;

    @Shadow
    @Final
    private List<Object> slots;

    public OverlayRecipeButtonMixin(int x, int y, int width, int height, class_2561 message) {
        super(x, y, width, height, message);
    }

    @Inject(at = @At("HEAD"), method = "renderWidget", cancellable = true)
    public void renderWidget(class_332 gui, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        class_2960 Identifier;

        Identifier = BRBTextures.RECIPE_BOOK_CRAFTING_OVERLAY_SPRITE.method_52729(this.isCraftable, method_25367());

        ClientCompat.blitSprite(gui, Identifier, method_46426(), method_46427(), this.field_22758, this.field_22759);
        gui.method_51448().pushMatrix();
        if (BetterRecipeBook.config.alternativeRecipes.onHover && !this.method_25367()) { // if show alternatives recipe is enabled and recipe is not hovered, show the result item
            class_1799 recipeOutput = betterRecipeBook$getRecipeOutput();
            gui.method_51427(recipeOutput, method_46426() + 4, method_46427() + 4);
        } else { // otherwise display the crafting recipe
            gui.method_51448().translate(this.method_46426() + 2, this.method_46427() + 2);
            for (Object rawPos : this.slots) {
                OverlayRecipeButtonPosAccessor pos = (OverlayRecipeButtonPosAccessor) rawPos;
                gui.method_51448().pushMatrix();
                gui.method_51448().translate(pos.betterRecipeBook$getX(), pos.betterRecipeBook$getY());
                gui.method_51448().scale(0.375f, 0.375f);
                gui.method_51448().translate(-8.0F, -8.0F);
                gui.method_51427(pos.betterRecipeBook$selectIngredient(0), 0, 0);
                gui.method_51448().popMatrix();
            }
        }
        gui.method_51448().popMatrix();

        ci.cancel();
    }

    private class_1799 betterRecipeBook$getRecipeOutput() {
        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null || minecraft.field_1687 == null) {
            return class_1799.field_8037;
        }

        Map<class_10298, class_10297> known = ((ClientRecipeBookAccessor) minecraft.field_1724.method_3130()).betterRecipeBook$getKnown();
        class_10297 entry = known.get(this.recipe);
        if (entry == null) {
            return class_1799.field_8037;
        }

        List<class_1799> results = entry.method_64730(class_10363.method_65008(minecraft.field_1687));
        return results.isEmpty() ? class_1799.field_8037 : results.get(0);
    }
}
