package com.alonie.brbe.mixins;

import com.alonie.brbe.interfaces.RecipeBookTabButtonIconOffset;
import net.minecraft.class_512;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(class_512.class)
public abstract class RecipeBookTabButtonMixin implements RecipeBookTabButtonIconOffset {
    @Unique
    private int betterRecipeBook$iconYOffset;

    @ModifyArg(
            method = "renderIcon",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/GuiGraphics;renderFakeItem(Lnet/minecraft/world/item/ItemStack;II)V"
            ),
            index = 2
    )
    private int betterRecipeBook$offsetIconY(int y) {
        return y + this.betterRecipeBook$iconYOffset;
    }

    @Override
    public void betterRecipeBook$setIconYOffset(int iconYOffset) {
        this.betterRecipeBook$iconYOffset = iconYOffset;
    }
}
