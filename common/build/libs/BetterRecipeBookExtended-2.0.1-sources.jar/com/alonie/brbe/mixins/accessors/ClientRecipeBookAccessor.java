package com.alonie.brbe.mixins.accessors;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.class_10297;
import net.minecraft.class_10298;
import net.minecraft.class_299;

@Mixin(class_299.class)
public interface ClientRecipeBookAccessor {
    @Accessor("known")
    Map<class_10298, class_10297> betterRecipeBook$getKnown();
}
