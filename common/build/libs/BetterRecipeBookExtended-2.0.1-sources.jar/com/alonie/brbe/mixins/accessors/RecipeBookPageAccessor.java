package com.alonie.brbe.mixins.accessors;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_508;
import net.minecraft.class_513;
import net.minecraft.class_514;
import net.minecraft.class_516;

@Mixin(class_513.class)
public interface RecipeBookPageAccessor {

    @Accessor("buttons")
    List<class_514> getButtons();

    @Accessor("overlay")
    class_508 getOverlay();

    @Accessor("recipeCollections")
    List<class_516> getCollections();

}
