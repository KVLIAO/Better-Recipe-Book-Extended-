package com.alonie.brbe.mixins.rei;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.compat.ItemViewCompat;
import com.alonie.brbe.mixins.accessors.RecipeBookComponentAccessor;
import com.alonie.brbe.mixins.accessors.RecipeBookPageAccessor;
import com.alonie.brbe.util.ClientCompat;
import net.minecraft.class_11908;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_507;
import net.minecraft.class_513;
import net.minecraft.class_514;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Adds REI recipe/usage view shortcuts to the vanilla crafting recipe book.
 * Press R to open recipe view, U to open usage view for the hovered recipe button.
 */
@Mixin(class_507.class)
public abstract class RecipeBookComponentMixin {

    @Shadow
    @Final
    protected class_310 minecraft;

    @Inject(method = "keyPressed", at = @At("RETURN"), cancellable = true)
    private void betterRecipeBook$handleReiKeys(class_11908 event, CallbackInfoReturnable<Boolean> cir) {
        if (!ItemViewCompat.isLoaded()) {
            return;
        }

        if (cir.getReturnValueZ()) {
            return;
        }

        RecipeBookComponentAccessor accessor = (RecipeBookComponentAccessor) this;
        class_513 page = accessor.getRecipeBookPage();
        if (page == null) return;

        for (class_514 button : RecipeBookPageAccessor.class.cast(page).getButtons()) {
            if (button.method_25367()) {
                class_1799 hoveredStack = button.method_64882();
                if (hoveredStack != null && !hoveredStack.method_7960()) {
                    if (ClientCompat.matches(BetterRecipeBook.RECIPE_VIEW_MAPPING, event.comp_4795(), event.comp_4796(), event.comp_4797())) {
                        cir.setReturnValue(ItemViewCompat.openRecipeView(hoveredStack));
                    } else if (ClientCompat.matches(BetterRecipeBook.USAGE_VIEW_MAPPING, event.comp_4795(), event.comp_4796(), event.comp_4797())) {
                        cir.setReturnValue(ItemViewCompat.openUsageView(hoveredStack));
                    }
                }
                return;
            }
        }
    }
}
