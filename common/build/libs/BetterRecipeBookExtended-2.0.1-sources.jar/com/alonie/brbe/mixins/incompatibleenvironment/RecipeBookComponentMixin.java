package com.alonie.brbe.mixins.incompatibleenvironment;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.util.IncompatibleCraftingUtil;
import net.minecraft.class_10298;
import net.minecraft.class_310;
import net.minecraft.class_490;
import net.minecraft.class_507;
import net.minecraft.class_516;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_507.class)
public abstract class RecipeBookComponentMixin {

    @Inject(method = "tryPlaceRecipe", at = @At("HEAD"), cancellable = true)
    private void betterRecipeBook$preventIncompatiblePlacement(
            class_516 collection, class_10298 id, boolean isFiltering,
            CallbackInfoReturnable<Boolean> cir) {
        if (!BetterRecipeBook.config.showAllRecipesInSurvival) return;
        if (!(class_310.method_1551().field_1755 instanceof class_490)) return;
        if (collection == null) return;

        if (IncompatibleCraftingUtil.checkIncompatible(collection, id)) {
            cir.setReturnValue(false);
        }
    }
}
