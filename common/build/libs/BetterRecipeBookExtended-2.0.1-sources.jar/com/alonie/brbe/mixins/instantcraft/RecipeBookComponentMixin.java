package com.alonie.brbe.mixins.instantcraft;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.util.BRBTextures;
import com.alonie.brbe.util.ClientCompat;
import com.alonie.brbe.widget.StateSwitchingButton;
import net.minecraft.class_11909;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_507;
import net.minecraft.class_517;
import com.alonie.brbe.widget.StateSwitchingButton;
import com.alonie.brbe.widget.StateSwitchingButton;
import com.alonie.brbe.widget.StateSwitchingButton;
import com.alonie.brbe.widget.StateSwitchingButton;
import com.alonie.brbe.widget.StateSwitchingButton;
import com.alonie.brbe.widget.StateSwitchingButton;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_507.class)
public abstract class RecipeBookComponentMixin {

    @Shadow protected class_310 minecraft;
    @Shadow private int height;
    @Shadow private int width;
    @Shadow private int xOffset;
    @Shadow public abstract boolean isVisible();

    @Unique protected StateSwitchingButton betterRecipeBook$instantCraftButton;
    @Unique private static final class_2561 TOGGLE_INSTANT_CRAFT_ON_TEXT = class_2561.method_43471("brbe.gui.instantCraft.on");
    @Unique private static final class_2561 TOGGLE_INSTANT_CRAFT_OFF_TEXT = class_2561.method_43471("brbe.gui.instantCraft.off");

    @Unique
    private boolean betterRecipeBook$shouldSkip() {
        if (!BetterRecipeBook.config.instantCraft.showButton) {
            return true;
        }

        return ((Object) this) instanceof class_517;
    }

    @Inject(method = "initVisuals", at = @At("RETURN"))
    public void reset(CallbackInfo ci) {
        if (betterRecipeBook$shouldSkip()) {
            return;
        }

        int i = (this.width - 147) / 2 - this.xOffset;
        int j = (this.height - 166) / 2;

        this.betterRecipeBook$instantCraftButton = new StateSwitchingButton(i + 110, j + 137, 26, 18, false);
        this.betterRecipeBook$instantCraftButton.useStateTriggeredForTexture(true);
        this.betterRecipeBook$instantCraftButton.setStateTriggered(BetterRecipeBook.instantCraftingManager.isEnabled());
        this.betterRecipeBook$instantCraftButton.initTextureValues(BRBTextures.RECIPE_BOOK_INSTANT_CRAFT_BUTTON_SPRITES);
        BetterRecipeBook.instantCraftingManager.lastInstantCraftButton = this.betterRecipeBook$instantCraftButton;
    }

    @Inject(method = "render", at = @At("RETURN"))
    public void render(class_332 gui, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (betterRecipeBook$shouldSkip() || this.betterRecipeBook$instantCraftButton == null) {
            return;
        }

        this.betterRecipeBook$instantCraftButton.setStateTriggered(BetterRecipeBook.instantCraftingManager.isEnabled());
        this.betterRecipeBook$instantCraftButton.field_22764 = this.isVisible();
        if (!this.isVisible()) {
            return;
        }

        this.betterRecipeBook$instantCraftButton.method_25394(gui, mouseX, mouseY, delta);
    }

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    public void mouseClicked(class_11909 event, boolean doubleClick, CallbackInfoReturnable<Boolean> cir) {
        if (!this.isVisible() || betterRecipeBook$shouldSkip() || this.betterRecipeBook$instantCraftButton == null) {
            return;
        }

        if (this.betterRecipeBook$instantCraftButton.mouseClicked(event.comp_4798(), event.comp_4799(), event.method_74245())) {
            boolean enabled = BetterRecipeBook.instantCraftingManager.toggleEnabled();
            this.betterRecipeBook$instantCraftButton.setStateTriggered(enabled);
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "renderTooltip", at = @At("RETURN"))
    public void drawTooltip(class_332 gui, int mouseX, int mouseY, class_1735 hoveredSlot, CallbackInfo ci) {
        if (!this.isVisible() || betterRecipeBook$shouldSkip() || this.betterRecipeBook$instantCraftButton == null) {
            return;
        }

        if (this.betterRecipeBook$instantCraftButton.method_25367() && this.minecraft.field_1755 != null) {
            class_2561 text = this.betterRecipeBook$instantCraftButton.isStateTriggered() ? TOGGLE_INSTANT_CRAFT_ON_TEXT : TOGGLE_INSTANT_CRAFT_OFF_TEXT;
            ClientCompat.setComponentTooltipForNextFrame(gui, java.util.List.of(text), mouseX, mouseY);
        }
    }
}
