package com.alonie.brbe.mixins.accessors;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2371;

@Mixin(class_1661.class)
public interface InventoryAccessor {
    @Accessor("compartments")
    List<class_2371<class_1799>> getCompartments();
}
