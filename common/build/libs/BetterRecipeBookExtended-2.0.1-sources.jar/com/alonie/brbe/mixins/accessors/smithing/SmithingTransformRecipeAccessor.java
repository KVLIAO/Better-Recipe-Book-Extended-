package com.alonie.brbe.mixins.accessors.smithing;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Optional;
import net.minecraft.class_10591;
import net.minecraft.class_1856;
import net.minecraft.class_8060;

@Mixin(class_8060.class)
public interface SmithingTransformRecipeAccessor {
    @Accessor("template")
    Optional<class_1856> getUnderlyingTemplate();

    @Accessor("base")
    class_1856 getUnderlyingBase();

    @Accessor("addition")
    Optional<class_1856> getUnderlyingAddition();

    @Accessor("result")
    class_10591 getResult();
}
