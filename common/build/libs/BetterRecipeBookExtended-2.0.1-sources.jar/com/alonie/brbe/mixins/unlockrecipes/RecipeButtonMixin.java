package com.alonie.brbe.mixins.unlockrecipes;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.util.RecipeUnlockUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.class_10298;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_514;

@Mixin(class_514.class)
public abstract class RecipeButtonMixin {
    @Shadow
    public abstract class_10298 getCurrentRecipe();

    @Inject(method = "getTooltipText", at = @At("RETURN"))
    public void getTooltip(class_1799 itemStack, CallbackInfoReturnable<List<class_2561>> cir) {
        // Don't show "craft once to unlock" when unlock-all is enabled
        if (BetterRecipeBook.config.newRecipes.unlockAll) {
            return;
        }

        if (RecipeUnlockUtil.isTemporarilyUnlocked(this.getCurrentRecipe())) {
            cir.getReturnValue().add(0, class_2561.method_43471("brbe.gui.crafting.lockedRecipe").method_27695(class_124.field_1080, class_124.field_1056));
        }
    }
}
