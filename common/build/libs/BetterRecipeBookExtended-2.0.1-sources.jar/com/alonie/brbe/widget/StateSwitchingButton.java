package com.alonie.brbe.widget;

import com.alonie.brbe.util.ClientCompat;
import net.minecraft.class_11910;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_5244;
import net.minecraft.class_6382;
import net.minecraft.class_8666;

public class StateSwitchingButton extends class_339 {
    protected class_8666 sprites = new class_8666(class_2960.method_60656("widget/button"));
    protected boolean isStateTriggered;
    private final boolean mirrored;
    private boolean useStateTriggeredForTexture;

    public StateSwitchingButton(int x, int y, int width, int height, boolean mirrored) {
        super(x, y, width, height, class_5244.field_39003);
        this.mirrored = mirrored;
    }

    public void initTextureValues(class_8666 sprites) {
        this.sprites = sprites;
    }

    public void setStateTriggered(boolean stateTriggered) {
        this.isStateTriggered = stateTriggered;
    }

    public boolean isStateTriggered() {
        return this.isStateTriggered;
    }

    public void useStateTriggeredForTexture(boolean useStateTriggeredForTexture) {
        this.useStateTriggeredForTexture = useStateTriggeredForTexture;
    }

    public void method_48229(int x, int y) {
        this.method_46421(x);
        this.method_46419(y);
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return ClientCompat.mouseClicked(this, mouseX, mouseY, button);
    }

    @Override
    protected boolean method_25351(class_11910 button) {
        return button.comp_4801() == 0;
    }

    @Override
    protected void method_48579(class_332 gui, int mouseX, int mouseY, float delta) {
        boolean enabledState = this.useStateTriggeredForTexture ? this.isStateTriggered : this.field_22763;
        boolean focusedState = this.useStateTriggeredForTexture ? this.method_25367() : this.method_25367();
        class_2960 sprite = this.sprites.method_52729(enabledState, focusedState);
        gui.method_51448().pushMatrix();
        if (this.mirrored) {
            gui.method_51448().translate(this.method_46426() + this.field_22758, this.method_46427());
            gui.method_51448().scale(-1.0F, 1.0F);
            ClientCompat.blitSprite(gui, sprite, 0, 0, this.field_22758, this.field_22759);
        } else {
            ClientCompat.blitSprite(gui, sprite, this.method_46426(), this.method_46427(), this.field_22758, this.field_22759);
        }
        gui.method_51448().popMatrix();
    }

    @Override
    protected void method_47399(class_6382 narrationElementOutput) {
        this.method_37021(narrationElementOutput);
    }
}
