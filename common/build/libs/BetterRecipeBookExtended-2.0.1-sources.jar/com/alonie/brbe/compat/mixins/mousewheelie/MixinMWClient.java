package com.alonie.brbe.compat.mixins.mousewheelie;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(targets = "de.siphalor.mousewheelie.client.MWClient")
public class MixinMWClient {

    @Inject(remap = false,
            method = "triggerScroll",
            at = @At(value = "INVOKE", target = "Lde/siphalor/mousewheelie/client/util/inject/IScrollableRecipeBook;mouseWheelie_onMouseScrollRecipeBook(DDD)Lde/siphalor/mousewheelie/client/util/ScrollAction;"),
            cancellable = true)
    private static void onTriggerScroll(double mouseX, double mouseY, double scrollY, CallbackInfoReturnable<Boolean> cir) {
        cir.setReturnValue(false);
        cir.cancel();
    }
}
