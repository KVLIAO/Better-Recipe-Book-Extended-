package com.alonie.brbe.util;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1856;
import net.minecraft.class_8786;
import net.minecraft.class_9838;

public class RecipePlacement {

    protected List<List<class_1856>> placement = new ArrayList<>();

    public RecipePlacement(int size) {
        for (int i = 0; i < size; i++) placement.add(new ArrayList<>());
    }

    public static List<List<class_1856>> create(class_8786<?> recipe, int gridWidth, int gridHeight) {
        RecipePlacement placer = new RecipePlacement(gridWidth * gridHeight);
        class_9838.class_9839<class_1856> output = new class_9838.class_9839<class_1856>() {
            @Override
            public void addItemToSlot(class_1856 ingredient, int slot, int x, int y) {
                if (!ingredient.method_65799() && slot < placer.placement.size()) {
                    placer.placement.get(slot).add(ingredient);
                }
            }
        };
        class_9838.method_64566(gridWidth, gridHeight, recipe.comp_1933(),
                recipe.comp_1933().method_61671().method_64675(), output);
        return placer.getPlacement();
    }

    public List<List<class_1856>> getPlacement() {
        return placement;
    }
}
