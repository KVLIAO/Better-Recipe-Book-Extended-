package com.alonie.brbe.util;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.class_10297;
import net.minecraft.class_10298;
import net.minecraft.class_10300;
import net.minecraft.class_10301;
import net.minecraft.class_516;

/**
 * Tracks which recipes in a RecipeCollection require a 3×3 crafting grid
 * and are therefore incompatible with the 2×2 inventory crafting grid.
 * <p>
 * Follows the same {@link WeakHashMap} pattern as {@link PartialCraftingUtil}.
 */
public final class IncompatibleCraftingUtil {
    private static final WeakHashMap<class_516, Set<class_10298>> INCOMPATIBLE_RECIPES = new WeakHashMap<>();
    private static final WeakHashMap<class_516, Integer> CHECKED_COLLECTIONS = new WeakHashMap<>();
    private static int filteringGeneration;
    private static boolean filteringActive;

    private IncompatibleCraftingUtil() {}

    public static boolean isActive() {
        return filteringActive;
    }

    public static void beginFiltering(boolean active) {
        filteringActive = active;
        if (active) {
            filteringGeneration++;
        }
    }

    /**
     * Scans a RecipeCollection for recipes that need a 3×3 grid
     * ({@code ShapedCraftingRecipeDisplay} with width &gt; 2 or height &gt; 2).
     */
    public static void markIncompatibleRecipes(class_516 collection) {
        CHECKED_COLLECTIONS.put(collection, filteringGeneration);
        Set<class_10298> incompatible = null;

        for (class_10297 entry : collection.method_2650()) {
            if (entry.comp_3263() instanceof class_10300 shaped) {
                if (shaped.comp_3268() > 2 || shaped.comp_3269() > 2) {
                    if (incompatible == null) incompatible = new HashSet<>();
                    incompatible.add(entry.comp_3262());
                }
            } else if (entry.comp_3263() instanceof class_10301 shapeless) {
                // 2×2 grid holds 4 items; shapeless recipes with >4 ingredients need 3×3
                if (shapeless.comp_3271().size() > 4) {
                    if (incompatible == null) incompatible = new HashSet<>();
                    incompatible.add(entry.comp_3262());
                }
            }
        }

        if (incompatible != null && !incompatible.isEmpty()) {
            INCOMPATIBLE_RECIPES.put(collection, incompatible);
        } else {
            INCOMPATIBLE_RECIPES.remove(collection);
        }
    }

    /** Call when a collection is split (ungroup) to preserve the incompatible mark. */
    public static void markIncompatibleOnCollection(class_516 collection, class_10298 id) {
        CHECKED_COLLECTIONS.put(collection, filteringGeneration);
        Set<class_10298> existing = INCOMPATIBLE_RECIPES.get(collection);
        if (existing != null) {
            existing.add(id);
        } else {
            INCOMPATIBLE_RECIPES.put(collection, new HashSet<>(Collections.singleton(id)));
        }
    }

    public static boolean wasChecked(class_516 collection) {
        Integer generation = CHECKED_COLLECTIONS.get(collection);
        return filteringActive && generation != null && generation == filteringGeneration;
    }

    public static boolean isIncompatible(class_516 collection, class_10298 id) {
        Set<class_10298> set = INCOMPATIBLE_RECIPES.get(collection);
        return set != null && set.contains(id);
    }

    /**
     * Checks dimensions directly against the recipe display, without relying on
     * the cached marking map. Used by the tooltip and ghost-recipe prevention
     * where the map may not be populated yet (e.g., after ungroup splitting).
     */
    public static boolean checkIncompatible(class_516 collection, class_10298 id) {
        for (class_10297 entry : collection.method_2650()) {
            if (!entry.comp_3262().equals(id)) continue;
            if (entry.comp_3263() instanceof class_10300 shaped)
                return shaped.comp_3268() > 2 || shaped.comp_3269() > 2;
            if (entry.comp_3263() instanceof class_10301 shapeless)
                return shapeless.comp_3271().size() > 4;
            return false;
        }
        return false;
    }

    public static boolean hasIncompatibleRecipes(class_516 collection) {
        Set<class_10298> set = INCOMPATIBLE_RECIPES.get(collection);
        return set != null && !set.isEmpty();
    }
}
