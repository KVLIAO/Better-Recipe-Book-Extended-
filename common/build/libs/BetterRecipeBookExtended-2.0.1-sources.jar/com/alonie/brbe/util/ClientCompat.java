package com.alonie.brbe.util;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import java.util.List;
import net.minecraft.class_10799;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_11910;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_3675;

public final class ClientCompat {
    public static final RenderPipeline GUI_TEXTURED = class_10799.field_56883;

    private ClientCompat() {
    }

    public static class_11908 keyEvent(int keyCode, int scanCode, int modifiers) {
        return new class_11908(keyCode, scanCode, modifiers);
    }

    public static class_11905 characterEvent(char character, int modifiers) {
        return new class_11905(character, modifiers);
    }

    public static class_11909 mouseButtonEvent(double mouseX, double mouseY, int button) {
        return new class_11909(mouseX, mouseY, new class_11910(button, 0));
    }

    public static boolean matches(class_304 keyMapping, int keyCode, int scanCode, int modifiers) {
        return keyMapping.method_1417(keyEvent(keyCode, scanCode, modifiers));
    }

    public static boolean keyPressed(class_342 editBox, int keyCode, int scanCode, int modifiers) {
        return editBox.method_25404(keyEvent(keyCode, scanCode, modifiers));
    }

    public static boolean charTyped(class_342 editBox, char character, int modifiers) {
        return editBox.method_25400(characterEvent(character, modifiers));
    }

    public static boolean mouseClicked(class_339 widget, double mouseX, double mouseY, int button) {
        return widget.method_25402(mouseButtonEvent(mouseX, mouseY, button), false);
    }

    public static boolean isControlDown() {
        class_310 minecraft = class_310.method_1551();
        return class_3675.method_15987(minecraft.method_22683(), class_3675.field_31950)
                || class_3675.method_15987(minecraft.method_22683(), class_3675.field_31954);
    }

    public static void blitSprite(class_332 gui, class_2960 sprite, int x, int y, int width, int height) {
        gui.method_52706(GUI_TEXTURED, sprite, x, y, width, height);
    }

    public static void setComponentTooltipForNextFrame(class_332 gui, List<class_2561> tooltip, int mouseX, int mouseY) {
        gui.method_51434(class_310.method_1551().field_1772, tooltip, mouseX, mouseY);
    }

    public static class_1799[] ingredientItems(class_1856 ingredient) {
        return ingredient.method_8105()
                .map(holder -> holder.comp_349().method_7854())
                .toArray(class_1799[]::new);
    }

    public static class_1799 firstIngredientItem(class_1856 ingredient) {
        class_1799[] items = ingredientItems(ingredient);
        return items.length == 0 ? class_1799.field_8037 : items[0];
    }
}
