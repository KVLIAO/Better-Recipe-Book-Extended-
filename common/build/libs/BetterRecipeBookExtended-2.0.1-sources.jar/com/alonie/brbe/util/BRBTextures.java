package com.alonie.brbe.util;

import com.alonie.brbe.BetterRecipeBook;
import net.minecraft.class_2960;
import net.minecraft.class_8666;

public class BRBTextures {

    private static final String NS = BetterRecipeBook.MOD_ID;

    public static final class_2960 RECIPE_BOOK_BACKGROUND_TEXTURE = class_2960.method_60656("textures/gui/recipe_book.png");

    public static final class_2960 RECIPE_BOOK_BUTTON_SLOT_CRAFTABLE_SPRITE = class_2960.method_60656("recipe_book/slot_craftable");
    public static final class_2960 RECIPE_BOOK_BUTTON_SLOT_UNCRAFTABLE_SPRITE = class_2960.method_60656("recipe_book/slot_uncraftable");
    public static final class_2960 RECIPE_BOOK_PIN_SPRITE = class_2960.method_60655(NS, "recipe_book/pin");
    public static final class_2960 RECIPE_BOOK_OVERLAY_PIN_SPRITE = class_2960.method_60655(NS, "recipe_book/overlay_pin");
    
    public static final class_8666 RECIPE_BOOK_FILTER_BUTTON_SPRITES = new class_8666(
            class_2960.method_60656("recipe_book/filter_enabled"),
            class_2960.method_60656("recipe_book/filter_disabled"),
            class_2960.method_60656("recipe_book/filter_enabled_highlighted"),
            class_2960.method_60656("recipe_book/filter_disabled_highlighted")
    );

    public static final class_8666 RECIPE_BOOK_PAGE_FORWARD_SPRITES = new class_8666(
            class_2960.method_60656("recipe_book/page_forward"),
            class_2960.method_60656("recipe_book/page_forward_highlighted")
    );

    public static final class_8666 RECIPE_BOOK_PAGE_BACKWARD_SPRITES = new class_8666(
            class_2960.method_60656("recipe_book/page_backward"),
            class_2960.method_60656("recipe_book/page_backward_highlighted")
    );

    public static final class_8666 RECIPE_BOOK_BUTTON_SPRITES = new class_8666(
            class_2960.method_60656("recipe_book/button"),
            class_2960.method_60656("recipe_book/button_highlighted")
    );

    public static final class_8666 RECIPE_BOOK_TAB_SPRITES = new class_8666(
            class_2960.method_60656("recipe_book/tab"),
            class_2960.method_60656("recipe_book/tab_selected")
    );

    public static class_8666 RECIPE_BOOK_CRAFTING_OVERLAY_SPRITE = new class_8666(
            class_2960.method_60655(NS, "recipe_book/crafting_overlay"),
            class_2960.method_60655(NS, "recipe_book/crafting_overlay_disabled"),
            class_2960.method_60655(NS, "recipe_book/crafting_overlay_highlighted"),
            class_2960.method_60655(NS, "recipe_book/crafting_overlay_disabled_highlighted")
    );

    public static class_8666 RECIPE_BOOK_PLAIN_OVERLAY_SPRITE = new class_8666(
            class_2960.method_60655(NS, "recipe_book/plain_overlay"),
            class_2960.method_60655(NS, "recipe_book/plain_overlay_disabled"),
            class_2960.method_60655(NS, "recipe_book/plain_overlay_highlighted"),
            class_2960.method_60655(NS, "recipe_book/plain_overlay_disabled_highlighted")
    );

    public static final class_8666 SETTINGS_BUTTON_SPRITES = new class_8666(
            class_2960.method_60655(NS, "recipe_book/button_settings"),
            class_2960.method_60655(NS, "recipe_book/button_settings_highlighted")
    );

    public static final class_8666 RECIPE_BOOK_INSTANT_CRAFT_BUTTON_SPRITES = new class_8666(
            class_2960.method_60655(NS, "recipe_book/button_instantcraft"),
            class_2960.method_60655(NS, "recipe_book/button_instantcraft_disabled"),
            class_2960.method_60655(NS, "recipe_book/button_instantcraft_highlighted"),
            class_2960.method_60655(NS, "recipe_book/button_instantcraft_disabled_highlighted")
    );

}
