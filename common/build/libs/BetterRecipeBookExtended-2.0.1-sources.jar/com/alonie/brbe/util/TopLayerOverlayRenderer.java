package com.alonie.brbe.util;

import com.alonie.brbe.interfaces.TopLayerOverlayProvider;
import com.alonie.brbe.mixins.accessors.AbstractRecipeBookScreenAccessor;
import com.alonie.brbe.mixins.accessors.OverlayRecipeComponentAccessor;
import com.alonie.brbe.mixins.accessors.RecipeBookComponentAccessor;
import com.alonie.brbe.mixins.accessors.RecipeBookPageAccessor;
import java.util.List;
import net.minecraft.class_10260;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_437;
import net.minecraft.class_507;
import net.minecraft.class_508;
import net.minecraft.class_8030;

public final class TopLayerOverlayRenderer {
    private TopLayerOverlayRenderer() {
    }

    public static boolean hasOverlay(class_437 screen) {
        if (screen instanceof TopLayerOverlayProvider provider) {
            return provider.betterRecipeBook$hasTopLayerOverlay();
        }

        return getVanillaOverlay(screen) != null;
    }

    public static void render(class_437 screen, class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        if (screen instanceof TopLayerOverlayProvider provider) {
            if (provider.betterRecipeBook$hasTopLayerOverlay()) {
                guiGraphics.method_71048();
                provider.betterRecipeBook$renderTopLayerOverlay(guiGraphics, mouseX, mouseY, partialTick);
            }
            return;
        }

        class_508 overlay = getVanillaOverlay(screen);
        if (overlay != null) {
            guiGraphics.method_71048();
            overlay.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        }
    }

    public static class_8030 getOverlayBounds(class_437 screen) {
        if (screen instanceof TopLayerOverlayProvider provider) {
            return provider.betterRecipeBook$getTopLayerOverlayBounds();
        }

        class_508 overlay = getVanillaOverlay(screen);
        return overlay == null ? null : getVanillaOverlayBounds(overlay);
    }

    private static class_508 getVanillaOverlay(class_437 screen) {
        if (!(screen instanceof class_10260<?> recipeBookScreen)) {
            return null;
        }

        class_507<?> book = ((AbstractRecipeBookScreenAccessor) recipeBookScreen).betterRecipeBook$getRecipeBookComponent();
        if (!book.method_2605()) {
            return null;
        }

        class_508 overlay = ((RecipeBookPageAccessor) ((RecipeBookComponentAccessor) book).getRecipeBookPage()).getOverlay();
        return overlay.method_2616() ? overlay : null;
    }

    private static class_8030 getVanillaOverlayBounds(class_508 overlay) {
        List<class_339> buttons = ((OverlayRecipeComponentAccessor) overlay).getRecipeButtons();
        if (buttons.isEmpty()) {
            return null;
        }

        int left = Integer.MAX_VALUE;
        int top = Integer.MAX_VALUE;
        int right = Integer.MIN_VALUE;
        int bottom = Integer.MIN_VALUE;

        for (class_339 button : buttons) {
            left = Math.min(left, button.method_46426());
            top = Math.min(top, button.method_46427());
            right = Math.max(right, button.method_46426() + button.method_25368());
            bottom = Math.max(bottom, button.method_46427() + button.method_25364());
        }

        left -= 4;
        top -= 5;
        right += 5;
        bottom += 4;
        return new class_8030(left, top, right - left, bottom - top);
    }
}
