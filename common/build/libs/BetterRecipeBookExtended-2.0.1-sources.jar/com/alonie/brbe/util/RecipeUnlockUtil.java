package com.alonie.brbe.util;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.mixins.accessors.ClientRecipeBookAccessor;
import com.alonie.brbe.mixins.accessors.ServerRecipeBookAccessor;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_10298;
import net.minecraft.class_1132;
import net.minecraft.class_1860;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_3441;
import net.minecraft.class_5321;
import net.minecraft.class_8786;

public class RecipeUnlockUtil {

    private static class_1132 betterRecipeBook$server;
    private static java.util.UUID betterRecipeBook$playerId;
    private static Set<class_5321<class_1860<?>>> betterRecipeBook$originalRecipes = Set.of();
    private static Set<class_10298> betterRecipeBook$originalRecipeDisplays = Set.of();
    private static boolean betterRecipeBook$hasSnapshot;

    /**
     * Applies the current config to the integrated server's recipe book when available.
     */
    public static void syncToConfig() {
        if (BetterRecipeBook.config.newRecipes.unlockAll) {
            unlockRecipes();
        } else {
            restoreRecipes();
        }
    }

    public static void restoreRecipes() {
        if (!betterRecipeBook$hasSnapshot || betterRecipeBook$server == null || betterRecipeBook$playerId == null) {
            betterRecipeBook$clearSession();
            return;
        }

        class_1132 server = betterRecipeBook$server;
        java.util.UUID playerId = betterRecipeBook$playerId;
        Set<class_5321<class_1860<?>>> originalRecipes = Set.copyOf(betterRecipeBook$originalRecipes);

        server.method_20493(() -> {
            class_3222 serverPlayer = server.method_3760().method_14602(playerId);
            if (serverPlayer == null) {
                return;
            }

            class_3441 recipeBook = serverPlayer.method_14253();
            Set<class_5321<class_1860<?>>> recipesToRemove = new HashSet<>(((ServerRecipeBookAccessor) recipeBook).betterRecipeBook$getKnown());
            recipesToRemove.removeAll(originalRecipes);
            if (recipesToRemove.isEmpty()) {
                return;
            }

            java.util.List<class_8786<?>> removedRecipes = recipesToRemove.stream()
                    .map(server.method_3772()::method_8130)
                    .flatMap(java.util.Optional::stream)
                    .toList();

            if (!removedRecipes.isEmpty()) {
                recipeBook.method_14900(removedRecipes, serverPlayer);
            }
        }).join();

        betterRecipeBook$clearSession();
    }

    public static void unlockRecipes() {
        class_310 minecraft = class_310.method_1551();
        if (minecraft.field_1724 == null || !minecraft.method_1496()) {
            return;
        }

        class_1132 server = minecraft.method_1576();
        if (server == null) {
            return;
        }

        java.util.UUID playerId = minecraft.field_1724.method_5667();
        Set<class_10298> clientKnownDisplays = Set.copyOf(((ClientRecipeBookAccessor) minecraft.field_1724.method_3130()).betterRecipeBook$getKnown().keySet());
        server.method_20493(() -> {
            class_3222 serverPlayer = server.method_3760().method_14602(playerId);
            if (serverPlayer == null) {
                return;
            }

            if (betterRecipeBook$hasSnapshot && betterRecipeBook$server == server && playerId.equals(betterRecipeBook$playerId)) {
                return;
            }

            if (!betterRecipeBook$hasSnapshot || betterRecipeBook$server != server || !playerId.equals(betterRecipeBook$playerId)) {
                betterRecipeBook$server = server;
                betterRecipeBook$playerId = playerId;
                betterRecipeBook$originalRecipes = Set.copyOf(((ServerRecipeBookAccessor) serverPlayer.method_14253()).betterRecipeBook$getKnown());
                betterRecipeBook$originalRecipeDisplays = clientKnownDisplays;
                betterRecipeBook$hasSnapshot = true;
            }

            serverPlayer.method_7254(server.method_3772().method_8126());
        }).join();
    }

    public static boolean isTemporarilyUnlocked(class_10298 recipeDisplayId) {
        return BetterRecipeBook.config.newRecipes.unlockAll
                && betterRecipeBook$hasSnapshot
                && !betterRecipeBook$originalRecipeDisplays.contains(recipeDisplayId);
    }

    private static void betterRecipeBook$clearSession() {
        betterRecipeBook$server = null;
        betterRecipeBook$playerId = null;
        betterRecipeBook$originalRecipes = Set.of();
        betterRecipeBook$originalRecipeDisplays = Set.of();
        betterRecipeBook$hasSnapshot = false;
    }
}
