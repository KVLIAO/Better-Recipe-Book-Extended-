package com.alonie.brbe.util;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_636;

/**
 * Simple utility to handle client side movement of items
 * @author Tau
 */
public class ClientInventoryUtil {

    /**
     * Stores an item from a slot/cursor to a slot within the bounds of indexCheck<br>
     * Note: If there is an item being carried bny the cursor, and you aren't storing the cursor item, the cursor item will be stored/dropped
     * @param fromSlot the location of the item, -1 to store the item being carried by the cursor
     * @param indexCheck the bounds of the "storage" - if the predicate returns false, that slot will not be used as storage
     */
    public static boolean storeItem(int fromSlot, Predicate<Integer> indexCheck) {
        class_636 gameMode = class_310.method_1551().field_1761;
        class_310 minecraft = class_310.method_1551();
        class_1703 menu = minecraft.field_1724.field_7512;
        if (menu == null) return false;

        // if fromSlot is null assume the item is being carried
        if (fromSlot >= 0) {
            if (menu.field_7761.get(fromSlot).method_7677().method_7960()) return false;

            // if there is already an item in the hand, drop it.
            if (!menu.method_34255().method_7960()) {
                storeItem(-1, indexCheck);
            }

            gameMode.method_2906(menu.field_7763, fromSlot, 0, class_1713.field_7790, minecraft.field_1724);
        } else if (menu.method_34255().method_7960()) {
            return true;
        }

        // sort the slots so full slots will be checked first
        List<class_1735> slots = new ArrayList<>(menu.field_7761);
        slots.sort((a, b) -> Boolean.compare(a.method_7677().method_7960(), b.method_7677().method_7960()));

        int count = menu.method_34255().method_7947();
        for (class_1735 slot : slots) {
            if (count <= 0) break;
            if (indexCheck.test(slot.field_7874) && (class_1799.method_31577(menu.method_34255(), slot.method_7677()) || slot.method_7677().method_7960())) {
                int slotCount = slot.method_7677().method_7947();
                if (slotCount < slot.method_7675()) {
                    count -= Math.max(0, slot.method_7675() - slotCount);
                    gameMode.method_2906(menu.field_7763, slot.field_7874, 0, class_1713.field_7790, minecraft.field_1724);
                }
            }
        }
        return count <= 0 || menu.method_34255().method_7960();
    }

    /**
     * Drops an item
     * @param slot the slot to drop the item from, -1 to drop the cursor item
     * @param wholeStack drop the whole stack or a single item
     * @param force If we should perform the drop even if the item is air for the client
     */
    public static void dropItem(int slot, boolean wholeStack, boolean force) {
        class_636 gameMode = class_310.method_1551().field_1761;
        class_310 minecraft = class_310.method_1551();
        class_1703 menu = minecraft.field_1724.field_7512;
        if (menu == null) return;

        class_1713 type = class_1713.field_7795;

        if (slot < 0) {
            slot = -999;
            type = class_1713.field_7790;
            if (!force && menu.method_34255().method_7960()) return;
        } else if (!force && menu.field_7761.get(slot).method_7677().method_7960()) {
            return;
        }

        gameMode.method_2906(menu.field_7763, slot, wholeStack ? 0 : 1, type, minecraft.field_1724);
    }

}
