package com.alonie.brbe.util;

import net.minecraft.class_1720;
import net.minecraft.class_1729;
import net.minecraft.class_9884;

public class RecipeMenuUtil {

    public static boolean isRecipeSlot(class_1729 menu, int slot) {
        if (menu instanceof class_1720) {
            return class_1720.field_30738 == slot;
        } else {
            return isCraftingGridSlot(menu, slot);
        }
    }

    public static boolean isCraftingGridSlot(class_1729 menu, int slot) {
        if (menu instanceof class_9884 craftingMenu) {
            return craftingMenu.method_61628().stream().anyMatch(inputSlot -> inputSlot.field_7874 == slot);
        }

        return slot > 0 && slot < menu.field_7761.size();
    }

    public static boolean isResultSlot(class_1729 menu, int slot) {
        if (menu instanceof class_9884 craftingMenu) {
            return craftingMenu.method_61627().field_7874 == slot;
        }

        return slot == 0;
    }

    public static boolean isCraftingMenuSlot(class_1729 menu, int slot) {
        return isCraftingGridSlot(menu, slot) || isResultSlot(menu, slot);
    }

}
