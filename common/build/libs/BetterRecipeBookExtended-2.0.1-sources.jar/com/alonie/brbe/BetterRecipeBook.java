package com.alonie.brbe;

import dev.architectury.registry.client.keymappings.KeyMappingRegistry;
import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.config.Config;
import com.alonie.brbe.loaders.PotionLoader;
import com.alonie.brbe.util.BRBHelper;
import com.alonie.brbe.util.RecipeUnlockUtil;
import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.ConfigHolder;
import me.shedaniel.autoconfig.serializer.Toml4jConfigSerializer;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class BetterRecipeBook {

    public static final String MOD_ID = "brbe";

    public static int queuedScroll;
    public static boolean isFilteringNone;

    public static Config config;
    public static ConfigHolder<Config> configHolder;

    public static PinnedRecipeManager pinnedRecipeManager;
    public static InstantCraftingManager instantCraftingManager;
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    private static final class_304.class_11900 KEY_CATEGORY = class_304.class_11900.method_74698(
            class_2960.method_60655(MOD_ID, "category")
    );

    public static final class_304 PIN_MAPPING = new class_304(
            "key.brbe.pin",
            class_3675.class_307.field_1668,
            class_3675.field_32020,
            KEY_CATEGORY
    );

    public static final class_304 RECIPE_VIEW_MAPPING = new class_304(
            "key.brbe.recipeView",
            class_3675.class_307.field_1668,
            class_3675.field_31907,
            KEY_CATEGORY
    );

    public static final class_304 USAGE_VIEW_MAPPING = new class_304(
            "key.brbe.usageView",
            class_3675.class_307.field_1668,
            class_3675.field_31910,
            KEY_CATEGORY
    );

    public static BRBHelper.Book BREWING = BRBHelper.createBook(MOD_ID, "brewing_stand");
    public static BRBHelper.Book SMITHING = BRBHelper.createBook(MOD_ID, "smithing_table");

    public static BRBBookCategories.Category BREWING_POTION = BREWING.createCategory(new class_1799(class_1802.field_8574));
    public static BRBBookCategories.Category BREWING_SPLASH_POTION = BREWING.createCategory(new class_1799(class_1802.field_8436));
    public static BRBBookCategories.Category BREWING_LINGERING_POTION = BREWING.createCategory(new class_1799(class_1802.field_8150));
    public static BRBBookCategories.Category SMITHING_SEARCH = SMITHING.createSearch();
    public static BRBBookCategories.Category SMITHING_TRANSFORM = SMITHING.createCategory(new class_1799(class_1802.field_41946));
    public static BRBBookCategories.Category SMITHING_TRIM = SMITHING.createCategory(new class_1799(class_1802.field_22028));

    public static void init() {
        PotionLoader.init();

        queuedScroll = 0;
        isFilteringNone = true;

        AutoConfig.register(Config.class, Toml4jConfigSerializer::new);

        configHolder = AutoConfig.getConfigHolder(Config.class);
        configHolder.registerSaveListener((holder, config) -> {
            BetterRecipeBook.config = config;
            RecipeUnlockUtil.syncToConfig();
            return class_1269.field_5812;
        });
        config = configHolder.getConfig();

        pinnedRecipeManager = new PinnedRecipeManager();
        pinnedRecipeManager.read();
        instantCraftingManager = new InstantCraftingManager();

        KeyMappingRegistry.register(PIN_MAPPING);
        KeyMappingRegistry.register(RECIPE_VIEW_MAPPING);
        KeyMappingRegistry.register(USAGE_VIEW_MAPPING);
    }
}
