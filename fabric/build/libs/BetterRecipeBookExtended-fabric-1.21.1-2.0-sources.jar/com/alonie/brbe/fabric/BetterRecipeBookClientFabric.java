package com.alonie.brbe.fabric;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.compat.OverlayHider;
import com.alonie.brbe.compat.rei.ReiCompat;
import dev.architectury.event.events.client.ClientGuiEvent;
import dev.architectury.event.events.client.ClientTickEvent;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_437;

public class BetterRecipeBookClientFabric implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ReiCompat.register();

        ClientGuiEvent.INIT_POST.register((screen, access) -> {
            if (screen != null) {
                OverlayHider.setOverlaysHidden(BetterRecipeBook.config.hideReiJeiOverlay);
            }
        });

        ClientTickEvent.CLIENT_POST.register(client -> {
            class_437 screen = client.field_1755;
            if (BetterRecipeBook.config.hideReiJeiOverlay && screen != null) {
                OverlayHider.ensureJeiOverlayHidden();
            }
        });
    }
}
