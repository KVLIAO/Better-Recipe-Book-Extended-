package com.alonie.brbe.fabric.compat.rei;

import com.alonie.brbe.util.TopLayerOverlayRenderer;
import java.util.Collection;
import net.minecraft.class_437;

public class BetterRecipeBookREIPlugin {

    public static void registerExclusionZones(class_437 screen, Collection<?> zones) {
        // No-op; REI integration handled via ReiCompatHandler reflection
    }
}
