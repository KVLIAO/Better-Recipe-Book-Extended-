package com.alonie.brbe.fabric.mixins.accessors;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_1842;
import net.minecraft.class_1845;

@Mixin(class_1845.class)
public interface FabricPotionBrewingAccessor {
    @Accessor("potionMixes")
    List<class_1845.class_1846<class_1842>> getPotionMixes();
}
