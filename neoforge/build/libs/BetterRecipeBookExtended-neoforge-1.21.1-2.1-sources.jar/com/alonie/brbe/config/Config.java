package com.alonie.brbe.config;

import me.shedaniel.autoconfig.ConfigData;
import me.shedaniel.autoconfig.annotation.ConfigEntry;

@me.shedaniel.autoconfig.annotation.Config(name = "brbe")
public class Config implements ConfigData {

    public boolean enablePinning = true;

    @ConfigEntry.Category("ui")
    public boolean keepCentered = false;

    @ConfigEntry.Gui.Tooltip()
    public boolean showModName = false;

    @ConfigEntry.Category("ui")
    @ConfigEntry.Gui.Tooltip()
    public boolean hideReiJeiOverlay = false;

    @ConfigEntry.Category("recipeFilter")
    public boolean showAllRecipesInSurvival = true;

    @ConfigEntry.Category("recipeFilter")
    @ConfigEntry.Gui.Tooltip()
    public boolean partialCraftingEnabled = true;

    @ConfigEntry.Category("recipeFilter")
    @ConfigEntry.Gui.Tooltip()
    public boolean partialMarkingEnabled = true;

    @ConfigEntry.Category("rbip")
    @ConfigEntry.Gui.TransitiveObject()
    public RecipeBookIsPain rbip = new RecipeBookIsPain();

    @ConfigEntry.Category("newRecipes")
    @ConfigEntry.Gui.TransitiveObject()
    public NewRecipes newRecipes = new NewRecipes();

    @ConfigEntry.Category("instantCraft")
    @ConfigEntry.Gui.TransitiveObject()
    public InstantCraft instantCraft = new InstantCraft();

    @ConfigEntry.Category("alternativeRecipes")
    @ConfigEntry.Gui.TransitiveObject()
    public AlternativeRecipes alternativeRecipes = new AlternativeRecipes();

    @ConfigEntry.Category("scrolling")
    @ConfigEntry.Gui.TransitiveObject()
    public Scrolling scrolling = new Scrolling();

    @ConfigEntry.Gui.PrefixText()
    public boolean settingsButton = true;
    public boolean enableBook = true;

    public static class RecipeBookIsPain {
        @ConfigEntry.Gui.Tooltip()
        public boolean enableRecipeBookIsPain = true;

        public boolean enableTabPage = true;
    }
}
