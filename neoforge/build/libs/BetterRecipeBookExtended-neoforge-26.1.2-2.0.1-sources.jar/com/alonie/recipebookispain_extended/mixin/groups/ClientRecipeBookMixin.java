package com.alonie.recipebookispain_extended.mixin.groups;

import com.alonie.recipebookispain_extended.RecipeBookIsPain;
import com.alonie.recipebookispain_extended.access.ItemAccess;
import net.minecraft.client.ClientRecipeBook;
import net.minecraft.client.gui.screens.recipebook.RecipeCollection;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.display.FurnaceRecipeDisplay;
import net.minecraft.world.item.crafting.display.RecipeDisplay;
import net.minecraft.world.item.crafting.display.RecipeDisplayEntry;
import net.minecraft.world.item.crafting.display.RecipeDisplayId;
import net.minecraft.world.item.crafting.display.SmithingRecipeDisplay;
import net.minecraft.world.item.crafting.display.StonecutterRecipeDisplay;
import net.minecraft.world.item.crafting.ExtendedRecipeBookCategory;
import net.minecraft.util.context.ContextMap;
import net.minecraft.util.context.ContextKeySet;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalInt;

@Mixin(value = ClientRecipeBook.class, priority = 999)
public class ClientRecipeBookMixin {

    @Shadow @Final private Map<RecipeDisplayId, RecipeDisplayEntry> known;
    @Shadow private Map<ExtendedRecipeBookCategory, List<RecipeCollection>> collectionsByTab;

    @Unique
    private static final ContextMap RBIP_EMPTY_CONTEXT = new ContextMap.Builder().create(new ContextKeySet.Builder().build());

    /**
     * Rebuild Polymer namespace cache at the start of every recipe-book refresh.
     */
    @Inject(at = @At("HEAD"), method = "rebuildCollections")
    private void rbip$preRefreshPolymerCache(CallbackInfo ci) {
        RecipeBookIsPain.buildNamespaceCache();
        RecipeBookIsPain.applyNamespaceOverrides();
    }

    @Inject(at = @At("TAIL"), method = "rebuildCollections")
    private void rbip$refreshCreativeGroups(CallbackInfo ci) {
        RecipeBookIsPain.ensureInitialized();
        if (RecipeBookIsPain.RECIPE_BOOK_GROUP_TO_ITEM_GROUP.isEmpty()) return;

        Map<ExtendedRecipeBookCategory, EntryBucket> buckets = new LinkedHashMap<>();
        for (RecipeDisplayEntry entry : this.known.values()) {
            // Skip non-crafting recipes (furnace, smithing, stonecutter) to prevent
            // them from mixing into the crafting recipe book's creative tabs.
            RecipeDisplay display = entry.display();
            if (display instanceof FurnaceRecipeDisplay
                    || display instanceof StonecutterRecipeDisplay
                    || display instanceof SmithingRecipeDisplay) continue;

            ExtendedRecipeBookCategory group = rbip$getGroupForEntry(entry);
            if (group == null) continue;
            buckets.computeIfAbsent(group, ignored -> new EntryBucket()).add(entry);
        }

        if (buckets.isEmpty()) return;

        Map<ExtendedRecipeBookCategory, List<RecipeCollection>> updatedResults = new HashMap<>(this.collectionsByTab);
        buckets.forEach((group, bucket) -> updatedResults.put(group, bucket.toCollections()));
        this.collectionsByTab = Map.copyOf(updatedResults);
    }

    @Unique
    private static int rbip$debugCounter = 0;

    @Unique
    private static ExtendedRecipeBookCategory rbip$getGroupForEntry(RecipeDisplayEntry entry) {
        try {
            for (ItemStack stack : entry.resultItems(RBIP_EMPTY_CONTEXT)) {
                ExtendedRecipeBookCategory group = RecipeBookIsPain.toRecipeBookGroup(stack);
                if (rbip$debugCounter < 20) {
                    RecipeBookIsPain.LOGGER.info("[RBIP-DEBUG] recipe #{} id={} stack={} possibleGroup={}",
                            rbip$debugCounter, entry.id(), stack.getItem(),
                            ((ItemAccess) stack.getItem()).rbip$getPossibleGroup().map(Object::toString).orElse("none"));
                    rbip$debugCounter++;
                }
                if (group != null) return group;
            }
        } catch (Exception e) {
            RecipeBookIsPain.LOGGER.debug("[RBIP] Could not resolve output stack for recipe display {}", entry.id(), e);
        }
        return null;
    }

    private static class EntryBucket {
        private final List<List<RecipeDisplayEntry>> entries = new ArrayList<>();
        private final Map<Integer, List<RecipeDisplayEntry>> groupedEntries = new LinkedHashMap<>();

        private void add(RecipeDisplayEntry entry) {
            OptionalInt group = entry.group();
            if (group.isEmpty()) {
                this.entries.add(List.of(entry));
                return;
            }

            List<RecipeDisplayEntry> grouped = this.groupedEntries.get(group.getAsInt());
            if (grouped == null) {
                grouped = new ArrayList<>();
                this.groupedEntries.put(group.getAsInt(), grouped);
                this.entries.add(grouped);
            }
            grouped.add(entry);
        }

        private List<RecipeCollection> toCollections() {
            return this.entries.stream()
                    .map(entries -> new RecipeCollection(List.copyOf(entries)))
                    .toList();
        }
    }
}
