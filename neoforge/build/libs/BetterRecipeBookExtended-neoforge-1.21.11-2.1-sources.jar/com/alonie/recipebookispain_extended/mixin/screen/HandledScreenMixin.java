package com.alonie.recipebookispain_extended.mixin.screen;

import com.alonie.recipebookispain_extended.access.RecipeBookScrollAccess;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.AbstractRecipeBookScreen;
import net.minecraft.client.gui.screens.recipebook.RecipeBookComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractContainerScreen.class)
public class HandledScreenMixin {
    @Inject(at = @At("HEAD"), method = "mouseScrolled", cancellable = true)
    private void rbip$scrollRecipeBookTabs(double mouseX, double mouseY, double horizontalAmount, double verticalAmount, CallbackInfoReturnable<Boolean> cir) {
        if (!((Object) this instanceof AbstractRecipeBookScreen<?>)) return;

        RecipeBookComponent<?> recipeBook = ((RecipeBookScreenAccessor) this).rbip$getRecipeBook();
        if (((RecipeBookScrollAccess) recipeBook).rbip$scrollPages(mouseX, mouseY, verticalAmount)) {
            cir.setReturnValue(true);
        }
    }
}
